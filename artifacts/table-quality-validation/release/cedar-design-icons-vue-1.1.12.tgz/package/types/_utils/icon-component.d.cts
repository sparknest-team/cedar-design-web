import type { AllowedComponentProps, App, ComponentCustomProps, ComponentOptionsMixin, DefineComponent, VNodeProps } from 'vue';
export interface IconProps {
    size?: string | number;
    color?: string;
    title?: string;
    strokeWidth?: number;
    strokeLinecap?: 'butt' | 'round' | 'square';
    strokeLinejoin?: 'bevel' | 'inherit' | 'miter' | 'round';
    rotate?: number;
    spin?: boolean;
}
type IconEmits = {
    click: (event: MouseEvent) => any;
};
type IconDefaults = {
    strokeWidth: number;
    strokeLinecap: NonNullable<IconProps['strokeLinecap']>;
    strokeLinejoin: NonNullable<IconProps['strokeLinejoin']>;
};
export type IconComponent = import("vue").DefineComponent<IconProps, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, IconEmits, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<IconProps> & Readonly<{
    onClick?: (event: MouseEvent) => any;
}>, IconDefaults> & {
    install(app: import("vue").App): void;
};
export {};
