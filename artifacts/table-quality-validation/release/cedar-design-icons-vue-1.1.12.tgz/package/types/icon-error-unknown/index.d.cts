import type { IconComponent } from '../_utils/icon-component.cjs';
export declare const IconErrorUnknown: IconComponent;
