import type { AllowedComponentProps, ComponentCustomProps, HTMLAttributes, Ref, VNodeProps } from 'vue'
export type PublicProps = VNodeProps & AllowedComponentProps & ComponentCustomProps
export type SlotsType<T extends Record<string, any> = Record<string, any>> = { readonly __slots?: T }
export type AriaAttributes = Pick<HTMLAttributes, Extract<keyof HTMLAttributes, `aria-${string}`>>
export type ShallowRef<T = any> = Ref<T>
export type MaybeRef<T = any> = T | Ref<T>
export type MaybeRefOrGetter<T = any> = MaybeRef<T> | (() => T)
export type Reactive<T> = T extends object ? ReturnType<typeof import('vue').reactive<T>> : T
export type ClassValue = false | null | undefined | string | Record<string, any> | Array<ClassValue>
export type Attrs = import('vue').ComponentPublicInstance['$attrs']
export type ComponentProvideOptions = Record<string | symbol, unknown> | (() => Record<string | symbol, unknown>)
export interface GlobalDirectives {}
