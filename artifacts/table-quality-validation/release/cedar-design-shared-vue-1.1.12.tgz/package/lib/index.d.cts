declare function removeItem<T>(array: T[], item: T): T[] | undefined;
declare function uniq<T>(array: T[]): T[];
declare function normalizeToArray<T>(value: T | T[]): T[];

declare function raf(): Promise<unknown>;
declare function doubleRaf(): Promise<unknown>;
declare function getStyle(element: Element): CSSStyleDeclaration;
declare function getRect(element: Element | Window): DOMRect;
declare function getScrollLeft(element: Element | Window): number;
declare function getScrollTop(element: Element | Window): number;
declare function inViewport(element: HTMLElement): boolean;
declare function preventDefault(event: Event): void;

declare function call<P extends any[], R>(fn?: ((...args: P) => R) | ((...args: P) => R)[] | null, ...args: P): R | R[] | undefined;
declare function throttle<F extends (...args: any[]) => any>(fn: F, delay?: number): (this: unknown, ...args: Parameters<F>) => void;

type MotionState = 'running' | 'paused' | 'pending' | 'finished';
interface MotionOptions {
    from: number;
    to: number;
    duration?: number;
    frame?: (frame: {
        value: number;
        done: boolean;
    }) => void;
    timingFunction?: (progress: number) => number;
    onStateChange?: (state: MotionState) => void;
}
declare function motion(options: MotionOptions): {
    start: () => void;
    pause: () => void;
    reset: () => void;
    getState: () => MotionState;
};

type ClassName = string | undefined | null;
type Classes = (ClassName | [any, ClassName, ClassName?])[];
type BEM<S extends string | undefined, N extends string, NC extends string> = S extends undefined ? NC : S extends `$--${infer CM}` ? `${N}--${CM}` : S extends `--${infer M}` ? `${NC}--${M}` : `${NC}__${S}`;
declare function createNamespaceFn<N extends string>(namespace: N): <C extends string>(name: C) => {
    name: string;
    n<S extends string | undefined = undefined>(suffix?: S | undefined): BEM<S, N, `${N}-${C}`>;
    classes(...names: Classes): any[];
};

declare function clamp(value: number, min: number, max: number): number;
declare function clampArrayRange(index: number, array: unknown[]): number;
declare function toNumber(value: number | string | boolean | undefined | null): number;
declare function floor(value: number, precision?: number): number;

declare function cloneDeep<T>(value: T): T;
type MergeCustomizer = (targetValue: any, sourceValue: any, key: string | number | symbol, object?: any, source?: any) => any;
declare function mergeWith<T extends Record<string, any>, K extends Record<string, any>>(object: T, ...sources: [...K[], customizer: MergeCustomizer]): T & K;

declare function inBrowser(): boolean;
declare function inMobile(): boolean;
declare function hasOwn<T extends object>(value: T, key: PropertyKey): key is keyof T;
declare function isArray(value: unknown): value is any[];
declare function isBoolean(value: unknown): value is boolean;
declare function isFunction(value: unknown): value is (...args: any[]) => any;
declare function isNumber(value: unknown): value is number;
declare function isString(value: unknown): value is string;
declare function isNumeric(value: unknown): value is number | string;
declare function isObject(value: unknown): value is Record<string, any>;
declare function isPlainObject(value: unknown): value is Record<string, any>;
declare function isEmpty(value: unknown): boolean;
declare function isWindow(value: unknown): value is Window;
declare function supportTouch(): boolean;

declare function camelize(value: string): string;
declare function kebabCase(value: string): string;
declare function pascalCase(value: string): string;
declare function slash(path: string): string;

declare function assert(condition: boolean, source: string, message: string): asserts condition;
declare function error(source: string, message: string): void;

export { MotionState, assert, call, camelize, clamp, clampArrayRange, cloneDeep, createNamespaceFn, doubleRaf, error, floor, getRect, getScrollLeft, getScrollTop, getStyle, hasOwn, inBrowser, inMobile, inViewport, isArray, isBoolean, isEmpty, isFunction, isNumber, isNumeric, isObject, isPlainObject, isString, isWindow, kebabCase, mergeWith, motion, normalizeToArray, pascalCase, preventDefault, raf, removeItem, slash, supportTouch, throttle, toNumber, uniq };
