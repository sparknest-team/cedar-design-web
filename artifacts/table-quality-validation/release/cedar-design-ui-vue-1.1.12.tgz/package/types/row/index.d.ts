import Component from './Row.vue';
import { rowProps } from './props';
declare const Row: import('../_utils/global-config').CedarComponentWithInstall<typeof Component>;
export { Row, rowProps };
export type { RowProps, RowGutter, RowAlign, RowJustify } from './props';
export type RowInstance = InstanceType<typeof Component>;
export declare const _RowComponent: typeof Row;
export default Row;
