import type { ComputedRef, InjectionKey } from 'vue';
export interface RowContext {
    gutter: import("vue").ComputedRef<[
        number,
        number
    ]>;
    div: import("vue").ComputedRef<boolean>;
}
export declare const ROW_CONTEXT_KEY: import("vue").InjectionKey<RowContext>;
