import { type VNode, type VNodeChild } from "vue";
/** Keep visible text/zero and empty elements, but omit empty structural nodes. */
export declare function isEmptySpaceNode(value: import("vue").VNodeChild): boolean;
export interface SpaceChild {
    node: import("vue").VNode;
    key: string;
}
/** Key namespaces belong to one Space instance, never to a shared registry. */
export declare function createSpaceChildren(): (nodes: import("vue").VNodeChild[]) => SpaceChild[];
