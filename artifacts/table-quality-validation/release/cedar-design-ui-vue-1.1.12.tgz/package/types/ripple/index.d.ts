import { type Directive, type Plugin } from 'vue';
import type { RippleDirectiveValue } from './props';
export type { RippleDirectiveValue } from './props';
declare const Ripple: import("vue").Directive<HTMLElement, RippleDirectiveValue | undefined> & import("vue").Plugin;
export type RippleInstance = typeof Ripple;
export declare const _RippleComponent: typeof Ripple;
export { Ripple };
export default Ripple;
