import _Popover from './Popover.vue';
import { popoverProps } from './props';
declare const Popover: import('../_utils/global-config').ComponentWithInstall<typeof _Popover>;
export type PopoverInstance = InstanceType<typeof _Popover>;
export type { PopoverPlacement, PopoverProps, PopoverTrigger } from './props';
export { Popover, popoverProps };
export declare const _PopoverComponent: typeof Popover;
export default Popover;
