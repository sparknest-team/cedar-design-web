import _Paper from './Paper.vue';
declare const Paper: import('../_utils/global-config').ComponentWithInstall<typeof _Paper>;
export { Paper };
export { paperProps } from './props';
export type { PaperProps } from './props';
export type PaperInstance = InstanceType<typeof _Paper>;
export declare const _PaperComponent: typeof Paper;
export default Paper;
