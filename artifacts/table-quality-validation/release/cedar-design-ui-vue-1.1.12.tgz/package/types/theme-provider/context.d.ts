import { type ComputedRef } from 'vue';
import type { ThemeProviderProps, ThemeProviderMode } from './props';
/** Presets belong to a theme boundary; explicit user overrides continue to inherit. */
export declare function provideThemeScope(props: Readonly<ThemeProviderProps>): import("vue").ComputedRef<{
    'data-c-theme': ThemeProviderMode | undefined;
    style: import("../_utils/maple/elements").StyleVars;
}>;
/** Apply on the actual teleported root, regardless of its destination. */
export declare function useThemeScope(): import("vue").ComputedRef<{
    'data-c-theme': ThemeProviderMode | undefined;
    style: Record<string, string>;
} | {
    'data-c-theme'?: undefined;
    style?: undefined;
}>;
