import _Badge from './Badge.vue';
import { badgeProps } from './props';
declare const Badge: import('../_utils/global-config').ComponentWithInstall<typeof _Badge>;
export type BadgeInstance = InstanceType<typeof _Badge>;
export { badgeProps };
export type { BadgeInlinePosition, BadgeMode, BadgePosition, BadgeProps, BadgeVariant, } from './props';
export { Badge };
export declare const _BadgeComponent: typeof Badge;
export default Badge;
