declare var __VLS_1: {}, __VLS_3: {};
type __VLS_Slots = {} & {
    content?: (props: typeof __VLS_1) => any;
} & {
    default?: (props: typeof __VLS_3) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    description: StringConstructor;
    dot: BooleanConstructor;
    max: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    show: {
        type: BooleanConstructor;
        default: boolean;
    };
    showZero: {
        type: BooleanConstructor;
        default: boolean;
    };
    offsetX: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    offsetY: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    color: StringConstructor;
    content: {
        type: import("vue").PropType<number | string>;
        validator: (value: number | string) => boolean;
    };
    textColor: StringConstructor;
    mode: {
        type: import("vue").PropType<import("./props").BadgeMode>;
        default: string;
        validator: (value: unknown) => value is import("./props").BadgeMode;
    };
    position: {
        type: import("vue").PropType<import("./props").BadgePosition>;
        default: string;
        validator: (value: unknown) => value is import("./props").BadgePosition;
    };
    inlinePosition: {
        type: import("vue").PropType<import("./props").BadgeInlinePosition>;
        default: string;
        validator: (value: unknown) => value is import("./props").BadgeInlinePosition;
    };
    size: {
        type: import("vue").PropType<import("..").ComponentSize>;
        default: string;
        validator: (value: unknown) => value is import("..").ComponentSize;
    };
    status: {
        type: import("vue").PropType<import("..").SemanticStatus>;
        default: string;
        validator: (value: unknown) => value is import("..").SemanticStatus;
    };
    variant: {
        type: import("vue").PropType<import("./props").BadgeVariant>;
        default: string;
        validator: (value: unknown) => value is import("./props").BadgeVariant;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    description: StringConstructor;
    dot: BooleanConstructor;
    max: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    show: {
        type: BooleanConstructor;
        default: boolean;
    };
    showZero: {
        type: BooleanConstructor;
        default: boolean;
    };
    offsetX: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    offsetY: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    color: StringConstructor;
    content: {
        type: import("vue").PropType<number | string>;
        validator: (value: number | string) => boolean;
    };
    textColor: StringConstructor;
    mode: {
        type: import("vue").PropType<import("./props").BadgeMode>;
        default: string;
        validator: (value: unknown) => value is import("./props").BadgeMode;
    };
    position: {
        type: import("vue").PropType<import("./props").BadgePosition>;
        default: string;
        validator: (value: unknown) => value is import("./props").BadgePosition;
    };
    inlinePosition: {
        type: import("vue").PropType<import("./props").BadgeInlinePosition>;
        default: string;
        validator: (value: unknown) => value is import("./props").BadgeInlinePosition;
    };
    size: {
        type: import("vue").PropType<import("..").ComponentSize>;
        default: string;
        validator: (value: unknown) => value is import("..").ComponentSize;
    };
    status: {
        type: import("vue").PropType<import("..").SemanticStatus>;
        default: string;
        validator: (value: unknown) => value is import("..").SemanticStatus;
    };
    variant: {
        type: import("vue").PropType<import("./props").BadgeVariant>;
        default: string;
        validator: (value: unknown) => value is import("./props").BadgeVariant;
    };
}>> & Readonly<{}>, {
    size: "xs" | "sm" | "md" | "lg" | "xl";
    mode: "inline" | "floating";
    position: "left" | "right" | "top-right" | "top-left" | "bottom-right" | "bottom-left";
    status: "default" | "primary" | "secondary" | "tertiary" | "info" | "success" | "warning" | "danger";
    variant: "default" | "outline";
    show: boolean;
    dot: boolean;
    max: number;
    showZero: boolean;
    offsetX: number;
    offsetY: number;
    inlinePosition: "start" | "end";
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
