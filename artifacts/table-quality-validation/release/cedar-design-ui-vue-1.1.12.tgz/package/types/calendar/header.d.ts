import { PropType } from 'vue';
import type { Dayjs } from 'dayjs';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    allowSelect: {
        type: BooleanConstructor;
        default: boolean;
    };
    mode: {
        type: import("vue").PropType<"day" | "week" | "month" | "year">;
    };
    dayStartOfWeek: {
        type: import("vue").PropType<0 | 1>;
    };
    isWeek: {
        type: BooleanConstructor;
    };
    panel: {
        type: BooleanConstructor;
    };
    modes: {
        type: import("vue").PropType<("day" | "week" | "month" | "year")[]>;
    };
    headerType: {
        type: StringConstructor;
    };
    pageShowData: {
        type: import("vue").PropType<Dayjs>;
        required: true;
    };
    move: {
        type: FunctionConstructor;
        required: true;
    };
    onYearChange: {
        type: FunctionConstructor;
        required: true;
    };
    onMonthChange: {
        type: FunctionConstructor;
        required: true;
    };
    changePageShowDate: {
        type: FunctionConstructor;
        required: true;
    };
    onModeChange: {
        type: import("vue").PropType<(value: any, ev?: Event) => void>;
        required: true;
    };
    headerValueFormat: {
        type: StringConstructor;
        required: true;
    };
}>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("yearChange" | "monthChange")[], "yearChange" | "monthChange", import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    allowSelect: {
        type: BooleanConstructor;
        default: boolean;
    };
    mode: {
        type: import("vue").PropType<"day" | "week" | "month" | "year">;
    };
    dayStartOfWeek: {
        type: import("vue").PropType<0 | 1>;
    };
    isWeek: {
        type: BooleanConstructor;
    };
    panel: {
        type: BooleanConstructor;
    };
    modes: {
        type: import("vue").PropType<("day" | "week" | "month" | "year")[]>;
    };
    headerType: {
        type: StringConstructor;
    };
    pageShowData: {
        type: import("vue").PropType<Dayjs>;
        required: true;
    };
    move: {
        type: FunctionConstructor;
        required: true;
    };
    onYearChange: {
        type: FunctionConstructor;
        required: true;
    };
    onMonthChange: {
        type: FunctionConstructor;
        required: true;
    };
    changePageShowDate: {
        type: FunctionConstructor;
        required: true;
    };
    onModeChange: {
        type: import("vue").PropType<(value: any, ev?: Event) => void>;
        required: true;
    };
    headerValueFormat: {
        type: StringConstructor;
        required: true;
    };
}>> & Readonly<{
    onYearChange?: ((...args: any[]) => any) | undefined;
    onMonthChange?: ((...args: any[]) => any) | undefined;
}>, {
    panel: boolean;
    isWeek: boolean;
    allowSelect: boolean;
}>;
export default _default;
