import { PropType } from 'vue';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    modelValue: {
        type: DateConstructor;
        default: undefined;
    };
    defaultValue: {
        type: DateConstructor;
    };
    mode: {
        type: import("vue").PropType<"month" | "year">;
    };
    defaultMode: {
        type: import("vue").PropType<"month" | "year">;
        default: string;
    };
    modes: {
        type: import("vue").PropType<("month" | "year")[]>;
        default: () => string[];
    };
    allowSelect: {
        type: BooleanConstructor;
        default: boolean;
    };
    panel: {
        type: BooleanConstructor;
        default: boolean;
    };
    panelWidth: {
        type: NumberConstructor;
    };
    panelTodayBtn: {
        type: BooleanConstructor;
        default: boolean;
    };
    dayStartOfWeek: {
        type: import("vue").PropType<0 | 1>;
        default: number;
    };
    isWeek: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    'update:modelValue': (date: Date) => true;
    'update:mode': (mode: "month" | "year") => true;
    /**
     * @zh 选择的日期改变时触发
     * @en Emitted when the selected date changes
     * @property {Date} date
     */
    change: (date: Date) => true;
    /**
     * @zh 日期面板改变时触发
     * @en Emitted when the displayed date changes
     * @property {Date} date
     */
    "panel-change": (date: Date) => true;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    modelValue: {
        type: DateConstructor;
        default: undefined;
    };
    defaultValue: {
        type: DateConstructor;
    };
    mode: {
        type: import("vue").PropType<"month" | "year">;
    };
    defaultMode: {
        type: import("vue").PropType<"month" | "year">;
        default: string;
    };
    modes: {
        type: import("vue").PropType<("month" | "year")[]>;
        default: () => string[];
    };
    allowSelect: {
        type: BooleanConstructor;
        default: boolean;
    };
    panel: {
        type: BooleanConstructor;
        default: boolean;
    };
    panelWidth: {
        type: NumberConstructor;
    };
    panelTodayBtn: {
        type: BooleanConstructor;
        default: boolean;
    };
    dayStartOfWeek: {
        type: import("vue").PropType<0 | 1>;
        default: number;
    };
    isWeek: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    onChange?: ((date: Date) => any) | undefined;
    "onUpdate:modelValue"?: ((date: Date) => any) | undefined;
    "onUpdate:mode"?: ((mode: "month" | "year") => any) | undefined;
    "onPanel-change"?: ((date: Date) => any) | undefined;
}>, {
    modelValue: Date;
    panel: boolean;
    dayStartOfWeek: 0 | 1;
    isWeek: boolean;
    allowSelect: boolean;
    modes: ("month" | "year")[];
    defaultMode: "month" | "year";
    panelTodayBtn: boolean;
}>;
export default _default;
