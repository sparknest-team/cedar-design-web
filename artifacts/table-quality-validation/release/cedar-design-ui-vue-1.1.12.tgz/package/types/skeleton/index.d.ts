import _Skeleton from './Skeleton.vue';
import _SkeletonLine from './Line.vue';
import _SkeletonShape from './Shape.vue';
import { skeletonLineProps, skeletonProps, skeletonShapeProps } from './props';
declare const Skeleton: import('../_utils/global-config').CedarComponentWithInstall<typeof _Skeleton & {
    Line: typeof _SkeletonLine;
    Shape: typeof _SkeletonShape;
}>;
export type SkeletonInstance = InstanceType<typeof _Skeleton>;
export type SkeletonLineInstance = InstanceType<typeof _SkeletonLine>;
export type SkeletonShapeInstance = InstanceType<typeof _SkeletonShape>;
export { skeletonLineProps, skeletonProps, skeletonShapeProps };
export type { SkeletonLineProps, SkeletonProps, SkeletonShapeProps, SkeletonShapeSize, SkeletonShapeType, SkeletonSize, } from './props';
export { Skeleton };
export { _SkeletonLine as SkeletonLine, _SkeletonShape as SkeletonShape };
export declare const _SkeletonComponent: typeof Skeleton;
export declare const _SkeletonLineComponent: typeof _SkeletonLine;
export declare const _SkeletonShapeComponent: typeof _SkeletonShape;
export default Skeleton;
