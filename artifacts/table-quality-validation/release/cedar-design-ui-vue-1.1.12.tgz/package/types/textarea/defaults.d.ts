/** Device-specific native resize default; no runtime platform switch. */
export declare const textareaDefaults: {
    resize: boolean;
};
