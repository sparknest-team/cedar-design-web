import type { ComputedRef } from 'vue';
import type { ComponentSize, SemanticStatus } from '../_utils/constant';
import type { ButtonVariant } from './props';
export interface ButtonGroupProvider {
    elevation: import("vue").ComputedRef<number | boolean>;
    status: import("vue").ComputedRef<SemanticStatus>;
    size: import("vue").ComputedRef<ComponentSize>;
    variant: import("vue").ComputedRef<ButtonVariant>;
    color: import("vue").ComputedRef<string | undefined>;
    textColor: import("vue").ComputedRef<string | undefined>;
    disabled: import("vue").ComputedRef<boolean>;
    stacked: import("vue").ComputedRef<boolean>;
    vertical: import("vue").ComputedRef<boolean>;
}
export declare const BUTTON_GROUP_BIND_BUTTON_KEY: unique symbol;
export declare function useButtons(): {
    length: import("vue").ComputedRef<number>;
    buttons: null[];
    bindButtons: (parentProvider: ButtonGroupProvider) => void;
};
