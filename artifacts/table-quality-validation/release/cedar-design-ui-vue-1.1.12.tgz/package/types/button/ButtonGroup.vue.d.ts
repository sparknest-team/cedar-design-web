import { type ButtonGroupProvider } from './group-provide';
declare var __VLS_1: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    status: {
        type: import("vue").PropType<import("..").SemanticStatus>;
        default: string;
        validator: (value: import("..").SemanticStatus) => boolean;
    };
    size: {
        type: import("vue").PropType<import("..").ComponentSize>;
        default: undefined;
        validator: (value: import("..").ComponentSize) => boolean;
    };
    variant: {
        type: import("vue").PropType<import("./variant").ButtonVariant>;
        default: string;
        validator: (value: import("./variant").ButtonVariant) => boolean;
    };
    color: StringConstructor;
    textColor: StringConstructor;
    disabled: BooleanConstructor;
    stacked: BooleanConstructor;
    vertical: BooleanConstructor;
    elevation: {
        type: (BooleanConstructor | NumberConstructor)[];
        default: boolean;
    };
}>, {
    buttonGroupProvider: ButtonGroupProvider;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    status: {
        type: import("vue").PropType<import("..").SemanticStatus>;
        default: string;
        validator: (value: import("..").SemanticStatus) => boolean;
    };
    size: {
        type: import("vue").PropType<import("..").ComponentSize>;
        default: undefined;
        validator: (value: import("..").ComponentSize) => boolean;
    };
    variant: {
        type: import("vue").PropType<import("./variant").ButtonVariant>;
        default: string;
        validator: (value: import("./variant").ButtonVariant) => boolean;
    };
    color: StringConstructor;
    textColor: StringConstructor;
    disabled: BooleanConstructor;
    stacked: BooleanConstructor;
    vertical: BooleanConstructor;
    elevation: {
        type: (BooleanConstructor | NumberConstructor)[];
        default: boolean;
    };
}>> & Readonly<{}>, {
    vertical: boolean;
    size: "xs" | "sm" | "md" | "lg" | "xl";
    disabled: boolean;
    status: "default" | "primary" | "secondary" | "tertiary" | "info" | "success" | "warning" | "danger";
    variant: "default" | "text" | "tonal" | "outline";
    elevation: number | boolean;
    stacked: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
