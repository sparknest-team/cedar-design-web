import _Button from "./base";
import _ButtonGroup from "./ButtonGroup.vue";
import { buttonProps, buttonGroupProps } from "./props";
declare const Button: import('../_utils/global-config').CedarComponentWithInstall<typeof _Button & {
    Group: typeof _ButtonGroup;
}>;
export type ButtonInstance = InstanceType<typeof _Button>;
export type ButtonGroupInstance = InstanceType<typeof _ButtonGroup>;
export type { ButtonProps, ButtonGroupProps, ButtonVariant, ButtonLoadingMode } from "./props";
export { buttonProps, buttonGroupProps };
export { Button };
export { _ButtonGroup as ButtonGroup };
export declare const _ButtonComponent: typeof Button;
export declare const _ButtonGroupComponent: typeof _ButtonGroup;
export default Button;
