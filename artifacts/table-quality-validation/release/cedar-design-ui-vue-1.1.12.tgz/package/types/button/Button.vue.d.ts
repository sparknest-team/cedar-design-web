declare var __VLS_15: {}, __VLS_20: {};
type __VLS_Slots = {} & {
    icon?: (props: typeof __VLS_15) => any;
} & {
    default?: (props: typeof __VLS_20) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    status: {
        type: import("vue").PropType<import("../index.ts").SemanticStatus>;
        validator: (v: import("../index.ts").SemanticStatus) => boolean;
    };
    variant: {
        type: import("vue").PropType<import("./variant.ts").ButtonVariant>;
        validator: (v: import("./variant.ts").ButtonVariant) => boolean;
    };
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
        validator: (v: import("../index.ts").ComponentSize) => boolean;
    };
    htmlType: {
        type: import("vue").PropType<typeof import("./props").buttonHtmlTypes[number]>;
        default: string;
        validator: (v: typeof import("./props").buttonHtmlTypes[number]) => boolean;
    };
    component: {
        type: import("vue").PropType<typeof import("./props").buttonComponents[number]>;
        default: string;
        validator: (v: typeof import("./props").buttonComponents[number]) => boolean;
    };
    round: BooleanConstructor;
    block: BooleanConstructor;
    loading: BooleanConstructor;
    loadingType: {
        type: import("vue").PropType<import("../index.ts").LoadingType>;
        default: string;
    };
    loadingMode: {
        type: import("vue").PropType<import("./props").ButtonLoadingMode>;
        default: string;
        validator: (v: import("./props").ButtonLoadingMode) => boolean;
    };
    loadingSize: import("vue").PropType<import("../index.ts").LoadingSize>;
    loadingColor: {
        type: StringConstructor;
        default: string;
    };
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    ripple: {
        type: BooleanConstructor;
        default: boolean;
    };
    focusable: {
        type: BooleanConstructor;
        default: boolean;
    };
    autofocus: BooleanConstructor;
    textColor: StringConstructor;
    color: StringConstructor;
    elevation: {
        type: import("vue").PropType<boolean | number>;
        default: boolean;
    };
    stacked: {
        type: BooleanConstructor;
        default: undefined;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    click: (event: MouseEvent) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    status: {
        type: import("vue").PropType<import("../index.ts").SemanticStatus>;
        validator: (v: import("../index.ts").SemanticStatus) => boolean;
    };
    variant: {
        type: import("vue").PropType<import("./variant.ts").ButtonVariant>;
        validator: (v: import("./variant.ts").ButtonVariant) => boolean;
    };
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
        validator: (v: import("../index.ts").ComponentSize) => boolean;
    };
    htmlType: {
        type: import("vue").PropType<typeof import("./props").buttonHtmlTypes[number]>;
        default: string;
        validator: (v: typeof import("./props").buttonHtmlTypes[number]) => boolean;
    };
    component: {
        type: import("vue").PropType<typeof import("./props").buttonComponents[number]>;
        default: string;
        validator: (v: typeof import("./props").buttonComponents[number]) => boolean;
    };
    round: BooleanConstructor;
    block: BooleanConstructor;
    loading: BooleanConstructor;
    loadingType: {
        type: import("vue").PropType<import("../index.ts").LoadingType>;
        default: string;
    };
    loadingMode: {
        type: import("vue").PropType<import("./props").ButtonLoadingMode>;
        default: string;
        validator: (v: import("./props").ButtonLoadingMode) => boolean;
    };
    loadingSize: import("vue").PropType<import("../index.ts").LoadingSize>;
    loadingColor: {
        type: StringConstructor;
        default: string;
    };
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    ripple: {
        type: BooleanConstructor;
        default: boolean;
    };
    focusable: {
        type: BooleanConstructor;
        default: boolean;
    };
    autofocus: BooleanConstructor;
    textColor: StringConstructor;
    color: StringConstructor;
    elevation: {
        type: import("vue").PropType<boolean | number>;
        default: boolean;
    };
    stacked: {
        type: BooleanConstructor;
        default: undefined;
    };
}>> & Readonly<{
    onClick?: ((event: MouseEvent) => any) | undefined;
}>, {
    round: boolean;
    autofocus: boolean;
    disabled: boolean;
    elevation: number | boolean;
    loading: boolean;
    component: "a" | "button";
    loadingMode: "default" | "fill" | "line";
    ripple: boolean;
    stacked: boolean;
    htmlType: "button" | "reset" | "submit";
    block: boolean;
    loadingType: import("../index.ts").LoadingType;
    loadingColor: string;
    focusable: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
