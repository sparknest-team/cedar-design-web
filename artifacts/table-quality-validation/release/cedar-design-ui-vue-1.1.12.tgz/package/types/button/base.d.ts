import Button from './Button.vue';
declare const Component: typeof Button & {
    setPropsDefaults: (defaults: Record<string, any>) => void;
};
export default Component;
