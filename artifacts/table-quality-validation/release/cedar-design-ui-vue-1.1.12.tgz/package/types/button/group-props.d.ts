import { type PropType } from 'vue';
import type { ComponentSize, SemanticStatus } from '../_utils/constant';
import { type ButtonVariant } from './variant';
export declare const buttonGroupProps: {
    /**
     * 按钮组主题色
     */
    status: {
        type: import("vue").PropType<SemanticStatus>;
        default: string;
        validator: (value: SemanticStatus) => boolean;
    };
    /**
     * 按钮组尺寸
     */
    size: {
        type: import("vue").PropType<ComponentSize>;
        default: undefined;
        validator: (value: ComponentSize) => boolean;
    };
    /**
     * 按钮组变体
     */
    variant: {
        type: import("vue").PropType<ButtonVariant>;
        default: string;
        validator: (value: ButtonVariant) => boolean;
    };
    /**
     * 自定义背景色
     */
    color: StringConstructor;
    /**
     * 自定义文字色
     */
    textColor: StringConstructor;
    /**
     * 是否禁用
     */
    disabled: BooleanConstructor;
    /**
     * 是否堆叠
     */
    stacked: BooleanConstructor;
    /**
     * 是否纵向排列
     */
    vertical: BooleanConstructor;
    /**
     * 海拔阴影
     */
    elevation: {
        type: (BooleanConstructor | NumberConstructor)[];
        default: boolean;
    };
};
export type ButtonGroupProps = import('../_utils/public-props').CompatiblePublicProps<typeof buttonGroupProps>;
