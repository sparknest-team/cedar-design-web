import _PageHeader from './PageHeader.vue';
declare const PageHeader: import('../_utils/global-config').ComponentWithInstall<typeof _PageHeader>;
export type PageHeaderInstance = InstanceType<typeof _PageHeader>;
export type { PageHeaderProps, PageHeaderSlots } from './props';
export { pageHeaderProps } from './props';
export declare const _PageHeaderComponent: typeof PageHeader;
export { PageHeader };
export default PageHeader;
