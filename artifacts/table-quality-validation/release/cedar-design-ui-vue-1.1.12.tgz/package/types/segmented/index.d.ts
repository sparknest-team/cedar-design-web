import _Segmented from './segmented';
import { segmentedProps } from './props';
declare const Segmented: import('../_utils/global-config').ComponentWithInstall<typeof _Segmented>;
export type SegmentedInstance = InstanceType<typeof _Segmented>;
export { segmentedProps };
export type { SegmentedOption, SegmentedProps, SegmentedValue } from './props';
export { Segmented };
export declare const _SegmentedComponent: typeof Segmented;
export default Segmented;
