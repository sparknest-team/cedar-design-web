import type { AppContext } from "vue";
import _Drawer from "./drawer.vue";
import { drawerProps } from "./props";
import type { DrawerConfig, DrawerUpdateConfig } from "./types";
declare const open: (config: DrawerConfig, appContext?: import("vue").AppContext) => {
    close: () => void;
    update: (config: DrawerUpdateConfig) => void;
};
declare const Drawer: import('../_utils/global-config').ComponentWithInstall<typeof _Drawer & {
    open: typeof open;
    _context: import("vue").AppContext | null;
}>;
export type { DrawerAction, DrawerMethod, DrawerConfig, DrawerReturn, DrawerUpdateConfig, } from "./types";
export type DrawerInstance = InstanceType<typeof _Drawer>;
export type { DrawerPlacement, DrawerProps } from "./props";
export { Drawer, drawerProps };
export declare const _DrawerComponent: typeof Drawer;
export default Drawer;
export type { DrawerBeforeClose } from "./types";
