import { type CSSProperties } from 'vue';
import type { DrawerAction } from "./types";
declare function handleConfirm(event?: Event): void;
declare function handleCancel(event?: Event): void;
declare function handleClose(event?: Event): void;
declare var __VLS_18: {}, __VLS_20: {}, __VLS_32: {}, __VLS_34: {
    cancel: typeof handleCancel;
    confirm: typeof handleConfirm;
    close: typeof handleClose;
};
type __VLS_Slots = {} & {
    header?: (props: typeof __VLS_18) => any;
} & {
    title?: (props: typeof __VLS_20) => any;
} & {
    default?: (props: typeof __VLS_32) => any;
} & {
    footer?: (props: typeof __VLS_34) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    topDivider: {
        type: BooleanConstructor;
        default: boolean;
    };
    bottomDivider: {
        type: BooleanConstructor;
        default: boolean;
    };
    dir: {
        type: import("vue").PropType<import("@cedar-design/use-vue").ReadingDirection>;
    };
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: {
        type: BooleanConstructor;
        default: boolean;
    };
    placement: {
        type: import("vue").PropType<import("./props").DrawerPlacement>;
        default: string;
        validator: (value: import("./props").DrawerPlacement) => boolean;
    };
    title: StringConstructor;
    overlay: {
        type: BooleanConstructor;
        default: boolean;
    };
    overlayClass: StringConstructor;
    overlayStyle: import("vue").PropType<import("vue").CSSProperties>;
    overlayClosable: {
        type: BooleanConstructor;
        default: boolean;
    };
    closable: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButtonText: StringConstructor;
    cancelButtonText: StringConstructor;
    confirmButtonLoading: {
        type: BooleanConstructor;
        default: boolean;
    };
    cancelButtonLoading: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButtonDisabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    cancelButtonDisabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButtonProps: import("vue").PropType<import("../button").ButtonProps>;
    cancelButtonProps: import("vue").PropType<import("../button").ButtonProps>;
    unmountOnClose: {
        type: BooleanConstructor;
        default: boolean;
    };
    width: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    height: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    popupContainer: {
        type: import("vue").PropType<import("../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    drawerClass: import("vue").PropType<string | any[]>;
    drawerStyle: import("vue").PropType<import("vue").CSSProperties>;
    bodyClass: import("vue").PropType<string | any[]>;
    bodyStyle: import("vue").PropType<import("../_utils/style-value.ts").CompatibleStyleValue>;
    beforeClose: import("vue").PropType<import("./types").DrawerBeforeClose>;
    escToClose: {
        type: BooleanConstructor;
        default: boolean;
    };
    lockScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    closeOnRouteChange: {
        type: BooleanConstructor;
        default: boolean;
    };
    overlayAnimationName: {
        type: StringConstructor;
        default: string;
    };
    header: {
        type: BooleanConstructor;
        default: boolean;
    };
    footer: {
        type: BooleanConstructor;
        default: boolean;
    };
    cancelButton: {
        type: BooleanConstructor;
        default: boolean;
    };
    ariaLabel: StringConstructor;
    closeButtonAriaLabel: {
        type: StringConstructor;
        default: string;
    };
    zIndex: NumberConstructor;
}>, {
    close: () => void;
    confirm: typeof handleConfirm;
    cancel: typeof handleCancel;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "guard-error": (error: unknown, action: DrawerAction) => void;
    "update:open": (value: boolean) => void;
    close: () => void;
    closed: () => void;
    open: () => void;
    opened: () => void;
    cancel: (value: Event) => void;
    confirm: (value: Event) => void;
    "click-overlay": (value: MouseEvent) => void;
    "key-escape": (value: KeyboardEvent) => void;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    topDivider: {
        type: BooleanConstructor;
        default: boolean;
    };
    bottomDivider: {
        type: BooleanConstructor;
        default: boolean;
    };
    dir: {
        type: import("vue").PropType<import("@cedar-design/use-vue").ReadingDirection>;
    };
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: {
        type: BooleanConstructor;
        default: boolean;
    };
    placement: {
        type: import("vue").PropType<import("./props").DrawerPlacement>;
        default: string;
        validator: (value: import("./props").DrawerPlacement) => boolean;
    };
    title: StringConstructor;
    overlay: {
        type: BooleanConstructor;
        default: boolean;
    };
    overlayClass: StringConstructor;
    overlayStyle: import("vue").PropType<import("vue").CSSProperties>;
    overlayClosable: {
        type: BooleanConstructor;
        default: boolean;
    };
    closable: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButtonText: StringConstructor;
    cancelButtonText: StringConstructor;
    confirmButtonLoading: {
        type: BooleanConstructor;
        default: boolean;
    };
    cancelButtonLoading: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButtonDisabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    cancelButtonDisabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButtonProps: import("vue").PropType<import("../button").ButtonProps>;
    cancelButtonProps: import("vue").PropType<import("../button").ButtonProps>;
    unmountOnClose: {
        type: BooleanConstructor;
        default: boolean;
    };
    width: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    height: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    popupContainer: {
        type: import("vue").PropType<import("../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    drawerClass: import("vue").PropType<string | any[]>;
    drawerStyle: import("vue").PropType<import("vue").CSSProperties>;
    bodyClass: import("vue").PropType<string | any[]>;
    bodyStyle: import("vue").PropType<import("../_utils/style-value.ts").CompatibleStyleValue>;
    beforeClose: import("vue").PropType<import("./types").DrawerBeforeClose>;
    escToClose: {
        type: BooleanConstructor;
        default: boolean;
    };
    lockScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    closeOnRouteChange: {
        type: BooleanConstructor;
        default: boolean;
    };
    overlayAnimationName: {
        type: StringConstructor;
        default: string;
    };
    header: {
        type: BooleanConstructor;
        default: boolean;
    };
    footer: {
        type: BooleanConstructor;
        default: boolean;
    };
    cancelButton: {
        type: BooleanConstructor;
        default: boolean;
    };
    ariaLabel: StringConstructor;
    closeButtonAriaLabel: {
        type: StringConstructor;
        default: string;
    };
    zIndex: NumberConstructor;
}>> & Readonly<{
    onCancel?: ((value: Event) => any) | undefined;
    onClose?: (() => any) | undefined;
    onClosed?: (() => any) | undefined;
    onOpen?: (() => any) | undefined;
    onConfirm?: ((value: Event) => any) | undefined;
    "onUpdate:open"?: ((value: boolean) => any) | undefined;
    onOpened?: (() => any) | undefined;
    "onKey-escape"?: ((value: KeyboardEvent) => any) | undefined;
    "onClick-overlay"?: ((value: MouseEvent) => any) | undefined;
    "onGuard-error"?: ((error: unknown, action: DrawerAction) => any) | undefined;
}>, {
    closable: boolean;
    footer: boolean;
    header: boolean;
    width: string | number;
    height: string | number;
    overlay: boolean;
    popupContainer: import("../index.ts").PopupContainer;
    open: boolean;
    defaultOpen: boolean;
    placement: "top" | "bottom" | "left" | "right";
    unmountOnClose: boolean;
    escToClose: boolean;
    closeButtonAriaLabel: string;
    topDivider: boolean;
    bottomDivider: boolean;
    cancelButton: boolean;
    confirmButtonLoading: boolean;
    cancelButtonLoading: boolean;
    confirmButtonDisabled: boolean;
    cancelButtonDisabled: boolean;
    lockScroll: boolean;
    closeOnRouteChange: boolean;
    overlayClosable: boolean;
    overlayAnimationName: string;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
