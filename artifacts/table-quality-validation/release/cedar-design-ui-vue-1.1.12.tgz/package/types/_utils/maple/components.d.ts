import { type App, type Component, type ComponentPublicInstance, type ExtractPropTypes, type Plugin, type PropType, type Ref, type VNode } from 'vue';
import type { ZodSafeParseResult, ZodType } from 'zod';
export type ListenerProp<F> = F | F[];
export interface MountInstance {
    instance: import("vue").ComponentPublicInstance;
    unmount: () => void;
}
export type ExtractPublicPropTypes<P> = Partial<import("vue").ExtractPropTypes<P>>;
export declare function pickProps<T, U extends keyof T>(props: T, propsKey: U): T[U];
export declare function pickProps<T, U extends keyof T>(props: T, propsKey: U[]): Pick<T, U>;
export type ComponentWithInstall<T> = T & import("vue").Plugin & {
    setPropsDefaults: (defaults: Record<string, any>) => void;
};
export interface WithInstallOptions<InstallOptions = unknown> {
    components?: import("vue").Component[];
    resolveName?: (component: import("vue").Component, options?: InstallOptions) => string | undefined;
    setup?: (app: import("vue").App, options?: InstallOptions) => void;
}
export declare function withInstall<T extends import("vue").Component, InstallOptions = unknown>(component: T, target?: undefined, options?: WithInstallOptions<InstallOptions>): ComponentWithInstall<T>;
export declare function withInstall<T, InstallOptions = unknown>(component: import("vue").Component, target: T, options?: WithInstallOptions<InstallOptions>): ComponentWithInstall<T>;
export declare function withPropsDefaultsSetter<T>(target: T, props: Record<string, any>): T & {
    setPropsDefaults: (defaults: Record<string, any>) => void;
};
export declare function mount(component: import("vue").Component): MountInstance;
export declare function mountInstance(component: any, props?: Record<string, any>, eventListener?: Record<string, any>): {
    unmountInstance: () => void;
};
export declare function isZodRule(rule: unknown): rule is ZodType;
export declare function isZodResult(result: unknown): result is ZodSafeParseResult<any>;
export declare function useValidation(): {
    errorMessage: import("vue").Ref<string>;
    validate: (ruleOrRules: any | any[], value: any, apis?: any) => Promise<boolean>;
    resetValidation: () => void;
    validateWithTrigger: <T>(validateTrigger: T[], trigger: T, rules: any, value: any, apis?: any) => Promise<void>;
};
export declare function useRouteListener(listener: () => void): void;
export declare function useTeleport(): {
    disabled: import("vue").Ref<boolean>;
};
export declare const createNamespace: <C extends string>(name: C) => {
    name: string;
    n<S extends string | undefined = undefined>(suffix?: S | undefined): S extends undefined ? `mp-${C}` : S extends `$--${infer CM}` ? `mp--${CM}` : S extends `--${infer M}` ? `mp-${C}--${M}` : `mp-${C}__${S}`;
    classes(...names: ((string | null | undefined) | [
        any,
        string | null | undefined,
        (string | null | undefined)?
    ])[]): any[];
};
export declare function defineListenerProp<F>(fallback?: any): {
    type: import("vue").PropType<F | F[]>;
    default: any;
};
export declare function formatElevation(elevation: number | boolean | string, defaultLevel?: number): string | null;
export declare const MaybeVNode: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    is: {
        type: import("vue").PropType<string | import("vue").VNode>;
    };
    tag: {
        type: StringConstructor;
        default: string;
    };
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}> | undefined, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    is: {
        type: import("vue").PropType<string | import("vue").VNode>;
    };
    tag: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{}>, {
    tag: string;
}>;
