export declare function canRestoreFocus(element: HTMLElement): boolean;
export declare function isTabStop(element: HTMLElement): boolean;
