import type { Ref, shallowRef } from 'vue';
type ShallowMarker = Pick<ReturnType<typeof shallowRef>, Exclude<keyof ReturnType<typeof shallowRef>, keyof import("vue").Ref<any>>>;
export type CompatibleShallowRef<T> = import("vue").Ref<T> & ShallowMarker;
export {};
