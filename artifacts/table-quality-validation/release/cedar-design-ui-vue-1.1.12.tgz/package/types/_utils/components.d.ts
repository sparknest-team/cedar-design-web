import { type PropType, type ExtractPropTypes } from 'vue';
export type ExtractPublicPropTypes<P> = Partial<import("vue").ExtractPropTypes<P>>;
export declare function defineListenerProp<F>(fallback?: any): {
    type: import("vue").PropType<F | F[]>;
    default: any;
};
export declare const createNamespace: <C extends string>(name: C) => {
    name: string;
    n<S extends string | undefined = undefined>(suffix?: S | undefined): S extends undefined ? `c-${C}` : S extends `$--${infer CM}` ? `c--${CM}` : S extends `--${infer M}` ? `c-${C}--${M}` : `c-${C}__${S}`;
    classes(...names: ((string | null | undefined) | [
        any,
        string | null | undefined,
        (string | null | undefined)?
    ])[]): any[];
};
