import { type ReadingDirection } from '@cedar-design/use-vue';
import type { PropType } from 'vue';
export { useDirection, resolveDirection } from '@cedar-design/use-vue';
export type { ReadingDirection } from '@cedar-design/use-vue';
/** Distance from the physical left edge, including negative native RTL scrollLeft. */
export declare function physicalScrollLeft(element: HTMLElement): number;
/** Convert a physical scrollbar-thumb coordinate back to the native CSSOM coordinate. */
export declare function nativeScrollLeft(element: HTMLElement, physical: number): number;
/** Reading direction for typed portal options; omitted values inherit their source scope. */
export declare const readingDirectionProp: {
    type: import("vue").PropType<ReadingDirection>;
};
/** Nonnegative distance from the reading start; native RTL CSSOM values are negative. */
export declare function inlineScrollLeft(element: HTMLElement): number;
export declare function setInlineScrollLeft(element: HTMLElement, offset: number): void;
