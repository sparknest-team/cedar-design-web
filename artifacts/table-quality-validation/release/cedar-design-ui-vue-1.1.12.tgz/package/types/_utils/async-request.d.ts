/** Every caller still settles; only the newest request may mutate visible state. */
export declare function createRequestGuard(): {
    begin(): () => boolean;
    invalidate(): void;
};
