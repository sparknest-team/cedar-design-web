import { type ComputedRef, type PropType } from "vue";
export type EmptyValue<T> = T | null | (() => T | null);
/** Omitted preserves the component default. A factory may explicitly return undefined. */
export declare function emptyValueProp<T>(): {
    type: import("vue").PropType<EmptyValue<T>>;
    default: undefined;
};
export declare function resolveEmptyValue<T>(props: {
    emptyValue?: EmptyValue<T>;
}, fallback: T): T | null;
/** Input recognition only; never used to decide controlled ownership. */
export declare const DEFAULT_EMPTY_VALUES: readonly unknown[];
export interface EmptyValuePolicyProps {
    emptyValues?: readonly unknown[];
    emptyText?: string;
}
export declare const emptyValuesProp: {
    type: import("vue").PropType<readonly unknown[]>;
    default: undefined;
};
export declare const emptyTextProp: {
    type: StringConstructor;
    default: undefined;
};
/** Empty containers stay empty; members do not make a non-empty collection empty. */
export declare function isEmptyValue(value: unknown, values?: readonly unknown[]): boolean;
/** Form/Item settings remain reactive; only Item registers its primary fields. */
export declare function provideEmptyValues(props: EmptyValuePolicyProps, registerFields?: boolean): {
    hasCustomEmptyValues: import("vue").ComputedRef<boolean>;
    isEmpty: (value: unknown) => boolean;
    emptyValues: import("vue").ComputedRef<readonly unknown[] | undefined>;
    emptyText: import("vue").ComputedRef<string | undefined>;
};
/** Resolve recognition/display separately from clear output and model ownership. */
export declare function useEmptyValues(props: EmptyValuePolicyProps, defaults?: readonly unknown[], register?: boolean): {
    emptyText: import("vue").ComputedRef<string>;
    emptyValues: import("vue").ComputedRef<readonly unknown[] | undefined>;
    hasCustomEmptyValues: import("vue").ComputedRef<boolean>;
    isEmpty: (value: unknown) => boolean;
};
