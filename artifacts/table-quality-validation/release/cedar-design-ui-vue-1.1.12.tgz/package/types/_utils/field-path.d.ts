export declare function resolveFieldPath(object: any, path: string | undefined, strict?: boolean): {
    o: any;
    k: string;
    v: any;
};
