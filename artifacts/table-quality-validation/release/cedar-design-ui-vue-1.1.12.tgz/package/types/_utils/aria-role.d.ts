/** Resolve the first recognized role using ASCII whitespace and case folding. */
export declare function resolveConcreteAriaRole(value: string | null): string | undefined;
export declare const interactiveAriaRoles: ReadonlySet<string>;
export declare function isInteractiveAriaRole(value: string | null): boolean;
