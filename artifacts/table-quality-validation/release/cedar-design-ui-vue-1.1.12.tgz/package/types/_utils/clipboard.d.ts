export declare const clipboard: (text: string, canFallback?: () => boolean) => Promise<boolean>;
