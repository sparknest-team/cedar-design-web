export declare const _ContextComponent: {
    zIndex: number;
    enableRipple: boolean;
};
declare const _default: {
    zIndex: number;
    enableRipple: boolean;
};
export default _default;
