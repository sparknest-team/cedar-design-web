import _ConfigProvider from './ConfigProvider.vue';
import { configProviderProps } from './props';
declare const ConfigProvider: import('../_utils/global-config').ComponentWithInstall<typeof _ConfigProvider>;
export type ConfigProviderInstance = InstanceType<typeof _ConfigProvider>;
export type { ConfigProviderProps } from './props';
export { ConfigProvider, configProviderProps };
export declare const _ConfigProviderComponent: typeof ConfigProvider;
export default ConfigProvider;
export type { ConfigProviderSlots } from './interfaces';
