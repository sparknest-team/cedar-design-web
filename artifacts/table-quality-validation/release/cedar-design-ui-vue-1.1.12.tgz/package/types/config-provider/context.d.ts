import type { ReadingDirection } from '@cedar-design/use-vue';
import { InjectionKey, Slots } from 'vue';
import { CedarLang } from '../locale/types';
import { ComponentSize } from '../_utils/constant';
export interface ConfigProvider {
    slots: import("vue").Slots;
    prefixCls?: string;
    locale?: CedarLang;
    size?: ComponentSize;
    updateAtScroll?: boolean;
    scrollToClose?: boolean;
    dir?: ReadingDirection;
}
export declare const configProviderInjectionKey: import("vue").InjectionKey<ConfigProvider>;
