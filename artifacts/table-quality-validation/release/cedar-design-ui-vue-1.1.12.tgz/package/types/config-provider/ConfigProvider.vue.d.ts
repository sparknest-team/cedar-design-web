import type { ConfigProviderSlots } from './interfaces';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    prefixCls: {
        type: StringConstructor;
        default: undefined;
    };
    locale: {
        type: import("vue").PropType<import("../locale/types.ts").CedarLang>;
    };
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
        validator: (value: import("../index.ts").ComponentSize) => boolean;
    };
    global: {
        type: BooleanConstructor;
        default: boolean;
    };
    updateAtScroll: {
        type: BooleanConstructor;
        default: undefined;
    };
    scrollToClose: {
        type: BooleanConstructor;
        default: undefined;
    };
    dir: {
        type: import("vue").PropType<import("@cedar-design/use-vue").ReadingDirection>;
    };
}>, {
    direction: import("vue").ComputedRef<import("@cedar-design/use-vue").ReadingDirection | undefined>;
    root: import("vue").Ref<HTMLElement | undefined>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    prefixCls: {
        type: StringConstructor;
        default: undefined;
    };
    locale: {
        type: import("vue").PropType<import("../locale/types.ts").CedarLang>;
    };
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
        validator: (value: import("../index.ts").ComponentSize) => boolean;
    };
    global: {
        type: BooleanConstructor;
        default: boolean;
    };
    updateAtScroll: {
        type: BooleanConstructor;
        default: undefined;
    };
    scrollToClose: {
        type: BooleanConstructor;
        default: undefined;
    };
    dir: {
        type: import("vue").PropType<import("@cedar-design/use-vue").ReadingDirection>;
    };
}>> & Readonly<{}>, {
    global: boolean;
    updateAtScroll: boolean;
    scrollToClose: boolean;
    prefixCls: string;
}> & {
    new (): {
        $slots: ConfigProviderSlots;
    };
};
export default _default;
