import _Ellipsis from './Ellipsis.vue';
import { ellipsisProps } from './props';
declare const Ellipsis: import('../_utils/global-config').CedarComponentWithInstall<typeof _Ellipsis>;
export type EllipsisInstance = InstanceType<typeof _Ellipsis>;
export type { EllipsisProps, EllipsisExpandTrigger } from './props';
export { Ellipsis, ellipsisProps };
export declare const _EllipsisComponent: typeof Ellipsis;
export default Ellipsis;
