import { type TooltipProps } from '../tooltip';
declare var __VLS_6: {}, __VLS_8: {}, __VLS_10: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_6) => any;
} & {
    'tooltip-content'?: (props: typeof __VLS_8) => any;
} & {
    default?: (props: typeof __VLS_10) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    expand: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultExpand: {
        type: BooleanConstructor;
        default: boolean;
    };
    expandTrigger: {
        type: import("vue").PropType<import("./props").EllipsisExpandTrigger>;
        validator: (value: string) => value is "click";
    };
    lineClamp: {
        type: (StringConstructor | NumberConstructor)[];
        validator: (value: unknown) => boolean;
    };
    tooltip: {
        type: import("vue").PropType<TooltipProps | boolean>;
        default: boolean;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:expand": (expand: boolean) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    expand: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultExpand: {
        type: BooleanConstructor;
        default: boolean;
    };
    expandTrigger: {
        type: import("vue").PropType<import("./props").EllipsisExpandTrigger>;
        validator: (value: string) => value is "click";
    };
    lineClamp: {
        type: (StringConstructor | NumberConstructor)[];
        validator: (value: unknown) => boolean;
    };
    tooltip: {
        type: import("vue").PropType<TooltipProps | boolean>;
        default: boolean;
    };
}>> & Readonly<{
    "onUpdate:expand"?: ((expand: boolean) => any) | undefined;
}>, {
    tooltip: boolean | TooltipProps;
    expand: boolean;
    defaultExpand: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
