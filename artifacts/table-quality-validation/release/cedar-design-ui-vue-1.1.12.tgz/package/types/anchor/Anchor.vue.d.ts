import { type AnchorBoundaryPosition } from './props';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    boundary: {
        type: import("vue").PropType<AnchorBoundaryPosition | number>;
        default: string;
        validator: (value: any) => boolean;
    };
    showLine: {
        type: BooleanConstructor;
        default: boolean;
    };
    showBackground: {
        type: BooleanConstructor;
        default: boolean;
    };
    scrollContainer: {
        type: import("vue").PropType<string | HTMLElement | Window>;
    };
    changeHash: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {
    n: (suffix?: string) => string;
    classes: (...names: ((string | null | undefined) | [
        any,
        string | null | undefined,
        (string | null | undefined)?
    ])[]) => any[];
    cls: import("vue").ComputedRef<any[]>;
    anchorRef: import("vue").Ref<HTMLElement | undefined>;
    lineSliderRef: import("vue").Ref<HTMLElement | undefined>;
    linkBackgroundRef: import("vue").Ref<HTMLElement | undefined>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    /** @zh 用户点击链接时触发 @en Triggered when the user clicks on the link */
    select: (hash: string | undefined, preHash: string) => true;
    /** @zh 链接发生改变时触发 @en Triggered when the link changes */
    change: (hash: string) => true;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    boundary: {
        type: import("vue").PropType<AnchorBoundaryPosition | number>;
        default: string;
        validator: (value: any) => boolean;
    };
    showLine: {
        type: BooleanConstructor;
        default: boolean;
    };
    showBackground: {
        type: BooleanConstructor;
        default: boolean;
    };
    scrollContainer: {
        type: import("vue").PropType<string | HTMLElement | Window>;
    };
    changeHash: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    onSelect?: ((hash: string | undefined, preHash: string) => any) | undefined;
    onChange?: ((hash: string) => any) | undefined;
}>, {
    boundary: number | "center" | "start" | "end" | "nearest";
    showLine: boolean;
    showBackground: boolean;
    changeHash: boolean;
}>;
export default _default;
