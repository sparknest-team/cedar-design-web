import { InjectionKey } from 'vue';
export interface AnchorContext {
    currentLink: string;
    addLink: (hash: string, node: HTMLElement) => void;
    removeLink: (hash: string, node: HTMLElement) => void;
    handleClick: (e: MouseEvent, hash?: string) => void;
}
export declare const anchorInjectionKey: import("vue").InjectionKey<AnchorContext>;
