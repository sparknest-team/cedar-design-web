declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    title: StringConstructor;
    href: StringConstructor;
}>, {
    n: (suffix?: string) => string;
    classes: (...names: ((string | null | undefined) | [
        any,
        string | null | undefined,
        (string | null | undefined)?
    ])[]) => any[];
    cls: import("vue").ComputedRef<any[]>;
    isCurrent: import("vue").ComputedRef<boolean>;
    linkRef: import("vue").Ref<HTMLElement | undefined>;
    handleClick: (e: MouseEvent) => void | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    title: StringConstructor;
    href: StringConstructor;
}>> & Readonly<{}>, {}>;
export default _default;
