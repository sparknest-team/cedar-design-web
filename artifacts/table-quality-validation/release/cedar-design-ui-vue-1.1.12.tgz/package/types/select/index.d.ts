import type { CompatiblePublicProps } from '../_utils/public-props';
import _Optgroup from './Optgroup.vue';
import _Option from './Option.vue';
import { selectProps, optionProps } from './props';
import { optgroupProps } from './optgroup-props';
import _Select from './select';
declare const Select: import('../_utils/global-config').ComponentWithInstall<typeof _Select & {
    Option: typeof _Option;
    OptGroup: typeof _Optgroup;
}>;
export type SelectInstance = InstanceType<typeof _Select> & import('./types').SelectExpose;
export type OptionInstance = InstanceType<typeof _Option>;
export type OptgroupInstance = InstanceType<typeof _Optgroup>;
export type OptionProps = CompatiblePublicProps<typeof optionProps>;
export type OptgroupProps = CompatiblePublicProps<typeof optgroupProps>;
export { optgroupProps };
export { selectProps, optionProps };
export type { SelectOptionsLoader, SelectValue, SelectEmptyValue, OptionSearchField, SelectOption, SelectOptionData, SelectOptionTagProps, SelectOptionGroup, SelectFieldNames, FilterOption, } from './types';
export type { SelectProps, SelectEditMode } from './props';
export { Select, _Option as Option, _Optgroup as Optgroup };
export declare const _SelectComponent: typeof Select;
export declare const _OptionComponent: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    internal: BooleanConstructor;
    value: {
        type: (BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[];
        default: undefined;
    };
    label: StringConstructor;
    disabled: BooleanConstructor;
    tagProps: {
        type: import("vue").PropType<import("./types").SelectOptionTagProps>;
    };
    index: {
        type: NumberConstructor;
    };
}>, {
    optionId: import("vue").ComputedRef<string | undefined>;
    prefixCls: string;
    cls: import("vue").ComputedRef<(string | {
        [x: string]: boolean | undefined;
    })[]>;
    selectCtx: import("./context.ts").SelectContext | undefined;
    itemRef: import("vue").Ref<HTMLElement | undefined>;
    component: import("vue").ComputedRef<string>;
    isSelected: import("vue").ComputedRef<boolean>;
    isValid: import("vue").ComputedRef<boolean>;
    handleClick: (ev: MouseEvent) => void;
    handleMouseEnter: () => void;
    handleMouseLeave: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    internal: BooleanConstructor;
    value: {
        type: (BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[];
        default: undefined;
    };
    label: StringConstructor;
    disabled: BooleanConstructor;
    tagProps: {
        type: import("vue").PropType<import("./types").SelectOptionTagProps>;
    };
    index: {
        type: NumberConstructor;
    };
}>> & Readonly<{}>, {
    value: string | number | boolean | Record<string, any>;
    disabled: boolean;
    internal: boolean;
}>;
export declare const _OptgroupComponent: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    label: {
        type: StringConstructor;
    };
}>, {
    prefixCls: string;
    titleId: string;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    label: {
        type: StringConstructor;
    };
}>> & Readonly<{}>, {}>;
export default Select;
export type { SelectEmits, SelectSlots, SelectExpose } from './types';
export type { SelectTriggerOptions } from './trigger-options';
