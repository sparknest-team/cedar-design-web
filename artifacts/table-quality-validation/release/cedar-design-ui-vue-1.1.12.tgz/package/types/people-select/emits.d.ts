import type { PeopleSelectValue } from './types';
export declare const peopleSelectEmits: {
    'update:modelValue': (value: PeopleSelectValue) => boolean;
    'update:open': (open: boolean) => boolean;
    'open-change': (open: boolean) => boolean;
    change: (value: PeopleSelectValue) => boolean;
    clear: () => boolean;
    search: (query: string) => boolean;
    'load-error': (_error: unknown, source: "options") => boolean;
    'action-error': (_error: unknown, action: "call" | "chat") => boolean;
};
