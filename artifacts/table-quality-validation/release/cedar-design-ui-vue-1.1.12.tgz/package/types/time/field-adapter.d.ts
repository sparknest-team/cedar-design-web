import type { FieldPresentationAdapter } from '../_components/field-presentation/with-field-presentation';
export declare function timeFieldAdapter(range: boolean): FieldPresentationAdapter;
