/** Resolve endpoint labels without mutating caller-owned arrays or losing explicit empty text. */
export declare function resolveTimeFieldPlaceholders(value: string | string[] | undefined, fallback: string | string[], range: boolean): string[];
