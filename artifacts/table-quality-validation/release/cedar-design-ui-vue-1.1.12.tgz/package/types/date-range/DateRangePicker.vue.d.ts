declare var __VLS_16: string | number, __VLS_17: any;
type __VLS_Slots = {} & {
    [K in NonNullable<typeof __VLS_16>]?: (props: typeof __VLS_17) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    disabled: {
        type: import("vue").PropType<boolean | boolean[]>;
        default: boolean;
    };
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<(import("./index.ts").DateValue | undefined)[] | undefined>>;
        default: undefined;
    };
    modelValue: import("vue").PropType<(import("./index.ts").DateValue | undefined)[] | null>;
    defaultValue: import("vue").PropType<(import("./index.ts").DateValue | undefined)[]>;
    exchangeTime: {
        type: BooleanConstructor;
        default: boolean;
    };
    readonly: BooleanConstructor;
    dayStartOfWeek: {
        type: import("vue").PropType<import("../index.ts").DateWeekStart>;
        default: number;
        validator: (value: number) => boolean;
    };
    timePickerProps: {
        type: import("vue").PropType<import("./index.ts").DateTimePickerOptions>;
    };
    abbreviation: {
        type: BooleanConstructor;
        default: boolean;
    };
    showCurrent: {
        type: BooleanConstructor;
        default: boolean;
    };
    shortcuts: {
        type: import("vue").PropType<import("../index.ts").DateShortcut[]>;
        default: () => never[];
    };
    shortcutsPosition: {
        type: import("vue").PropType<import("../index.ts").DateShortcutsPosition>;
        default: string;
    };
    previewShortcut: {
        type: BooleanConstructor;
        default: boolean;
    };
    pickerValue: import("vue").PropType<import("./index.ts").DateSelection>;
    defaultPickerValue: import("vue").PropType<import("./index.ts").DateSelection>;
    type: {
        type: import("vue").PropType<import("../date/date-format.ts").DateFormatMode>;
        default: string;
        validator: (value: string) => boolean;
    };
    timeZone: StringConstructor;
    showTime: BooleanConstructor;
    format: import("vue").PropType<import("./index.ts").DateValueOptions["format"]>;
    valueFormat: StringConstructor;
    min: import("vue").PropType<import("./index.ts").DateValue>;
    max: import("vue").PropType<import("./index.ts").DateValue>;
    disabledDate: import("vue").PropType<import("./index.ts").DateRules["disabledDate"]>;
    disabledTime: import("vue").PropType<import("./index.ts").DateRules["disabledTime"]>;
    disableConfirm: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    select: (value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any;
    change: (value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any;
    confirm: (value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any;
    "update:modelValue": (value: import("./index.ts").DateSelection) => any;
    "select-shortcut": (shortcut: import("../index.ts").DateShortcut) => any;
    "picker-value-change": (value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any;
    "update:pickerValue": (value: import("./index.ts").DateSelection) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    disabled: {
        type: import("vue").PropType<boolean | boolean[]>;
        default: boolean;
    };
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<(import("./index.ts").DateValue | undefined)[] | undefined>>;
        default: undefined;
    };
    modelValue: import("vue").PropType<(import("./index.ts").DateValue | undefined)[] | null>;
    defaultValue: import("vue").PropType<(import("./index.ts").DateValue | undefined)[]>;
    exchangeTime: {
        type: BooleanConstructor;
        default: boolean;
    };
    readonly: BooleanConstructor;
    dayStartOfWeek: {
        type: import("vue").PropType<import("../index.ts").DateWeekStart>;
        default: number;
        validator: (value: number) => boolean;
    };
    timePickerProps: {
        type: import("vue").PropType<import("./index.ts").DateTimePickerOptions>;
    };
    abbreviation: {
        type: BooleanConstructor;
        default: boolean;
    };
    showCurrent: {
        type: BooleanConstructor;
        default: boolean;
    };
    shortcuts: {
        type: import("vue").PropType<import("../index.ts").DateShortcut[]>;
        default: () => never[];
    };
    shortcutsPosition: {
        type: import("vue").PropType<import("../index.ts").DateShortcutsPosition>;
        default: string;
    };
    previewShortcut: {
        type: BooleanConstructor;
        default: boolean;
    };
    pickerValue: import("vue").PropType<import("./index.ts").DateSelection>;
    defaultPickerValue: import("vue").PropType<import("./index.ts").DateSelection>;
    type: {
        type: import("vue").PropType<import("../date/date-format.ts").DateFormatMode>;
        default: string;
        validator: (value: string) => boolean;
    };
    timeZone: StringConstructor;
    showTime: BooleanConstructor;
    format: import("vue").PropType<import("./index.ts").DateValueOptions["format"]>;
    valueFormat: StringConstructor;
    min: import("vue").PropType<import("./index.ts").DateValue>;
    max: import("vue").PropType<import("./index.ts").DateValue>;
    disabledDate: import("vue").PropType<import("./index.ts").DateRules["disabledDate"]>;
    disabledTime: import("vue").PropType<import("./index.ts").DateRules["disabledTime"]>;
    disableConfirm: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    onSelect?: ((value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any) | undefined;
    onChange?: ((value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any) | undefined;
    onConfirm?: ((value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any) | undefined;
    "onUpdate:modelValue"?: ((value: import("./index.ts").DateSelection) => any) | undefined;
    "onSelect-shortcut"?: ((shortcut: import("../index.ts").DateShortcut) => any) | undefined;
    "onPicker-value-change"?: ((value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any) | undefined;
    "onUpdate:pickerValue"?: ((value: import("./index.ts").DateSelection) => any) | undefined;
}>, {
    readonly: boolean;
    type: import("../date/date-format.ts").DateFormatMode;
    disabled: boolean | boolean[];
    emptyValue: import("../_utils/empty-value.ts").EmptyValue<(import("./index.ts").DateValue | undefined)[] | undefined>;
    disableConfirm: boolean;
    dayStartOfWeek: import("../index.ts").DateWeekStart;
    showTime: boolean;
    shortcuts: import("../index.ts").DateShortcut[];
    abbreviation: boolean;
    showCurrent: boolean;
    exchangeTime: boolean;
    shortcutsPosition: import("../index.ts").DateShortcutsPosition;
    previewShortcut: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
