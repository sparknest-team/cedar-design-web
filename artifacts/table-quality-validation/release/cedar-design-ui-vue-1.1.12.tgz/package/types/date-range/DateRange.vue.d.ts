declare var __VLS_22: string | number, __VLS_23: any;
type __VLS_Slots = {} & {
    [K in NonNullable<typeof __VLS_22>]?: (props: typeof __VLS_23) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: BooleanConstructor;
    disableConfirm: BooleanConstructor;
    popupContainer: {
        type: import("vue").PropType<import("../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    popupProps: {
        type: import("vue").PropType<Record<string, unknown> & {
            popupContainer?: import("../index.ts").PopupContainer;
        }>;
        default: () => {};
    };
    dateRangePickerProps: {
        type: import("vue").PropType<import("./picker-props.ts").DateRangePickerOptions>;
        default: () => {};
    };
    timePickerProps: {
        type: import("vue").PropType<import("./index.ts").DateTimePickerOptions>;
        default: () => {};
    };
    inputEditable: {
        type: BooleanConstructor;
        default: boolean;
    };
    disabled: {
        type: import("vue").PropType<boolean | boolean[]>;
        default: undefined;
    };
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    error: {
        type: BooleanConstructor;
        default: undefined;
    };
    clearable: {
        type: BooleanConstructor;
        default: boolean;
    };
    placeholder: import("vue").PropType<string | string[]>;
    separator: {
        type: StringConstructor;
        default: string;
    };
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
        default: string;
        validator: (value: import("../index.ts").ComponentSize) => boolean;
    };
    variant: {
        default: string;
        type: import("vue").PropType<import("../index.ts").FieldDecoratorVariant>;
        validator: (value: import("../index.ts").FieldDecoratorVariant) => boolean;
    };
    hint: {
        type: BooleanConstructor;
        default: boolean;
    };
    line: {
        type: BooleanConstructor;
        default: boolean;
    };
    textColor: StringConstructor;
    focusColor: StringConstructor;
    blurColor: StringConstructor;
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<(import("./index.ts").DateValue | undefined)[] | undefined>>;
        default: undefined;
    };
    modelValue: import("vue").PropType<(import("./index.ts").DateValue | undefined)[] | null>;
    defaultValue: import("vue").PropType<(import("./index.ts").DateValue | undefined)[]>;
    type: {
        type: import("vue").PropType<import("../date/date-format.ts").DateFormatMode>;
        default: string;
        validator: (value: string) => boolean;
    };
    timeZone: StringConstructor;
    showTime: BooleanConstructor;
    format: import("vue").PropType<import("./index.ts").DateValueOptions["format"]>;
    valueFormat: StringConstructor;
    min: import("vue").PropType<import("./index.ts").DateValue>;
    max: import("vue").PropType<import("./index.ts").DateValue>;
    disabledDate: import("vue").PropType<import("./index.ts").DateRules["disabledDate"]>;
    disabledTime: import("vue").PropType<import("./index.ts").DateRules["disabledTime"]>;
    editMode: {
        type: import("vue").PropType<import("../index.ts").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
    beforeCommit: import("vue").PropType<import("../index.ts").BeforeFieldCommit>;
    inputAttrs: {
        type: import("vue").PropType<import("./index.ts").RangeInputAttributes[]>;
        default: undefined;
    };
    openTriggerTarget: {
        type: import("vue").PropType<import("../index.ts").OpenTriggerTarget>;
        default: "field";
        validator: (value: string) => value is "icon" | "field";
    };
    loading: BooleanConstructor;
    loadingMode: {
        type: import("vue").PropType<import("../index.ts").FieldLoadingMode>;
        default: string;
        validator: (value: import("../index.ts").FieldLoadingMode) => boolean;
    };
}>, {
    focus: (index?: number) => void | undefined;
    blur: () => void | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    click: (event: Event) => any;
    focus: () => any;
    clear: () => any;
    select: (value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any;
    blur: () => any;
    change: (value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any;
    "update:open": (open: boolean) => any;
    "open-change": (open: boolean) => any;
    "update:modelValue": (value: import("./index.ts").DateSelection) => any;
    "select-shortcut": (shortcut: import("../index.ts").DateShortcut) => any;
    "picker-value-change": (value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any;
    "update:pickerValue": (value: import("./index.ts").DateSelection) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: BooleanConstructor;
    disableConfirm: BooleanConstructor;
    popupContainer: {
        type: import("vue").PropType<import("../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    popupProps: {
        type: import("vue").PropType<Record<string, unknown> & {
            popupContainer?: import("../index.ts").PopupContainer;
        }>;
        default: () => {};
    };
    dateRangePickerProps: {
        type: import("vue").PropType<import("./picker-props.ts").DateRangePickerOptions>;
        default: () => {};
    };
    timePickerProps: {
        type: import("vue").PropType<import("./index.ts").DateTimePickerOptions>;
        default: () => {};
    };
    inputEditable: {
        type: BooleanConstructor;
        default: boolean;
    };
    disabled: {
        type: import("vue").PropType<boolean | boolean[]>;
        default: undefined;
    };
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    error: {
        type: BooleanConstructor;
        default: undefined;
    };
    clearable: {
        type: BooleanConstructor;
        default: boolean;
    };
    placeholder: import("vue").PropType<string | string[]>;
    separator: {
        type: StringConstructor;
        default: string;
    };
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
        default: string;
        validator: (value: import("../index.ts").ComponentSize) => boolean;
    };
    variant: {
        default: string;
        type: import("vue").PropType<import("../index.ts").FieldDecoratorVariant>;
        validator: (value: import("../index.ts").FieldDecoratorVariant) => boolean;
    };
    hint: {
        type: BooleanConstructor;
        default: boolean;
    };
    line: {
        type: BooleanConstructor;
        default: boolean;
    };
    textColor: StringConstructor;
    focusColor: StringConstructor;
    blurColor: StringConstructor;
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<(import("./index.ts").DateValue | undefined)[] | undefined>>;
        default: undefined;
    };
    modelValue: import("vue").PropType<(import("./index.ts").DateValue | undefined)[] | null>;
    defaultValue: import("vue").PropType<(import("./index.ts").DateValue | undefined)[]>;
    type: {
        type: import("vue").PropType<import("../date/date-format.ts").DateFormatMode>;
        default: string;
        validator: (value: string) => boolean;
    };
    timeZone: StringConstructor;
    showTime: BooleanConstructor;
    format: import("vue").PropType<import("./index.ts").DateValueOptions["format"]>;
    valueFormat: StringConstructor;
    min: import("vue").PropType<import("./index.ts").DateValue>;
    max: import("vue").PropType<import("./index.ts").DateValue>;
    disabledDate: import("vue").PropType<import("./index.ts").DateRules["disabledDate"]>;
    disabledTime: import("vue").PropType<import("./index.ts").DateRules["disabledTime"]>;
    editMode: {
        type: import("vue").PropType<import("../index.ts").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
    beforeCommit: import("vue").PropType<import("../index.ts").BeforeFieldCommit>;
    inputAttrs: {
        type: import("vue").PropType<import("./index.ts").RangeInputAttributes[]>;
        default: undefined;
    };
    openTriggerTarget: {
        type: import("vue").PropType<import("../index.ts").OpenTriggerTarget>;
        default: "field";
        validator: (value: string) => value is "icon" | "field";
    };
    loading: BooleanConstructor;
    loadingMode: {
        type: import("vue").PropType<import("../index.ts").FieldLoadingMode>;
        default: string;
        validator: (value: import("../index.ts").FieldLoadingMode) => boolean;
    };
}>> & Readonly<{
    onClick?: ((event: Event) => any) | undefined;
    onFocus?: (() => any) | undefined;
    onClear?: (() => any) | undefined;
    onSelect?: ((value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any) | undefined;
    onBlur?: (() => any) | undefined;
    onChange?: ((value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any) | undefined;
    "onUpdate:open"?: ((open: boolean) => any) | undefined;
    "onOpen-change"?: ((open: boolean) => any) | undefined;
    "onUpdate:modelValue"?: ((value: import("./index.ts").DateSelection) => any) | undefined;
    "onSelect-shortcut"?: ((shortcut: import("../index.ts").DateShortcut) => any) | undefined;
    "onPicker-value-change"?: ((value: import("./index.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any) | undefined;
    "onUpdate:pickerValue"?: ((value: import("./index.ts").DateSelection) => any) | undefined;
}>, {
    error: boolean;
    readonly: boolean;
    size: "xs" | "sm" | "md" | "lg" | "xl";
    type: import("../date/date-format.ts").DateFormatMode;
    line: boolean;
    disabled: boolean | boolean[];
    variant: "outline" | "standard" | "filled";
    loading: boolean;
    editMode: import("../index.ts").FieldEditMode;
    readPretty: boolean;
    loadingMode: "default" | "line";
    hint: boolean;
    clearable: boolean;
    emptyValue: import("../_utils/empty-value.ts").EmptyValue<(import("./index.ts").DateValue | undefined)[] | undefined>;
    emptyValues: readonly unknown[];
    emptyText: string;
    popupContainer: import("../index.ts").PopupContainer;
    open: boolean;
    defaultOpen: boolean;
    inputAttrs: import("./index.ts").RangeInputAttributes[];
    separator: string;
    openTriggerTarget: import("../index.ts").OpenTriggerTarget;
    disableConfirm: boolean;
    showTime: boolean;
    timePickerProps: import("./index.ts").DateTimePickerOptions;
    inputEditable: boolean;
    popupProps: Record<string, unknown> & {
        popupContainer?: import("../index.ts").PopupContainer;
    };
    dateRangePickerProps: import("./picker-props.ts").DateRangePickerOptions;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
