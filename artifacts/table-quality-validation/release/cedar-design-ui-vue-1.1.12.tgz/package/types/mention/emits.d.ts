import type { SelectOptionValue } from '../select/types';
export declare const mentionEmits: {
    'load-error': (error: unknown) => boolean;
    'update:modelValue': (value: string | null) => boolean;
    change: (value: string | null) => boolean;
    search: (query: string, prefix: string) => boolean;
    select: (value: SelectOptionValue | undefined) => boolean;
    clear: (event: Event) => boolean;
    focus: (event: FocusEvent) => boolean;
    blur: (event: FocusEvent) => boolean;
};
