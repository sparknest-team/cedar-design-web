import _Alert from './Alert.vue';
import { alertProps } from './props';
declare const Alert: import('../_utils/global-config').ComponentWithInstall<typeof _Alert>;
export type AlertInstance = InstanceType<typeof _Alert>;
export type { AlertProps, AlertStatus, AlertVariant } from './props';
export { alertProps };
export { Alert };
export declare const _AlertComponent: typeof Alert;
export default Alert;
