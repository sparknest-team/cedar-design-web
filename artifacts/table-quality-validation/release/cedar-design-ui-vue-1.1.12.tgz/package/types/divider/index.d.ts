import _Divider from './Divider.vue';
import { dividerProps } from './props';
declare const Divider: import('../_utils/global-config').ComponentWithInstall<typeof _Divider>;
export type DividerInstance = InstanceType<typeof _Divider>;
export type { DividerProps, DividerOrientation, DividerTextAlign, DividerType, DividerSize, DividerSizePreset } from './props';
export { dividerProps };
export { Divider };
export declare const _DividerComponent: typeof Divider;
export default Divider;
