import { type DividerSize } from "./props";
declare var __VLS_1: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    inset: {
        type: import("vue").PropType<DividerSize>;
        validator: typeof import("./props").isValidDividerSize | undefined;
    };
    spacing: {
        type: import("vue").PropType<DividerSize>;
        validator: typeof import("./props").isValidDividerSize | undefined;
        default: string;
    };
    orientation: {
        type: import("vue").PropType<import("./props").DividerOrientation>;
        default: string;
        validator: ((value: unknown) => boolean) | undefined;
    };
    textAlign: {
        type: import("vue").PropType<import("./props").DividerTextAlign>;
        default: string;
        validator: ((value: unknown) => boolean) | undefined;
    };
    description: StringConstructor;
    type: {
        type: import("vue").PropType<import("./props").DividerType>;
        default: string;
        validator: ((value: unknown) => boolean) | undefined;
    };
    hairline: BooleanConstructor;
    thickness: {
        type: NumberConstructor;
        validator: ((value: unknown) => value is number) | undefined;
    };
    color: StringConstructor;
    opacity: {
        type: NumberConstructor;
        validator: ((value: unknown) => value is number) | undefined;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    inset: {
        type: import("vue").PropType<DividerSize>;
        validator: typeof import("./props").isValidDividerSize | undefined;
    };
    spacing: {
        type: import("vue").PropType<DividerSize>;
        validator: typeof import("./props").isValidDividerSize | undefined;
        default: string;
    };
    orientation: {
        type: import("vue").PropType<import("./props").DividerOrientation>;
        default: string;
        validator: ((value: unknown) => boolean) | undefined;
    };
    textAlign: {
        type: import("vue").PropType<import("./props").DividerTextAlign>;
        default: string;
        validator: ((value: unknown) => boolean) | undefined;
    };
    description: StringConstructor;
    type: {
        type: import("vue").PropType<import("./props").DividerType>;
        default: string;
        validator: ((value: unknown) => boolean) | undefined;
    };
    hairline: BooleanConstructor;
    thickness: {
        type: NumberConstructor;
        validator: ((value: unknown) => value is number) | undefined;
    };
    color: StringConstructor;
    opacity: {
        type: NumberConstructor;
        validator: ((value: unknown) => value is number) | undefined;
    };
}>> & Readonly<{}>, {
    type: import("./props").DividerType;
    textAlign: import("./props").DividerTextAlign;
    orientation: "horizontal" | "vertical";
    spacing: DividerSize;
    hairline: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
