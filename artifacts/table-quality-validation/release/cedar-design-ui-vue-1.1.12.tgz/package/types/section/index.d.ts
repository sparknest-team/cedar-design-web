import { type ComponentWithInstall } from '../_utils/global-config';
import _Section from './Section.vue';
export declare const Section: ComponentWithInstall<typeof _Section>;
export declare const _SectionComponent: typeof Section;
export type SectionInstance = InstanceType<typeof _Section>;
export { sectionProps } from './props';
export type { SectionProps, SectionSlots, SectionVariant, SectionHeadingLevel } from './props';
export default Section;
