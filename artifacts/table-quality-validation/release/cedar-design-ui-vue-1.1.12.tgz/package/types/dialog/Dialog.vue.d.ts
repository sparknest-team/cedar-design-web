import { type CSSProperties } from 'vue';
import type { DialogAction } from "./types";
declare function handleClose(event?: Event): void;
declare function handleConfirm(event?: Event): void;
declare function handleCancel(event?: Event): void;
declare var __VLS_34: {}, __VLS_46: {}, __VLS_48: {
    cancel: typeof handleCancel;
    confirm: typeof handleConfirm;
    close: typeof handleClose;
};
type __VLS_Slots = {} & {
    title?: (props: typeof __VLS_34) => any;
} & {
    default?: (props: typeof __VLS_46) => any;
} & {
    footer?: (props: typeof __VLS_48) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    topDivider: {
        type: BooleanConstructor;
        default: boolean;
    };
    bottomDivider: {
        type: BooleanConstructor;
        default: boolean;
    };
    dir: {
        type: import("vue").PropType<import("@cedar-design/use-vue").ReadingDirection>;
    };
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: {
        type: BooleanConstructor;
        default: boolean;
    };
    width: {
        type: (StringConstructor | NumberConstructor)[];
    };
    top: {
        type: (StringConstructor | NumberConstructor)[];
    };
    overlay: {
        type: BooleanConstructor;
        default: boolean;
    };
    overlayClass: StringConstructor;
    overlayStyle: {
        type: import("vue").PropType<import("vue").CSSProperties>;
    };
    title: StringConstructor;
    message: StringConstructor;
    messageAlign: {
        type: import("vue").PropType<"left" | "center" | "right">;
        default: string;
    };
    type: {
        type: import("vue").PropType<import("./types").DialogType>;
    };
    simple: {
        type: BooleanConstructor;
        default: boolean;
    };
    titleAlign: {
        type: import("vue").PropType<"start" | "center">;
        default: string;
    };
    alignCenter: {
        type: BooleanConstructor;
        default: boolean;
    };
    unmountOnClose: BooleanConstructor;
    overlayClosable: {
        type: BooleanConstructor;
        default: boolean;
    };
    escToClose: {
        type: BooleanConstructor;
        default: boolean;
    };
    lockScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    closeOnRouteChange: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButton: {
        type: BooleanConstructor;
        default: boolean;
    };
    cancelButton: {
        type: BooleanConstructor;
        default: boolean;
    };
    closable: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButtonText: StringConstructor;
    cancelButtonText: StringConstructor;
    confirmButtonLoading: {
        type: BooleanConstructor;
        default: boolean;
    };
    cancelButtonLoading: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButtonDisabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    cancelButtonDisabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButtonProps: {
        type: import("vue").PropType<import("../index.ts").ButtonProps>;
    };
    cancelButtonProps: {
        type: import("vue").PropType<import("../index.ts").ButtonProps>;
    };
    footer: {
        type: BooleanConstructor;
        default: boolean;
    };
    popupContainer: {
        type: import("vue").PropType<import("../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    dialogClass: {
        type: import("vue").PropType<string | any[]>;
    };
    dialogStyle: {
        type: import("vue").PropType<import("vue").CSSProperties>;
    };
    beforeClose: {
        type: import("vue").PropType<import("./types").DialogBeforeClose>;
    };
    draggable: {
        type: BooleanConstructor;
        default: boolean;
    };
    fullscreen: {
        type: BooleanConstructor;
        default: boolean;
    };
    overlayAnimationName: {
        type: StringConstructor;
        default: (props: Record<string, any>) => "fade-in-standard" | "fade-modal";
    };
    dialogAnimationName: {
        type: StringConstructor;
        default: (props: Record<string, any>) => "zoom-in" | "zoom-modal";
    };
    bodyClass: {
        type: import("vue").PropType<string | any[]>;
    };
    bodyStyle: {
        type: import("vue").PropType<import("../_utils/style-value.ts").CompatibleStyleValue>;
    };
    hideTitle: {
        type: BooleanConstructor;
        default: boolean;
    };
    ariaLabel: StringConstructor;
    closeButtonAriaLabel: {
        type: StringConstructor;
        default: string;
    };
    zIndex: NumberConstructor;
}>, {
    close: () => void;
    confirm: typeof handleConfirm;
    cancel: typeof handleCancel;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "guard-error": (error: unknown, action: DialogAction) => void;
    "update:open": (value: boolean) => void;
    close: () => void;
    closed: () => void;
    open: () => void;
    opened: () => void;
    cancel: (value: Event) => void;
    confirm: (value: Event) => void;
    "click-overlay": (value: MouseEvent) => void;
    "key-escape": (value: KeyboardEvent) => void;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    topDivider: {
        type: BooleanConstructor;
        default: boolean;
    };
    bottomDivider: {
        type: BooleanConstructor;
        default: boolean;
    };
    dir: {
        type: import("vue").PropType<import("@cedar-design/use-vue").ReadingDirection>;
    };
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: {
        type: BooleanConstructor;
        default: boolean;
    };
    width: {
        type: (StringConstructor | NumberConstructor)[];
    };
    top: {
        type: (StringConstructor | NumberConstructor)[];
    };
    overlay: {
        type: BooleanConstructor;
        default: boolean;
    };
    overlayClass: StringConstructor;
    overlayStyle: {
        type: import("vue").PropType<import("vue").CSSProperties>;
    };
    title: StringConstructor;
    message: StringConstructor;
    messageAlign: {
        type: import("vue").PropType<"left" | "center" | "right">;
        default: string;
    };
    type: {
        type: import("vue").PropType<import("./types").DialogType>;
    };
    simple: {
        type: BooleanConstructor;
        default: boolean;
    };
    titleAlign: {
        type: import("vue").PropType<"start" | "center">;
        default: string;
    };
    alignCenter: {
        type: BooleanConstructor;
        default: boolean;
    };
    unmountOnClose: BooleanConstructor;
    overlayClosable: {
        type: BooleanConstructor;
        default: boolean;
    };
    escToClose: {
        type: BooleanConstructor;
        default: boolean;
    };
    lockScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    closeOnRouteChange: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButton: {
        type: BooleanConstructor;
        default: boolean;
    };
    cancelButton: {
        type: BooleanConstructor;
        default: boolean;
    };
    closable: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButtonText: StringConstructor;
    cancelButtonText: StringConstructor;
    confirmButtonLoading: {
        type: BooleanConstructor;
        default: boolean;
    };
    cancelButtonLoading: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButtonDisabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    cancelButtonDisabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    confirmButtonProps: {
        type: import("vue").PropType<import("../index.ts").ButtonProps>;
    };
    cancelButtonProps: {
        type: import("vue").PropType<import("../index.ts").ButtonProps>;
    };
    footer: {
        type: BooleanConstructor;
        default: boolean;
    };
    popupContainer: {
        type: import("vue").PropType<import("../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    dialogClass: {
        type: import("vue").PropType<string | any[]>;
    };
    dialogStyle: {
        type: import("vue").PropType<import("vue").CSSProperties>;
    };
    beforeClose: {
        type: import("vue").PropType<import("./types").DialogBeforeClose>;
    };
    draggable: {
        type: BooleanConstructor;
        default: boolean;
    };
    fullscreen: {
        type: BooleanConstructor;
        default: boolean;
    };
    overlayAnimationName: {
        type: StringConstructor;
        default: (props: Record<string, any>) => "fade-in-standard" | "fade-modal";
    };
    dialogAnimationName: {
        type: StringConstructor;
        default: (props: Record<string, any>) => "zoom-in" | "zoom-modal";
    };
    bodyClass: {
        type: import("vue").PropType<string | any[]>;
    };
    bodyStyle: {
        type: import("vue").PropType<import("../_utils/style-value.ts").CompatibleStyleValue>;
    };
    hideTitle: {
        type: BooleanConstructor;
        default: boolean;
    };
    ariaLabel: StringConstructor;
    closeButtonAriaLabel: {
        type: StringConstructor;
        default: string;
    };
    zIndex: NumberConstructor;
}>> & Readonly<{
    onCancel?: ((value: Event) => any) | undefined;
    onClose?: (() => any) | undefined;
    onClosed?: (() => any) | undefined;
    onOpen?: (() => any) | undefined;
    onConfirm?: ((value: Event) => any) | undefined;
    "onUpdate:open"?: ((value: boolean) => any) | undefined;
    onOpened?: (() => any) | undefined;
    "onKey-escape"?: ((value: KeyboardEvent) => any) | undefined;
    "onClick-overlay"?: ((value: MouseEvent) => any) | undefined;
    "onGuard-error"?: ((error: unknown, action: DialogAction) => any) | undefined;
}>, {
    closable: boolean;
    footer: boolean;
    overlay: boolean;
    popupContainer: import("../index.ts").PopupContainer;
    open: boolean;
    defaultOpen: boolean;
    unmountOnClose: boolean;
    escToClose: boolean;
    draggable: boolean;
    closeButtonAriaLabel: string;
    topDivider: boolean;
    bottomDivider: boolean;
    messageAlign: "left" | "right" | "center";
    simple: boolean;
    confirmButton: boolean;
    cancelButton: boolean;
    confirmButtonLoading: boolean;
    cancelButtonLoading: boolean;
    confirmButtonDisabled: boolean;
    cancelButtonDisabled: boolean;
    lockScroll: boolean;
    closeOnRouteChange: boolean;
    overlayClosable: boolean;
    alignCenter: boolean;
    fullscreen: boolean;
    titleAlign: "center" | "start";
    overlayAnimationName: string;
    dialogAnimationName: string;
    hideTitle: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
