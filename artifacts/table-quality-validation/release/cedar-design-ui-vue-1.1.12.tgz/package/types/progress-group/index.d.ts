import _ProgressGroup from './ProgressGroup.vue';
import { progressGroupProps } from './props';
declare const ProgressGroup: import('../_utils/global-config').ComponentWithInstall<typeof _ProgressGroup>;
export type ProgressGroupInstance = InstanceType<typeof _ProgressGroup>;
export type { ProgressGroupItem, ProgressGroupMode, ProgressGroupOrientation, ProgressGroupProps } from './props';
export { ProgressGroup, progressGroupProps };
export declare const _ProgressGroupComponent: typeof ProgressGroup;
export default ProgressGroup;
