declare const _default: import("vue").DefineComponent<{}, {
    svgPrefix: string;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<{}> & Readonly<{}>, {}>;
export default _default;
