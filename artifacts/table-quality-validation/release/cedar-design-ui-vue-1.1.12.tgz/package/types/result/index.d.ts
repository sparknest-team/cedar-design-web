import _Result from './Result.vue';
import { resultProps } from './props';
declare const Result: import('../_utils/global-config').ComponentWithInstall<typeof _Result>;
export type ResultInstance = InstanceType<typeof _Result>;
export { resultProps };
export type { ResultProps, ResultStatus } from './props';
export { Result };
export declare const _ResultComponent: typeof Result;
export default Result;
