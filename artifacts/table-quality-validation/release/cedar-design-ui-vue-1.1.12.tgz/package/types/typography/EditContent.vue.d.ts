declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    text: {
        type: StringConstructor;
        required: true;
    };
    inputAttrs: {
        type: ObjectConstructor;
        default: () => {};
    };
}>, {
    classNames: string[];
    inputRef: import("vue").Ref<import("../_utils/global-config").CedarComponentWithInstall<{
        new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
            emptyValue: {
                type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<string>>;
                default: undefined;
            };
            editMode: {
                type: import("vue").PropType<import("../index.ts").FieldEditMode>;
                default: undefined;
                validator: (value: string) => boolean;
            };
            readPretty: {
                type: BooleanConstructor;
                default: undefined;
            };
            emptyValues: {
                type: import("vue").PropType<readonly unknown[]>;
                default: undefined;
            };
            emptyText: {
                type: StringConstructor;
                default: undefined;
            };
            beforeCommit: import("vue").PropType<import("../index.ts").BeforeFieldCommit>;
            popupContainer: {
                type: import("vue").PropType<import("../index.ts").PopupContainer>;
                default: undefined;
                validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
            };
            open: {
                type: BooleanConstructor;
                default: undefined;
            };
            defaultOpen: BooleanConstructor;
            modelValue: import("vue").PropType<string | null>;
            modelModifiers: {
                type: import("vue").PropType<{
                    trim?: boolean;
                }>;
                default: () => {};
            };
            defaultValue: {
                type: StringConstructor;
                default: string;
            };
            type: {
                type: import("vue").PropType<import("../input").InputType>;
                default: string;
                validator: (value: import("../input").InputType) => boolean;
            };
            size: {
                type: import("vue").PropType<import("../index.ts").ComponentSize>;
                validator: (value: import("../index.ts").ComponentSize) => boolean;
            };
            variant: {
                type: import("vue").PropType<import("../input").InputVariant>;
                validator: (value: import("../input").InputVariant) => boolean;
            };
            clearable: {
                type: BooleanConstructor;
                default: boolean;
            };
            disabled: {
                type: BooleanConstructor;
                default: undefined;
            };
            readonly: {
                type: BooleanConstructor;
                default: undefined;
            };
            error: {
                type: BooleanConstructor;
                default: undefined;
            };
            placeholder: StringConstructor;
            hint: {
                type: BooleanConstructor;
                default: undefined;
            };
            line: {
                type: BooleanConstructor;
                default: boolean;
            };
            textColor: StringConstructor;
            focusColor: StringConstructor;
            blurColor: StringConstructor;
            ariaLabel: StringConstructor;
            autofocus: BooleanConstructor;
            enterkeyhint: import("vue").PropType<"enter" | "done" | "go" | "next" | "previous" | "search" | "send">;
            maxLength: {
                type: import("vue").PropType<import("../input").InputMaxLength>;
                default: number;
                validator: typeof import("../_utils/text-input-value.ts").isValidTextInputMaxLength;
            };
            showWordLimit: {
                type: BooleanConstructor;
                default: boolean;
            };
            wordLength: import("vue").PropType<import("../input").WordLength>;
            wordSlice: import("vue").PropType<import("../input").WordSlice>;
            inputAttrs: import("vue").PropType<Record<string, unknown>>;
            loading: BooleanConstructor;
            loadingMode: {
                type: import("vue").PropType<import("../index.ts").FieldLoadingMode>;
                default: string;
                validator: (value: import("../index.ts").FieldLoadingMode) => boolean;
            };
        }>> & Readonly<{
            onClick?: ((originalEvent: MouseEvent) => any) | undefined;
            onFocus?: ((originalEvent: FocusEvent) => any) | undefined;
            onClear?: ((originalEvent: Event) => any) | undefined;
            onInput?: ((value: string, originalEvent: Event) => any) | undefined;
            onBlur?: ((originalEvent: FocusEvent) => any) | undefined;
            onChange?: ((value: string | null, originalEvent?: Event | undefined) => any) | undefined;
            onKeydown?: ((originalEvent: KeyboardEvent) => any) | undefined;
            "onUpdate:open"?: ((value: boolean) => any) | undefined;
            "onUpdate:modelValue"?: ((value: string | null) => any) | undefined;
            "onPress-enter"?: ((originalEvent: KeyboardEvent) => any) | undefined;
        }>, {
            inputRef: import("vue").Ref<HTMLInputElement | undefined>;
            focus: (options?: FocusOptions) => void;
            blur: () => void;
            select: () => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            click: (originalEvent: MouseEvent) => any;
            focus: (originalEvent: FocusEvent) => any;
            clear: (originalEvent: Event) => any;
            input: (value: string, originalEvent: Event) => any;
            blur: (originalEvent: FocusEvent) => any;
            change: (value: string | null, originalEvent?: Event | undefined) => any;
            keydown: (originalEvent: KeyboardEvent) => any;
            "update:open": (value: boolean) => any;
            "update:modelValue": (value: string | null) => any;
            "press-enter": (originalEvent: KeyboardEvent) => any;
        }, import("../vue-compat").PublicProps, {
            error: boolean;
            autofocus: boolean;
            readonly: boolean;
            type: "number" | "text" | "password" | "tel" | "email";
            line: boolean;
            disabled: boolean;
            loading: boolean;
            editMode: import("../index.ts").FieldEditMode;
            readPretty: boolean;
            loadingMode: "default" | "line";
            hint: boolean;
            clearable: boolean;
            emptyValue: import("../_utils/empty-value.ts").EmptyValue<string>;
            emptyValues: readonly unknown[];
            emptyText: string;
            popupContainer: import("../index.ts").PopupContainer;
            open: boolean;
            defaultOpen: boolean;
            modelModifiers: {
                trim?: boolean;
            };
            defaultValue: string;
            maxLength: import("../_utils/text-input-value.ts").TextInputMaxLength;
            showWordLimit: boolean;
        }, true>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        emptyValue: {
            type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<string>>;
            default: undefined;
        };
        editMode: {
            type: import("vue").PropType<import("../index.ts").FieldEditMode>;
            default: undefined;
            validator: (value: string) => boolean;
        };
        readPretty: {
            type: BooleanConstructor;
            default: undefined;
        };
        emptyValues: {
            type: import("vue").PropType<readonly unknown[]>;
            default: undefined;
        };
        emptyText: {
            type: StringConstructor;
            default: undefined;
        };
        beforeCommit: import("vue").PropType<import("../index.ts").BeforeFieldCommit>;
        popupContainer: {
            type: import("vue").PropType<import("../index.ts").PopupContainer>;
            default: undefined;
            validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
        };
        open: {
            type: BooleanConstructor;
            default: undefined;
        };
        defaultOpen: BooleanConstructor;
        modelValue: import("vue").PropType<string | null>;
        modelModifiers: {
            type: import("vue").PropType<{
                trim?: boolean;
            }>;
            default: () => {};
        };
        defaultValue: {
            type: StringConstructor;
            default: string;
        };
        type: {
            type: import("vue").PropType<import("../input").InputType>;
            default: string;
            validator: (value: import("../input").InputType) => boolean;
        };
        size: {
            type: import("vue").PropType<import("../index.ts").ComponentSize>;
            validator: (value: import("../index.ts").ComponentSize) => boolean;
        };
        variant: {
            type: import("vue").PropType<import("../input").InputVariant>;
            validator: (value: import("../input").InputVariant) => boolean;
        };
        clearable: {
            type: BooleanConstructor;
            default: boolean;
        };
        disabled: {
            type: BooleanConstructor;
            default: undefined;
        };
        readonly: {
            type: BooleanConstructor;
            default: undefined;
        };
        error: {
            type: BooleanConstructor;
            default: undefined;
        };
        placeholder: StringConstructor;
        hint: {
            type: BooleanConstructor;
            default: undefined;
        };
        line: {
            type: BooleanConstructor;
            default: boolean;
        };
        textColor: StringConstructor;
        focusColor: StringConstructor;
        blurColor: StringConstructor;
        ariaLabel: StringConstructor;
        autofocus: BooleanConstructor;
        enterkeyhint: import("vue").PropType<"enter" | "done" | "go" | "next" | "previous" | "search" | "send">;
        maxLength: {
            type: import("vue").PropType<import("../input").InputMaxLength>;
            default: number;
            validator: typeof import("../_utils/text-input-value.ts").isValidTextInputMaxLength;
        };
        showWordLimit: {
            type: BooleanConstructor;
            default: boolean;
        };
        wordLength: import("vue").PropType<import("../input").WordLength>;
        wordSlice: import("vue").PropType<import("../input").WordSlice>;
        inputAttrs: import("vue").PropType<Record<string, unknown>>;
        loading: BooleanConstructor;
        loadingMode: {
            type: import("vue").PropType<import("../index.ts").FieldLoadingMode>;
            default: string;
            validator: (value: import("../index.ts").FieldLoadingMode) => boolean;
        };
    }>> & Readonly<{
        onClick?: ((originalEvent: MouseEvent) => any) | undefined;
        onFocus?: ((originalEvent: FocusEvent) => any) | undefined;
        onClear?: ((originalEvent: Event) => any) | undefined;
        onInput?: ((value: string, originalEvent: Event) => any) | undefined;
        onBlur?: ((originalEvent: FocusEvent) => any) | undefined;
        onChange?: ((value: string | null, originalEvent?: Event | undefined) => any) | undefined;
        onKeydown?: ((originalEvent: KeyboardEvent) => any) | undefined;
        "onUpdate:open"?: ((value: boolean) => any) | undefined;
        "onUpdate:modelValue"?: ((value: string | null) => any) | undefined;
        "onPress-enter"?: ((originalEvent: KeyboardEvent) => any) | undefined;
    }>, {
        inputRef: import("vue").Ref<HTMLInputElement | undefined>;
        focus: (options?: FocusOptions) => void;
        blur: () => void;
        select: () => void;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        click: (originalEvent: MouseEvent) => any;
        focus: (originalEvent: FocusEvent) => any;
        clear: (originalEvent: Event) => any;
        input: (value: string, originalEvent: Event) => any;
        blur: (originalEvent: FocusEvent) => any;
        change: (value: string | null, originalEvent?: Event | undefined) => any;
        keydown: (originalEvent: KeyboardEvent) => any;
        "update:open": (value: boolean) => any;
        "update:modelValue": (value: string | null) => any;
        "press-enter": (originalEvent: KeyboardEvent) => any;
    }, string, {
        error: boolean;
        autofocus: boolean;
        readonly: boolean;
        type: "number" | "text" | "password" | "tel" | "email";
        line: boolean;
        disabled: boolean;
        loading: boolean;
        editMode: import("../index.ts").FieldEditMode;
        readPretty: boolean;
        loadingMode: "default" | "line";
        hint: boolean;
        clearable: boolean;
        emptyValue: import("../_utils/empty-value.ts").EmptyValue<string>;
        emptyValues: readonly unknown[];
        emptyText: string;
        popupContainer: import("../index.ts").PopupContainer;
        open: boolean;
        defaultOpen: boolean;
        modelModifiers: {
            trim?: boolean;
        };
        defaultValue: string;
        maxLength: import("../_utils/text-input-value.ts").TextInputMaxLength;
        showWordLimit: boolean;
    }, {}, string> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
        $slots: import("../input").InputSlots;
    }) & {
        setPropsDefaults: (defaults: Record<string, any>) => void;
    } & {
        Password: typeof import("../input").InputPassword;
        Group: typeof import("../input").InputGroup;
        GroupLabel: typeof import("../input").InputGroupLabel;
    }> | undefined>;
    onBlur: () => void;
    onChange: (value: string | null) => void;
    onPressEnter: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("change" | "end" | "update:text")[], "change" | "end" | "update:text", import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    text: {
        type: StringConstructor;
        required: true;
    };
    inputAttrs: {
        type: ObjectConstructor;
        default: () => {};
    };
}>> & Readonly<{
    onChange?: ((...args: any[]) => any) | undefined;
    onEnd?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
}>, {
    inputAttrs: Record<string, any>;
}>;
export default _default;
