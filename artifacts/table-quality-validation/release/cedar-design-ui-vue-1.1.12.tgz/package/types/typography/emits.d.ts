export declare const typographyEmits: {
    'edit-start': () => boolean;
    change: (_text: string) => boolean;
    'update:editText': (_text: string) => boolean;
    'edit-end': () => boolean;
    'update:editing': (_editing: boolean) => boolean;
    copy: (_text: string) => boolean;
    ellipsis: (_isEllipsis: boolean) => boolean;
    expand: (_expanded: boolean) => boolean;
};
