import _Descriptions from './descriptions';
import _DescriptionsItem from './DescriptionsItem.vue';
import { descriptionsItemProps, descriptionsProps } from './props';
declare const Descriptions: import('../_utils/global-config').ComponentWithInstall<typeof _Descriptions & {
    DescriptionsItem: typeof _DescriptionsItem;
}>;
export type DescriptionsInstance = InstanceType<typeof _Descriptions>;
export type DescriptionsItemInstance = InstanceType<typeof _DescriptionsItem>;
export type { DescriptionsAlign, DescriptionsItemProps, DescriptionsProps } from './props';
export type { DescData, DescLayout, DescriptionsSlotScope, DescriptionsSlots, DescriptionsItemSlots } from './types';
export { Descriptions, descriptionsItemProps, descriptionsProps };
export declare const _DescriptionsComponent: typeof Descriptions;
export declare const _DescriptionsItemComponent: typeof _DescriptionsItem;
export { _DescriptionsItem as DescriptionsItem };
export default Descriptions;
