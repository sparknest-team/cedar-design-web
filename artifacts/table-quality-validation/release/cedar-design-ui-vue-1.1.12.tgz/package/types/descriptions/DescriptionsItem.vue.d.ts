declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    span: {
        type: NumberConstructor;
        default: number;
        validator: (value: unknown) => value is number;
    };
    label: StringConstructor;
}>, {
    prefixCls: string;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    span: {
        type: NumberConstructor;
        default: number;
        validator: (value: unknown) => value is number;
    };
    label: StringConstructor;
}>> & Readonly<{}>, {
    span: number;
}>;
export default _default;
