import _Countdown from './Countdown.vue';
import { countdownProps } from './props';
declare const Countdown: import('../_utils/global-config').ComponentWithInstall<typeof _Countdown>;
export type CountdownInstance = InstanceType<typeof _Countdown>;
export type { CountdownProps, TimeData, CountdownSlots, CountdownEvents, CountdownExpose } from './props';
export { countdownProps };
export { Countdown };
export declare const _CountdownComponent: typeof Countdown;
export default Countdown;
