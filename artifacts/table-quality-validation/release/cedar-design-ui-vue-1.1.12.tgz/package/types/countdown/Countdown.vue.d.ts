import { type CountdownSlots } from './props';
type __VLS_Slots = CountdownSlots;
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    time: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    format: {
        type: StringConstructor;
        default: string;
    };
    autoStart: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {
    start: () => void;
    pause: () => void;
    reset: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    change: (time: import("./props").TimeData) => any;
    end: () => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    time: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    format: {
        type: StringConstructor;
        default: string;
    };
    autoStart: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    onChange?: ((time: import("./props").TimeData) => any) | undefined;
    onEnd?: (() => any) | undefined;
}>, {
    time: string | number;
    format: string;
    autoStart: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
