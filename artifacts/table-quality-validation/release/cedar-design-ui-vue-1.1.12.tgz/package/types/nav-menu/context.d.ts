import type { ComputedRef, InjectionKey, Ref, Slots } from 'vue';
import type { NavMenuItemName } from './item-names';
import type { NavMenuKey, NavMenuNode, NavMenuProps, NavMenuRenderContext } from './types';
export interface NavMenuContext {
    dir: import("vue").ComputedRef<'ltr' | 'rtl'>;
    props: NavMenuProps;
    selected: import("vue").ComputedRef<NavMenuKey | null>;
    activeItem: import("vue").ComputedRef<NavMenuKey | null>;
    expanded: import("vue").ComputedRef<NavMenuKey[]>;
    collapsed: import("vue").ComputedRef<boolean>;
    activePath: import("vue").ComputedRef<Set<NavMenuKey>>;
    focusKey: import("vue").Ref<NavMenuKey | undefined>;
    slots: import("vue").Slots;
    context(node: NavMenuNode): NavMenuRenderContext;
    select(node: NavMenuNode, event: Event): void;
    expand(node: NavMenuNode, open: boolean): void;
    register(node: NavMenuNode, element: HTMLElement | null): void;
    focus(key: NavMenuKey): void;
    registerItem(id: symbol, close: (restoreFocus?: boolean) => void, name?: NavMenuItemName): () => void;
    activateItem(id?: symbol): boolean;
    selectItem(name: NavMenuKey): void;
    labelField: import("vue").ComputedRef<string>;
}
export declare const navMenuKey: import("vue").InjectionKey<NavMenuContext>;
