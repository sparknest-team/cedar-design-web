import { type PropType } from 'vue';
import type { TriggerPlacement } from '../trigger/contract';
/** Arrow follows the panel direction; inline branches expand downwards. */
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    placement: {
        type: import("vue").PropType<TriggerPlacement>;
        default: string;
    };
    open: BooleanConstructor;
    inline: BooleanConstructor;
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    placement: {
        type: import("vue").PropType<TriggerPlacement>;
        default: string;
    };
    open: BooleanConstructor;
    inline: BooleanConstructor;
}>> & Readonly<{}>, {
    open: boolean;
    placement: "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "left" | "left-start" | "left-end" | "right" | "right-start" | "right-end";
    inline: boolean;
}>;
export default _default;
