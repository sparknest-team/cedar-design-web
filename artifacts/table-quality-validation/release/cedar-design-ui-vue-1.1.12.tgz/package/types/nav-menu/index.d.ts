import _NavMenu from './menu';
import _NavMenuItem from './item';
export { navMenuItemProps } from './item-props';
export type { NavMenuItemProps, NavMenuItemSlotContext, NavMenuItemExposed } from './item-props';
declare const NavMenuItem: import('../_utils/global-config').ComponentWithInstall<typeof _NavMenuItem>;
export { NavMenuItem };
export type NavMenuItemInstance = InstanceType<typeof _NavMenuItem> & import('./item-props').NavMenuItemExposed;
export declare const _NavMenuItemComponent: typeof NavMenuItem;
export { navMenuProps } from './props';
export type { NavMenuProps, NavMenuKey, NavMenuOption, NavMenuFieldNames, NavMenuContent, NavMenuRenderContext, NavMenuMode, NavMenuPopupLayout, NavMenuExposed } from './types';
export declare const NavMenu: import('../_utils/global-config').ComponentWithInstall<typeof _NavMenu & {
    Item: typeof NavMenuItem;
}>;
export type NavMenuInstance = InstanceType<typeof _NavMenu> & import('./types').NavMenuExposed;
export declare const _NavMenuComponent: typeof NavMenu;
export default NavMenu;
