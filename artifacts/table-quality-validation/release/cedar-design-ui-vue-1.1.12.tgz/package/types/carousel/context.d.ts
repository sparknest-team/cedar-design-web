import type { ComputedRef, CSSProperties, InjectionKey } from 'vue';
export interface CarouselContext {
    keys: import("vue").ComputedRef<Array<string | number | symbol>>;
    current: import("vue").ComputedRef<number>;
    visible: import("vue").ComputedRef<number[]>;
    slideLabel: (index: number) => string;
    itemStyle: (index: number) => import("vue").CSSProperties;
    focusIfHidden: (element: HTMLElement | undefined) => void;
}
export declare const carouselInjectionKey: import("vue").InjectionKey<CarouselContext>;
