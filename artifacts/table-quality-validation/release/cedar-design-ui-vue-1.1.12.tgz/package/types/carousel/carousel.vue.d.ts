import type { CarouselSlots, CarouselToOptions } from './types';
type __VLS_Slots = CarouselSlots;
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    modelValue: NumberConstructor;
    defaultValue: {
        type: NumberConstructor;
        default: number;
    };
    loop: {
        type: BooleanConstructor;
        default: boolean;
    };
    autoPlay: {
        type: import("vue").PropType<boolean | number | import("./types").CarouselAutoPlayConfig>;
        default: boolean;
    };
    moveSpeed: NumberConstructor;
    trigger: {
        type: import("vue").PropType<import("./types").CarouselTriggerEvent>;
        default: string;
    };
    orientation: {
        type: import("vue").PropType<import("./types").CarouselOrientation>;
        default: string;
    };
    showArrow: {
        type: import("vue").PropType<import("./types").CarouselArrowType>;
        default: string;
    };
    arrowClass: StringConstructor;
    indicator: {
        type: BooleanConstructor;
        default: boolean;
    };
    indicatorType: {
        type: import("vue").PropType<import("./types").CarouselIndicatorType>;
        default: string;
    };
    indicatorPosition: {
        type: import("vue").PropType<import("./types").CarouselIndicatorPosition>;
        default: string;
    };
    indicatorClass: StringConstructor;
    indicatorColor: StringConstructor;
    height: (StringConstructor | NumberConstructor)[];
    transitionTimingFunction: StringConstructor;
    touchable: {
        type: BooleanConstructor;
        default: boolean;
    };
    draggable: BooleanConstructor;
    mousewheel: BooleanConstructor;
    keyboard: BooleanConstructor;
    slidesPerView: {
        type: import("vue").PropType<number | "auto">;
        default: number;
    };
    spaceBetween: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    effect: {
        type: import("vue").PropType<import("./types").CarouselEffect>;
        default: string;
    };
    centeredSlides: BooleanConstructor;
    ariaLabel: StringConstructor;
    previousButtonAriaLabel: StringConstructor;
    nextButtonAriaLabel: StringConstructor;
}>, {
    next: (options?: CarouselToOptions) => void;
    prev: (options?: CarouselToOptions) => void;
    to: (slideNumber: number, options?: CarouselToOptions) => void;
    resize: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    change: (slideNumber: number, previousSlideNumber: number, isManual: boolean) => any;
    "update:modelValue": (slideNumber: number) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    modelValue: NumberConstructor;
    defaultValue: {
        type: NumberConstructor;
        default: number;
    };
    loop: {
        type: BooleanConstructor;
        default: boolean;
    };
    autoPlay: {
        type: import("vue").PropType<boolean | number | import("./types").CarouselAutoPlayConfig>;
        default: boolean;
    };
    moveSpeed: NumberConstructor;
    trigger: {
        type: import("vue").PropType<import("./types").CarouselTriggerEvent>;
        default: string;
    };
    orientation: {
        type: import("vue").PropType<import("./types").CarouselOrientation>;
        default: string;
    };
    showArrow: {
        type: import("vue").PropType<import("./types").CarouselArrowType>;
        default: string;
    };
    arrowClass: StringConstructor;
    indicator: {
        type: BooleanConstructor;
        default: boolean;
    };
    indicatorType: {
        type: import("vue").PropType<import("./types").CarouselIndicatorType>;
        default: string;
    };
    indicatorPosition: {
        type: import("vue").PropType<import("./types").CarouselIndicatorPosition>;
        default: string;
    };
    indicatorClass: StringConstructor;
    indicatorColor: StringConstructor;
    height: (StringConstructor | NumberConstructor)[];
    transitionTimingFunction: StringConstructor;
    touchable: {
        type: BooleanConstructor;
        default: boolean;
    };
    draggable: BooleanConstructor;
    mousewheel: BooleanConstructor;
    keyboard: BooleanConstructor;
    slidesPerView: {
        type: import("vue").PropType<number | "auto">;
        default: number;
    };
    spaceBetween: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    effect: {
        type: import("vue").PropType<import("./types").CarouselEffect>;
        default: string;
    };
    centeredSlides: BooleanConstructor;
    ariaLabel: StringConstructor;
    previousButtonAriaLabel: StringConstructor;
    nextButtonAriaLabel: StringConstructor;
}>> & Readonly<{
    onChange?: ((slideNumber: number, previousSlideNumber: number, isManual: boolean) => any) | undefined;
    "onUpdate:modelValue"?: ((slideNumber: number) => any) | undefined;
}>, {
    defaultValue: number;
    showArrow: import("./types").CarouselArrowType;
    trigger: import("./types").CarouselTriggerEvent;
    indicator: boolean;
    orientation: "horizontal" | "vertical";
    effect: import("./types").CarouselEffect;
    draggable: boolean;
    keyboard: boolean;
    loop: boolean;
    autoPlay: number | boolean | import("./types").CarouselAutoPlayConfig;
    indicatorType: import("./types").CarouselIndicatorType;
    indicatorPosition: import("./types").CarouselIndicatorPosition;
    touchable: boolean;
    mousewheel: boolean;
    slidesPerView: number | "auto";
    spaceBetween: string | number;
    centeredSlides: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
