import _Carousel from './carousel.vue';
import _CarouselItem from './CarouselItem.vue';
import { carouselItemProps, carouselProps } from './props';
declare const Carousel: import('../_utils/global-config').CedarComponentWithInstall<typeof _Carousel & {
    Item: typeof _CarouselItem;
}>;
export type CarouselInstance = InstanceType<typeof _Carousel>;
export type CarouselItemInstance = InstanceType<typeof _CarouselItem>;
export type { CarouselProps, CarouselItemProps } from './props';
export type { CarouselArrowType, CarouselAutoPlayConfig, CarouselIndicatorPosition, CarouselIndicatorType, CarouselTriggerEvent, CarouselOrientation, CarouselEffect, CarouselToOptions, CarouselChangeData, CarouselEmits, CarouselSlots, CarouselItemSlots, CarouselExpose, CarouselSlotScope, } from './types';
export { Carousel, _CarouselItem as CarouselItem, carouselProps, carouselItemProps };
export declare const _CarouselComponent: typeof Carousel;
export declare const _CarouselItemComponent: typeof _CarouselItem;
export default Carousel;
