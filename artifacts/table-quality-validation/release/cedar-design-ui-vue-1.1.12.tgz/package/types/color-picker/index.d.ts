import _ColorPicker from './color-picker';
import { colorPickerProps } from './props';
declare const ColorPicker: import('../_utils/global-config').ComponentWithInstall<typeof _ColorPicker>;
export type { RGB, HSV, Color, ColorPickerSlots, ColorPickerTriggerSlotProps } from './types';
export type ColorPickerInstance = InstanceType<typeof _ColorPicker>;
export type { ColorPickerProps } from './props';
export { ColorPicker, colorPickerProps };
export declare const _ColorPickerComponent: typeof ColorPicker;
export default ColorPicker;
