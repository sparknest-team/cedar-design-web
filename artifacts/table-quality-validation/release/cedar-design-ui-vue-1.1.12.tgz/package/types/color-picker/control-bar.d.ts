import { PropType } from 'vue';
import { Color } from './types';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    x: {
        type: NumberConstructor;
        required: true;
    };
    color: {
        type: import("vue").PropType<Color>;
        required: true;
    };
    colorString: StringConstructor;
    type: import("vue").PropType<"hue" | "alpha">;
    disabled: BooleanConstructor;
    onChange: import("vue").PropType<(x: number) => void>;
}>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    x: {
        type: NumberConstructor;
        required: true;
    };
    color: {
        type: import("vue").PropType<Color>;
        required: true;
    };
    colorString: StringConstructor;
    type: import("vue").PropType<"hue" | "alpha">;
    disabled: BooleanConstructor;
    onChange: import("vue").PropType<(x: number) => void>;
}>> & Readonly<{}>, {
    disabled: boolean;
}>;
export default _default;
