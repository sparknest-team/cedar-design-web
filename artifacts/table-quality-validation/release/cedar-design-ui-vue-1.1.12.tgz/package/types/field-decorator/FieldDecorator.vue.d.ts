declare function handleClear(event?: Event): void;
declare var __VLS_11: {}, __VLS_13: {}, __VLS_15: {
    clear: typeof handleClear;
}, __VLS_24: {}, __VLS_26: {};
type __VLS_Slots = {} & {
    prefix?: (props: typeof __VLS_11) => any;
} & {
    default?: (props: typeof __VLS_13) => any;
} & {
    'clear-icon'?: (props: typeof __VLS_15) => any;
} & {
    'loading-icon'?: (props: typeof __VLS_24) => any;
} & {
    suffix?: (props: typeof __VLS_26) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    decorativeHint: BooleanConstructor;
    tag: {
        type: import("vue").PropType<"div" | "span">;
        default: string;
    };
    value: {
        type: null;
    };
    id: StringConstructor;
    title: StringConstructor;
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
        default: string;
        validator: (value: import("../index.ts").ComponentSize) => boolean;
    };
    variant: {
        type: import("vue").PropType<import("./props").FieldDecoratorVariant>;
        default: string;
        validator: (value: import("./props").FieldDecoratorVariant) => boolean;
    };
    placeholder: StringConstructor;
    hint: {
        type: BooleanConstructor;
        default: boolean;
    };
    hintCenter: {
        type: BooleanConstructor;
        default: boolean;
    };
    line: {
        type: BooleanConstructor;
        default: boolean;
    };
    focused: BooleanConstructor;
    error: BooleanConstructor;
    disabled: BooleanConstructor;
    readonly: BooleanConstructor;
    clearable: BooleanConstructor;
    composing: BooleanConstructor;
    textColor: StringConstructor;
    focusColor: StringConstructor;
    blurColor: StringConstructor;
    cursor: StringConstructor;
    loading: BooleanConstructor;
    loadingMode: {
        type: import("vue").PropType<import("./props").FieldLoadingMode>;
        default: string;
        validator: (value: import("./props").FieldLoadingMode) => boolean;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    clear: (event: Event) => any;
    mousedown: (event: MouseEvent) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    decorativeHint: BooleanConstructor;
    tag: {
        type: import("vue").PropType<"div" | "span">;
        default: string;
    };
    value: {
        type: null;
    };
    id: StringConstructor;
    title: StringConstructor;
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
        default: string;
        validator: (value: import("../index.ts").ComponentSize) => boolean;
    };
    variant: {
        type: import("vue").PropType<import("./props").FieldDecoratorVariant>;
        default: string;
        validator: (value: import("./props").FieldDecoratorVariant) => boolean;
    };
    placeholder: StringConstructor;
    hint: {
        type: BooleanConstructor;
        default: boolean;
    };
    hintCenter: {
        type: BooleanConstructor;
        default: boolean;
    };
    line: {
        type: BooleanConstructor;
        default: boolean;
    };
    focused: BooleanConstructor;
    error: BooleanConstructor;
    disabled: BooleanConstructor;
    readonly: BooleanConstructor;
    clearable: BooleanConstructor;
    composing: BooleanConstructor;
    textColor: StringConstructor;
    focusColor: StringConstructor;
    blurColor: StringConstructor;
    cursor: StringConstructor;
    loading: BooleanConstructor;
    loadingMode: {
        type: import("vue").PropType<import("./props").FieldLoadingMode>;
        default: string;
        validator: (value: import("./props").FieldLoadingMode) => boolean;
    };
}>> & Readonly<{
    onClear?: ((event: Event) => any) | undefined;
    onMousedown?: ((event: MouseEvent) => any) | undefined;
}>, {
    error: boolean;
    readonly: boolean;
    size: "xs" | "sm" | "md" | "lg" | "xl";
    tag: "div" | "span";
    line: boolean;
    disabled: boolean;
    variant: "outline" | "standard" | "filled";
    loading: boolean;
    loadingMode: "default" | "line";
    hint: boolean;
    hintCenter: boolean;
    focused: boolean;
    clearable: boolean;
    composing: boolean;
    decorativeHint: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
