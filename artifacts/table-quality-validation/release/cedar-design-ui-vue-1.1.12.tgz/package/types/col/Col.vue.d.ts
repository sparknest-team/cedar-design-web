declare var __VLS_1: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    span: {
        type: NumberConstructor;
        default: number;
        validator: ((value: unknown) => value is number) | undefined;
    };
    offset: {
        type: NumberConstructor;
        validator: ((value: unknown) => value is number) | undefined;
    };
    order: {
        type: NumberConstructor;
        validator: ((value: unknown) => value is number) | undefined;
    };
    xs: {
        type: import("vue").PropType<import("./props").ColBreakpoint>;
        validator: ((value: unknown) => boolean) | undefined;
    };
    sm: {
        type: import("vue").PropType<import("./props").ColBreakpoint>;
        validator: ((value: unknown) => boolean) | undefined;
    };
    md: {
        type: import("vue").PropType<import("./props").ColBreakpoint>;
        validator: ((value: unknown) => boolean) | undefined;
    };
    lg: {
        type: import("vue").PropType<import("./props").ColBreakpoint>;
        validator: ((value: unknown) => boolean) | undefined;
    };
    xl: {
        type: import("vue").PropType<import("./props").ColBreakpoint>;
        validator: ((value: unknown) => boolean) | undefined;
    };
    xxl: {
        type: import("vue").PropType<import("./props").ColBreakpoint>;
        validator: ((value: unknown) => boolean) | undefined;
    };
    flex: {
        type: import("vue").PropType<import("./props").FlexType>;
        validator: ((value: unknown) => boolean) | undefined;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    click: (value: MouseEvent) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    span: {
        type: NumberConstructor;
        default: number;
        validator: ((value: unknown) => value is number) | undefined;
    };
    offset: {
        type: NumberConstructor;
        validator: ((value: unknown) => value is number) | undefined;
    };
    order: {
        type: NumberConstructor;
        validator: ((value: unknown) => value is number) | undefined;
    };
    xs: {
        type: import("vue").PropType<import("./props").ColBreakpoint>;
        validator: ((value: unknown) => boolean) | undefined;
    };
    sm: {
        type: import("vue").PropType<import("./props").ColBreakpoint>;
        validator: ((value: unknown) => boolean) | undefined;
    };
    md: {
        type: import("vue").PropType<import("./props").ColBreakpoint>;
        validator: ((value: unknown) => boolean) | undefined;
    };
    lg: {
        type: import("vue").PropType<import("./props").ColBreakpoint>;
        validator: ((value: unknown) => boolean) | undefined;
    };
    xl: {
        type: import("vue").PropType<import("./props").ColBreakpoint>;
        validator: ((value: unknown) => boolean) | undefined;
    };
    xxl: {
        type: import("vue").PropType<import("./props").ColBreakpoint>;
        validator: ((value: unknown) => boolean) | undefined;
    };
    flex: {
        type: import("vue").PropType<import("./props").FlexType>;
        validator: ((value: unknown) => boolean) | undefined;
    };
}>> & Readonly<{
    onClick?: ((value: MouseEvent) => any) | undefined;
}>, {
    span: number;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
