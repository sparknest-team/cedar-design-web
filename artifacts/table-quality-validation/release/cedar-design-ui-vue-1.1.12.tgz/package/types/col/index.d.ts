import Component from './Col.vue';
import { colProps } from './props';
declare const Col: import('../_utils/global-config').CedarComponentWithInstall<typeof Component>;
export { Col, colProps };
export type { ColProps, ColBreakpoint, ColSizeDescriptor, FlexType } from './props';
export type ColInstance = InstanceType<typeof Component>;
export declare const _ColComponent: typeof Col;
export default Col;
