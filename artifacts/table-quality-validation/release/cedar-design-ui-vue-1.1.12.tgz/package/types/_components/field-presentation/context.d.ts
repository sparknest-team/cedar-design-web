import { type ComputedRef, type InjectionKey, type PropType } from 'vue';
import { type BeforeHookDone } from '../../_hooks/use-action-guard';
/** Field editing mode; independent of layout and readPretty. */
export type FieldEditMode = 'direct' | 'click' | 'dblclick';
export declare const fieldEditModeProp: {
    type: import("vue").PropType<FieldEditMode>;
    default: undefined;
    validator: (value: string) => boolean;
};
export declare const defaultSelectionPresentation: FieldEditMode;
export type BeforeFieldCommit = (payload: {
    value: unknown;
    previousValue: unknown;
}, done: BeforeHookDone, context: {
    signal: AbortSignal;
    event?: Event;
}) => void | boolean | Promise<void | boolean>;
/** Undefined waits for done; return a boolean or Promise for return-based completion. */
export declare function invokeBeforeCommit(hook: BeforeFieldCommit | undefined, value: unknown, context: {
    previousValue: unknown;
    signal: AbortSignal;
}): Promise<boolean> | undefined;
export type ReadPretty = boolean;
export declare const readPrettyProp: {
    type: BooleanConstructor;
    default: undefined;
};
export declare const beforeFieldCommitProp: import("vue").PropType<BeforeFieldCommit>;
export interface ActiveEditor {
    field?: string;
    active: () => boolean;
    cancel: () => void;
    focus: () => void;
}
interface PresentationContext {
    editMode: import("vue").ComputedRef<FieldEditMode | undefined>;
    readPretty?: import("vue").ComputedRef<ReadPretty | undefined>;
    label?: import("vue").ComputedRef<string | undefined>;
    message?: import("vue").ComputedRef<string>;
    field?: import("vue").ComputedRef<string>;
    validate?: (value: unknown) => Promise<boolean>;
    resetValidation?: () => void;
    register?: (editor: ActiveEditor) => () => void;
    resolved?: (value: FieldEditMode | undefined, readPretty?: boolean) => void;
}
export declare const fieldEditorBoundary: import("vue").InjectionKey<boolean>;
/** Physical editor panel presence, distinct from form-event ownership boundaries. */
export declare const fieldEditorPanel: import("vue").InjectionKey<boolean>;
/** Whether Enter without an open child popup belongs to the editor. */
export declare const fieldEditorEnterSubmits: import("vue").InjectionKey<import("vue").ComputedRef<boolean>>;
/** Only the wrapped control owns inline Form notifications; its nested inputs do not. */
export declare const fieldControlFormEvents: import("vue").InjectionKey<import("vue").ComputedRef<boolean>>;
export declare function provideFormPresentation(editMode: () => FieldEditMode | undefined, readPretty?: () => ReadPretty | undefined): {
    blocked(): boolean;
    cancel(fields?: string | string[]): void;
};
export declare function provideItemPresentation(options: Omit<PresentationContext, 'editMode' | 'readPretty'> & {
    editMode: () => FieldEditMode | undefined;
    readPretty?: () => ReadPretty | undefined;
}): {
    resolved: import("vue").ComputedRef<FieldEditMode>;
    readPretty: import("vue").ComputedRef<boolean>;
    cancel(): void;
};
export declare function useFieldPresentation(editMode: () => FieldEditMode | undefined, readPretty?: () => ReadPretty | undefined, defaultPresentation?: FieldEditMode): {
    readPretty: import("vue").ComputedRef<boolean>;
    editMode: import("vue").ComputedRef<FieldEditMode>;
    nativeEditor: boolean;
    item: PresentationContext | undefined;
    label: import("vue").ComputedRef<string | undefined>;
    register: (editor: ActiveEditor) => void;
};
export {};
