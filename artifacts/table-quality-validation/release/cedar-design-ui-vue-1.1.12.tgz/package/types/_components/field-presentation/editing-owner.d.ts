interface EditingOwner {
    save: () => Promise<boolean>;
    focus: () => void;
}
export declare function editingOwner(document: Document): EditingOwner | undefined;
export declare function claimEditing(document: Document, owner: EditingOwner): () => void;
export declare function withEditingTurn(document: Document, action: () => Promise<void>): Promise<void>;
export {};
