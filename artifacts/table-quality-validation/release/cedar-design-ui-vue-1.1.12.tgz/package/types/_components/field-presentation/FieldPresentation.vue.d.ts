import { type PopupContainer } from '../../_utils/popup-container';
import type { FieldEditMode } from './context';
type __VLS_Props = {
    clearable?: boolean;
    commit?: (event?: Event) => unknown | Promise<unknown>;
    retainReferenceIdWhenOpen?: boolean;
    openTriggerTarget?: 'field' | 'icon';
    editMode: FieldEditMode;
    empty?: boolean;
    emptyText?: string;
    readPretty?: boolean;
    loading?: boolean;
    text?: string;
    placeholder?: string;
    intent?: 'input' | 'select';
    label?: string;
    open?: boolean;
    popupContainer?: PopupContainer;
    confirmDisabled?: boolean;
    pending?: boolean;
    disabled?: boolean;
    readonly?: boolean;
    needConfirm?: boolean;
    error?: string;
    count?: number;
    limit?: number;
};
declare var __VLS_1: {}, __VLS_6: {}, __VLS_32: {};
type __VLS_Slots = {} & {
    read?: (props: typeof __VLS_1) => any;
} & {
    default?: (props: typeof __VLS_6) => any;
} & {
    default?: (props: typeof __VLS_32) => any;
};
declare const __VLS_component: import("vue").DefineComponent<__VLS_Props, {
    focus: () => void;
    blur: () => void | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    clear: () => any;
    cancel: () => any;
    open: (value: boolean) => any;
    confirm: (event?: Event | undefined) => any;
    "editor-ready": () => any;
}, string, import("../../vue-compat").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onClear?: (() => any) | undefined;
    onCancel?: (() => any) | undefined;
    onOpen?: ((value: boolean) => any) | undefined;
    onConfirm?: ((event?: Event | undefined) => any) | undefined;
    "onEditor-ready"?: (() => any) | undefined;
}>, {}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
