type __VLS_Props = {
    popupContainer?: string | HTMLElement | false;
    clearable?: boolean;
    compact?: boolean;
    deferEscape?: boolean;
    title?: string;
    intent?: 'input' | 'select';
    label?: string;
    pending?: boolean;
    disabled?: boolean;
    needConfirm?: boolean;
    error?: string;
    count?: number;
    limit?: number;
};
declare var __VLS_1: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_component: import("vue").DefineComponent<__VLS_Props, {
    focus: () => void;
    blur: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    clear: () => any;
    cancel: () => any;
    confirm: (event?: Event | undefined) => any;
}, string, import("../../vue-compat").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onClear?: (() => any) | undefined;
    onCancel?: (() => any) | undefined;
    onConfirm?: ((event?: Event | undefined) => any) | undefined;
}>, {}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
