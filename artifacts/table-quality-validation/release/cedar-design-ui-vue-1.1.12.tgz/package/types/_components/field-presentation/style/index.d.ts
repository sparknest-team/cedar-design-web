import '../../pending-feedback/style';
import '../../../button/style';
import '../../../dialog/style';
import '../../../trigger/style';
import '../style.less';
