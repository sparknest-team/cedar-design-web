import type { FieldEditMode } from './context';
type __VLS_Props = {
    openTriggerTarget?: 'field' | 'icon';
    id?: string;
    editMode?: FieldEditMode;
    disabled?: boolean;
    unavailable?: boolean;
    loading?: boolean;
    label?: string;
    text?: string;
    placeholder?: string;
    open?: boolean;
};
declare const _default: import("vue").DefineComponent<__VLS_Props, {
    focus: () => void | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    open: () => any;
}, string, import("../../vue-compat").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onOpen?: (() => any) | undefined;
}>, {}>;
export default _default;
