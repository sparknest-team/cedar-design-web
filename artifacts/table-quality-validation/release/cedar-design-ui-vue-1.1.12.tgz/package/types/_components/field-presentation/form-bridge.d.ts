export declare const usePresentationForm: ({ size, disabled, readonly, error, uninject, }?: {
    size?: import("vue").Ref<import("../..").ComponentSize | undefined>;
    disabled?: import("vue").Ref<boolean | undefined>;
    readonly?: import("vue").Ref<boolean | undefined>;
    error?: import("vue").Ref<boolean | undefined>;
    uninject?: boolean;
}) => import("../../_hooks/use-form-item").FormItemResolvedState;
export declare function isolateEditorForm(): void;
