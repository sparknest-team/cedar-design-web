import type { InjectionKey, ShallowRef, VNodeChild } from 'vue';
/** The editor host owns one footer; a field can contribute its auxiliary actions. */
export declare const editorAuxiliaryActions: import("vue").InjectionKey<import("vue").ShallowRef<(() => import("vue").VNodeChild) | undefined>>;
