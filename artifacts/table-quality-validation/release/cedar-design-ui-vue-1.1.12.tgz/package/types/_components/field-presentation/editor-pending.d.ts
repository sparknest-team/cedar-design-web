import type { InjectionKey, Ref } from 'vue';
/** Internal pending work of the control currently rendered by a field editor. */
export declare const fieldEditorControlPending: import("vue").InjectionKey<import("vue").Ref<boolean>>;
