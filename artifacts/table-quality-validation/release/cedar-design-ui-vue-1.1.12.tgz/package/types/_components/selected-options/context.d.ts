import type { InjectionKey, VNodeChild } from 'vue';
export interface SelectedOptionItem {
    key: string | number | symbol;
    label?: import("vue").VNodeChild;
    text?: string;
    closable?: boolean;
}
export declare const selectionListStyle: import("vue").InjectionKey<boolean>;
export declare const selectionEditorSurface: import("vue").InjectionKey<{
    mobile: boolean;
}>;
