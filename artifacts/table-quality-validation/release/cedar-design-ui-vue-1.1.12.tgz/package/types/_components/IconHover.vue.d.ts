import type { PropType } from 'vue';
import type { ComponentSize } from '../_utils/constant';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    prefix: {
        type: StringConstructor;
    };
    size: {
        type: import("vue").PropType<ComponentSize>;
        default: string;
    };
    disabled: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {
    classes: (...names: ((string | null | undefined) | [
        any,
        string | null | undefined,
        (string | null | undefined)?
    ])[]) => any[];
    n: (suffix?: string) => string;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    prefix: {
        type: StringConstructor;
    };
    size: {
        type: import("vue").PropType<ComponentSize>;
        default: string;
    };
    disabled: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{}>, {
    size: "xs" | "sm" | "md" | "lg" | "xl";
    disabled: boolean;
}>;
export default _default;
