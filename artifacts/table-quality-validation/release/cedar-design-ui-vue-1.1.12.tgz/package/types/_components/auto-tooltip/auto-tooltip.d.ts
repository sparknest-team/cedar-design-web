declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    tooltipProps: {
        type: ObjectConstructor;
    };
}>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    tooltipProps: {
        type: ObjectConstructor;
    };
}>> & Readonly<{}>, {}>;
export default _default;
