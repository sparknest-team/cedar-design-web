/** Resolve the current provider slot; local slots take precedence. */
export declare function useEmptySlot(): import("vue").ComputedRef<import("vue").Slot | undefined>;
