import { CSSProperties } from 'vue';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    height: {
        type: NumberConstructor;
    };
    offset: {
        type: NumberConstructor;
    };
    disabled: {
        type: BooleanConstructor;
    };
    type: StringConstructor;
    outerAttrs: ObjectConstructor;
    innerAttrs: ObjectConstructor;
}>, {
    outerStyle: import("vue").ComputedRef<import("vue").CSSProperties>;
    innerStyle: import("vue").ComputedRef<import("vue").CSSProperties>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    height: {
        type: NumberConstructor;
    };
    offset: {
        type: NumberConstructor;
    };
    disabled: {
        type: BooleanConstructor;
    };
    type: StringConstructor;
    outerAttrs: ObjectConstructor;
    innerAttrs: ObjectConstructor;
}>> & Readonly<{}>, {
    disabled: boolean;
}>;
export default _default;
