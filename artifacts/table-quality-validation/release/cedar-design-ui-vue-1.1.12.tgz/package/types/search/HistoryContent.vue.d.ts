import type { CompatibleReactive as UnwrapNestedRefs } from '../_utils/compatible-reactive';
import type { SearchResolvedProps } from './props';
import type { SearchSlots } from './types';
import type { SearchControl } from './use-search-control';
type __VLS_Props = {
    inputAttrs?: Record<string, unknown>;
    settings: SearchResolvedProps;
    state: UnwrapNestedRefs<SearchControl>;
};
type __VLS_Slots = SearchSlots;
declare const __VLS_component: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
