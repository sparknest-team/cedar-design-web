/** The field selector changes Search's criterion, not a second Form value. */
export declare function useSearchFieldBoundary(): void;
