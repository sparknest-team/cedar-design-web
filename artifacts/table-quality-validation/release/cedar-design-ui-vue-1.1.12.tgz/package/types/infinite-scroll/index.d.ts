import _InfiniteScroll from "./infinite-scroll.vue";
import { infiniteScrollProps } from "./props";
declare const InfiniteScroll: import('../_utils/global-config').ComponentWithInstall<typeof _InfiniteScroll>;
export interface InfiniteScrollMethods {
    check: () => void;
    retry: () => void;
}
export type InfiniteScrollInstance = InstanceType<typeof _InfiniteScroll> & InfiniteScrollMethods;
export type { InfiniteScrollProps, InfiniteScrollStatus } from "./props";
export { InfiniteScroll, infiniteScrollProps };
export declare const _InfiniteScrollComponent: typeof InfiniteScroll;
export default InfiniteScroll;
