import type { InjectionKey, Slots } from 'vue';
import type { ComponentSize } from '../_utils/constant';
import type { RadioNavigation } from './use-radio-navigation';
import type { RadioModel, ChoiceValue } from '../checkbox/choice-value-props';
import type { RadioVariant } from './variant';
export interface RadioGroupContext {
    navigation: RadioNavigation;
    value: RadioModel;
    size: ComponentSize;
    variant: RadioVariant;
    disabled: boolean;
    readonly: boolean;
    error: boolean;
    formErrorId?: string;
    name?: string;
    slots: import("vue").Slots;
    handleChange(value: ChoiceValue, event?: Event): void;
}
export declare const radioGroupKey: import("vue").InjectionKey<RadioGroupContext>;
