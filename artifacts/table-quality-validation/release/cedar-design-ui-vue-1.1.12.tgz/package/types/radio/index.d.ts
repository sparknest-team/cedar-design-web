import _RadioGroup from './group-presentation';
import _Radio from './presentation';
import { radioGroupProps, radioProps } from './props';
declare const Radio: import('../_utils/global-config').CedarComponentWithInstall<typeof _Radio & {
    Group: typeof _RadioGroup;
}>;
export type RadioInstance = InstanceType<typeof _Radio> & import('./props').RadioMethods;
export type RadioGroupInstance = InstanceType<typeof _RadioGroup>;
export { radioGroupProps, radioProps };
export type { RadioGroupProps, RadioProps, RadioValue } from './props';
export type { RadioVariant } from './variant';
export { Radio, _RadioGroup as RadioGroup };
export declare const _RadioComponent: typeof Radio;
export declare const _RadioGroupComponent: typeof _RadioGroup;
export default Radio;
export type { RadioMethods, RadioModel } from './props';
export type { RadioOption } from './types';
export type { RadioEmits, RadioGroupEmits, RadioSlots, RadioGroupSlots } from './props';
