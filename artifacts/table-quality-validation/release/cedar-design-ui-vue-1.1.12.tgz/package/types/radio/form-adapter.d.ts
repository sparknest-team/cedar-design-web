import type { ComponentSize } from '../_utils/constant';
export declare function useRadioForm(props: {
    size?: ComponentSize;
    disabled?: boolean;
    readonly?: boolean;
    error?: boolean;
}): {
    mergedSize: import("vue").ComputedRef<"xs" | "sm" | "md" | "lg" | "xl">;
    eventHandlers: import("vue").ComputedRef<import("..").FormItemEventHandler>;
    formItemCtx: import("../form/context").FormItemContext;
    mergedDisabled: import("vue").ComputedRef<boolean>;
    mergedReadonly: import("vue").ComputedRef<boolean>;
    mergedError: import("vue").ComputedRef<boolean>;
    feedback: import("vue").Ref<import("../form/context").FormItemContext["feedback"]>;
};
