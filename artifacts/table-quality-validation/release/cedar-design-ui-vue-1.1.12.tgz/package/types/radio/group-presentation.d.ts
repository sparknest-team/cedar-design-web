import Base from './radio-group.vue';
declare const Presented: typeof Base;
export default Presented;
