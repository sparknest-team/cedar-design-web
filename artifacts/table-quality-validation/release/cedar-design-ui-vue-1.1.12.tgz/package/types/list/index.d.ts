import _List from "./list.vue";
import _ListItem from "./list-item.vue";
import { listProps } from "./props";
declare const List: import('../_utils/global-config').ComponentWithInstall<typeof _List & {
    Item: typeof _ListItem;
}>;
export type ListInstance = InstanceType<typeof _List>;
export type ListItemInstance = InstanceType<typeof _ListItem>;
export type { ListProps, ListSize, ListVirtualListProps, ListScrollbarProps, ListExpose, ListSlots, ListEmits } from "./props";
export { _ListItem as ListItem };
export declare const _ListComponent: typeof List;
export declare const _ListItemComponent: typeof _ListItem;
export { List };
export { listProps };
export default List;
