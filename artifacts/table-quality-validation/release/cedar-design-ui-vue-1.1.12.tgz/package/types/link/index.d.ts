import _Link from './Link.vue';
import { linkProps } from './props';
declare const Link: import('../_utils/global-config').ComponentWithInstall<typeof _Link>;
export type LinkInstance = InstanceType<typeof _Link>;
export { linkProps };
export type { LinkProps, LinkUnderline, LinkSize } from './props';
export { Link };
export declare const _LinkComponent: typeof Link;
export default Link;
