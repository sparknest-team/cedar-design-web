import type { UploadProps } from './props';
export declare function useUploadForm(props: Readonly<UploadProps>): {
    group: import("../input/context").InputGroupContext | undefined;
    hasOuterLabel: import("vue").ComputedRef<boolean>;
    mergedSize: import("vue").ComputedRef<"xs" | "sm" | "md" | "lg" | "xl">;
    eventHandlers: import("vue").ComputedRef<import("..").FormItemEventHandler>;
    formItemCtx: import("../form/context").FormItemContext;
    mergedDisabled: import("vue").ComputedRef<boolean>;
    mergedReadonly: import("vue").ComputedRef<boolean>;
    mergedError: import("vue").ComputedRef<boolean>;
    feedback: import("vue").Ref<import("../form/context").FormItemContext["feedback"]>;
};
