export declare function watchDetachedCard(check: () => void): () => void;
