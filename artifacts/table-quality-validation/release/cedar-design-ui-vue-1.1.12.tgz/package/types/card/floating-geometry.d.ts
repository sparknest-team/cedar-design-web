export declare function layoutHeight(element: HTMLElement, visualHeight: number): number;
export declare function returnGeometry(holder: HTMLElement, floater: HTMLElement | null, expandedContent: HTMLElement | null): {
    rect: DOMRect;
    layoutHeight: string;
};
