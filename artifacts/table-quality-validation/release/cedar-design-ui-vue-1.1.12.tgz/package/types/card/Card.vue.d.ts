declare var __VLS_1: {}, __VLS_3: {}, __VLS_5: {
    slotClass: string;
}, __VLS_7: {}, __VLS_9: {
    slotClass: string;
}, __VLS_14: {}, __VLS_16: {
    slotClass: string;
}, __VLS_21: {}, __VLS_23: {}, __VLS_25: {};
type __VLS_Slots = {} & {
    cover?: (props: typeof __VLS_1) => any;
} & {
    header?: (props: typeof __VLS_3) => any;
} & {
    title?: (props: typeof __VLS_5) => any;
} & {
    'title-action'?: (props: typeof __VLS_7) => any;
} & {
    subtitle?: (props: typeof __VLS_9) => any;
} & {
    default?: (props: typeof __VLS_14) => any;
} & {
    description?: (props: typeof __VLS_16) => any;
} & {
    footer?: (props: typeof __VLS_21) => any;
} & {
    'floating-content'?: (props: typeof __VLS_23) => any;
} & {
    'close-button'?: (props: typeof __VLS_25) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    variant: {
        type: import("vue").PropType<import("./props").CardVariant>;
        default: string;
        validator: (v: import("./props").CardVariant) => boolean;
    };
    size: {
        type: import("vue").PropType<import("./props").CardSize>;
        validator: (v: import("./props").CardSize) => boolean;
    };
    direction: {
        type: import("vue").PropType<import("./props").CardDirection>;
        default: string;
        validator: (v: import("./props").CardDirection) => boolean;
    };
    hoverable: BooleanConstructor;
    titleStyle: import("vue").PropType<import("vue").CSSProperties>;
    title: StringConstructor;
    subtitle: StringConstructor;
    description: StringConstructor;
    topDivider: BooleanConstructor;
    bottomDivider: BooleanConstructor;
    imageSrc: StringConstructor;
    imageFit: {
        type: import("vue").PropType<import("./props").CardFit>;
        default: string;
    };
    imageHeight: (StringConstructor | NumberConstructor)[];
    imageWidth: (StringConstructor | NumberConstructor)[];
    imageAlt: StringConstructor;
    elevation: {
        type: import("vue").PropType<boolean | number>;
        default: number;
    };
    ripple: BooleanConstructor;
    floating: BooleanConstructor;
    floatingDuration: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    ariaLabel: StringConstructor;
    ariaLabelledby: StringConstructor;
    closeButtonAriaLabel: StringConstructor;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    click: (event: Event) => any;
    "update:floating": (value: boolean) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    variant: {
        type: import("vue").PropType<import("./props").CardVariant>;
        default: string;
        validator: (v: import("./props").CardVariant) => boolean;
    };
    size: {
        type: import("vue").PropType<import("./props").CardSize>;
        validator: (v: import("./props").CardSize) => boolean;
    };
    direction: {
        type: import("vue").PropType<import("./props").CardDirection>;
        default: string;
        validator: (v: import("./props").CardDirection) => boolean;
    };
    hoverable: BooleanConstructor;
    titleStyle: import("vue").PropType<import("vue").CSSProperties>;
    title: StringConstructor;
    subtitle: StringConstructor;
    description: StringConstructor;
    topDivider: BooleanConstructor;
    bottomDivider: BooleanConstructor;
    imageSrc: StringConstructor;
    imageFit: {
        type: import("vue").PropType<import("./props").CardFit>;
        default: string;
    };
    imageHeight: (StringConstructor | NumberConstructor)[];
    imageWidth: (StringConstructor | NumberConstructor)[];
    imageAlt: StringConstructor;
    elevation: {
        type: import("vue").PropType<boolean | number>;
        default: number;
    };
    ripple: BooleanConstructor;
    floating: BooleanConstructor;
    floatingDuration: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    ariaLabel: StringConstructor;
    ariaLabelledby: StringConstructor;
    closeButtonAriaLabel: StringConstructor;
}>> & Readonly<{
    onClick?: ((event: Event) => any) | undefined;
    "onUpdate:floating"?: ((value: boolean) => any) | undefined;
}>, {
    variant: "default" | "tonal" | "outline";
    elevation: number | boolean;
    direction: "column" | "row" | "row-reverse";
    ripple: boolean;
    floating: boolean;
    hoverable: boolean;
    topDivider: boolean;
    bottomDivider: boolean;
    imageFit: import("./props").CardFit;
    floatingDuration: number;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
