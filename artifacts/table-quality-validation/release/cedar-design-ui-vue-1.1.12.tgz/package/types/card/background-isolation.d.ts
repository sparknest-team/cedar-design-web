export declare function cardLayerTrees(roots: HTMLElement[]): Generator<Document | ShadowRoot, void, unknown>;
export declare function setCardBackgroundIsolation(panel: HTMLElement | null, active: boolean): void;
export declare function createBackgroundIsolation(document: Document): (cards: HTMLElement[], visible: HTMLElement[]) => void;
