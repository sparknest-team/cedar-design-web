import _Card from './Card.vue';
import { cardProps } from './props';
declare const Card: import('../_utils/global-config').ComponentWithInstall<typeof _Card>;
export type CardInstance = InstanceType<typeof _Card>;
export { cardProps };
export type { CardDirection, CardFit, CardProps, CardSize, CardVariant } from './props';
export { Card };
export declare const _CardComponent: typeof Card;
export default Card;
