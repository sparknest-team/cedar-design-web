import type { ComputedRef, InjectionKey } from 'vue';
import type { ComponentSize } from '../_utils/constant';
import type { InputVariant } from './props';
export interface InputGroupContext {
    size: import("vue").ComputedRef<ComponentSize>;
    disabled: import("vue").ComputedRef<boolean>;
    readonly: import("vue").ComputedRef<boolean>;
    variant: import("vue").ComputedRef<InputVariant>;
    hint: import("vue").ComputedRef<boolean | undefined>;
}
export declare const inputGroupKey: import("vue").InjectionKey<InputGroupContext>;
/** Internal opt-in for the first cell of the SMS verification control. */
export declare const oneTimeCodeKey: import("vue").InjectionKey<boolean>;
