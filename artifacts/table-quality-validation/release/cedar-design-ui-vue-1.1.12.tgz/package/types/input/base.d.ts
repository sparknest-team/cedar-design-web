import Input from './input.vue';
declare const Component: typeof Input & {
    setPropsDefaults: (defaults: Record<string, any>) => void;
};
export default Component;
