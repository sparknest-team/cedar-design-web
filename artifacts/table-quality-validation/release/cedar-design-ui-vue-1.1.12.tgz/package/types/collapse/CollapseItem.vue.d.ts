import { type CollapseName, type CollapseItemSlots } from './props';
type __VLS_Slots = CollapseItemSlots;
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    name: {
        type: import("vue").PropType<CollapseName>;
        required: true;
    };
    title: StringConstructor;
    headingLevel: {
        type: NumberConstructor;
        validator: (value: number) => boolean;
    };
    region: {
        type: BooleanConstructor;
        default: boolean;
    };
    disabled: BooleanConstructor;
    showExpandIcon: {
        type: BooleanConstructor;
        default: boolean;
    };
    destroyOnHide: BooleanConstructor;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    name: {
        type: import("vue").PropType<CollapseName>;
        required: true;
    };
    title: StringConstructor;
    headingLevel: {
        type: NumberConstructor;
        validator: (value: number) => boolean;
    };
    region: {
        type: BooleanConstructor;
        default: boolean;
    };
    disabled: BooleanConstructor;
    showExpandIcon: {
        type: BooleanConstructor;
        default: boolean;
    };
    destroyOnHide: BooleanConstructor;
}>> & Readonly<{}>, {
    disabled: boolean;
    region: boolean;
    showExpandIcon: boolean;
    destroyOnHide: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
