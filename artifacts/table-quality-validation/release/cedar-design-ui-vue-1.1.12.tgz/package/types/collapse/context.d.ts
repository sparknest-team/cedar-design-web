import type { ComputedRef, InjectionKey } from 'vue';
import type { CollapseName, ExpandIconPosition, CollapseSlots } from './props';
export interface CollapseItemContext {
    name: CollapseName;
    disabled: import("vue").ComputedRef<boolean>;
}
export interface CollapseContext {
    expandedNames: CollapseName[];
    slots: CollapseSlots;
    showExpandIcon?: boolean;
    expandIconPosition: ExpandIconPosition;
    destroyOnHide: boolean;
    divider: boolean;
    offset: boolean;
    handleClick: (name: CollapseName, e: Event) => void;
    addItem: (item: CollapseItemContext) => void;
    removeItem: (name: CollapseName) => void;
}
export declare const collapseKey: import("vue").InjectionKey<CollapseContext>;
