import { type CollapseName, type CollapseSlots, type CollapseToggleAllOptions } from './props';
type __VLS_Slots = CollapseSlots;
declare function toggleAll(options: CollapseToggleAllOptions): void;
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    modelValue: import("vue").PropType<import("./props").CollapseActiveNames>;
    defaultValue: {
        type: import("vue").PropType<import("./props").CollapseActiveNames>;
        default: () => never[];
    };
    accordion: BooleanConstructor;
    showExpandIcon: {
        type: BooleanConstructor;
        default: undefined;
    };
    expandIconPosition: {
        type: import("vue").PropType<import("./props").ExpandIconPosition>;
        default: string;
        validator: (value: import("./props").ExpandIconPosition) => boolean;
    };
    bordered: {
        type: BooleanConstructor;
        default: boolean;
    };
    divider: {
        type: BooleanConstructor;
        default: boolean;
    };
    offset: BooleanConstructor;
    destroyOnHide: BooleanConstructor;
}>, {
    toggleAll: typeof toggleAll;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    change: (expandedNames: CollapseName[], ev: Event) => any;
    "update:modelValue": (expandedNames: CollapseName[]) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    modelValue: import("vue").PropType<import("./props").CollapseActiveNames>;
    defaultValue: {
        type: import("vue").PropType<import("./props").CollapseActiveNames>;
        default: () => never[];
    };
    accordion: BooleanConstructor;
    showExpandIcon: {
        type: BooleanConstructor;
        default: undefined;
    };
    expandIconPosition: {
        type: import("vue").PropType<import("./props").ExpandIconPosition>;
        default: string;
        validator: (value: import("./props").ExpandIconPosition) => boolean;
    };
    bordered: {
        type: BooleanConstructor;
        default: boolean;
    };
    divider: {
        type: BooleanConstructor;
        default: boolean;
    };
    offset: BooleanConstructor;
    destroyOnHide: BooleanConstructor;
}>> & Readonly<{
    onChange?: ((expandedNames: CollapseName[], ev: Event) => any) | undefined;
    "onUpdate:modelValue"?: ((expandedNames: CollapseName[]) => any) | undefined;
}>, {
    offset: boolean;
    defaultValue: import("./props").CollapseActiveNames;
    bordered: boolean;
    divider: boolean;
    accordion: boolean;
    showExpandIcon: boolean;
    expandIconPosition: "left" | "right";
    destroyOnHide: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
