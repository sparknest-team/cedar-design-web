/**
 * 表单颜色字段。内部使用 ColorPicker（带触发器）。
 * 面板能力请直接使用 ColorPicker（默认无触发器）。
 */
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<string>>;
        default: undefined;
    };
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    modelValue: StringConstructor;
    defaultValue: StringConstructor;
    format: {
        type: import("vue").PropType<"hex" | "rgb">;
    };
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
        default: string;
        validator: (value: import("../index.ts").ComponentSize) => boolean;
    };
    showText: {
        type: BooleanConstructor;
        default: boolean;
    };
    showHistory: BooleanConstructor;
    showPreset: BooleanConstructor;
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    disabledAlpha: BooleanConstructor;
    historyColors: {
        type: import("vue").PropType<string[]>;
    };
    presetColors: {
        type: import("vue").PropType<string[]>;
    };
    colorPickerProps: {
        type: import("vue").PropType<Partial<import("../color-picker").ColorPickerProps>>;
        default: () => {};
    };
    clearable: BooleanConstructor;
    editMode: {
        type: import("vue").PropType<import("../index.ts").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
    beforeCommit: import("vue").PropType<import("../index.ts").BeforeFieldCommit>;
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: BooleanConstructor;
    popupContainer: {
        type: import("vue").PropType<import("../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
}>, {
    pickerProps: import("vue").ComputedRef<Partial<import("../color-picker").ColorPickerProps>>;
    blocked: import("vue").ComputedRef<boolean>;
    onUpdateModelValue: (value: string | undefined) => void;
    onChange: (value: string) => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    'update:modelValue': (value: string | undefined) => true;
    change: (value: string) => true;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<string>>;
        default: undefined;
    };
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    modelValue: StringConstructor;
    defaultValue: StringConstructor;
    format: {
        type: import("vue").PropType<"hex" | "rgb">;
    };
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
        default: string;
        validator: (value: import("../index.ts").ComponentSize) => boolean;
    };
    showText: {
        type: BooleanConstructor;
        default: boolean;
    };
    showHistory: BooleanConstructor;
    showPreset: BooleanConstructor;
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    disabledAlpha: BooleanConstructor;
    historyColors: {
        type: import("vue").PropType<string[]>;
    };
    presetColors: {
        type: import("vue").PropType<string[]>;
    };
    colorPickerProps: {
        type: import("vue").PropType<Partial<import("../color-picker").ColorPickerProps>>;
        default: () => {};
    };
    clearable: BooleanConstructor;
    editMode: {
        type: import("vue").PropType<import("../index.ts").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
    beforeCommit: import("vue").PropType<import("../index.ts").BeforeFieldCommit>;
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: BooleanConstructor;
    popupContainer: {
        type: import("vue").PropType<import("../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
}>> & Readonly<{
    onChange?: ((value: string) => any) | undefined;
    "onUpdate:modelValue"?: ((value: string | undefined) => any) | undefined;
}>, {
    readonly: boolean;
    size: "xs" | "sm" | "md" | "lg" | "xl";
    disabled: boolean;
    editMode: import("../index.ts").FieldEditMode;
    readPretty: boolean;
    clearable: boolean;
    emptyValue: import("../_utils/empty-value.ts").EmptyValue<string>;
    emptyValues: readonly unknown[];
    emptyText: string;
    popupContainer: import("../index.ts").PopupContainer;
    open: boolean;
    defaultOpen: boolean;
    disabledAlpha: boolean;
    showHistory: boolean;
    showPreset: boolean;
    showText: boolean;
    colorPickerProps: Partial<import("../color-picker").ColorPickerProps>;
}>;
export default _default;
