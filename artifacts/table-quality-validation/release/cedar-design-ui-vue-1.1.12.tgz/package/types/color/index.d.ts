import _Color from './presentation';
import { colorProps } from './props';
declare const Color: import('../_utils/global-config').ComponentWithInstall<typeof _Color>;
export type ColorInstance = InstanceType<typeof _Color>;
export type { ColorProps } from './props';
export { Color, colorProps };
export declare const _ColorComponent: typeof Color;
export default Color;
