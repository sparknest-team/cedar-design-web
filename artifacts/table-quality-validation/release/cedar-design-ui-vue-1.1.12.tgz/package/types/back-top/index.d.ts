import _BackTop from './BackTop.vue';
import { backTopProps } from './props';
declare const BackTop: import('../_utils/global-config').CedarComponentWithInstall<typeof _BackTop>;
export type BackTopInstance = InstanceType<typeof _BackTop>;
export type { BackTopProps, BackTopTarget, BackTopEasing } from './props';
export { BackTop, backTopProps };
export declare const _BackTopComponent: typeof BackTop;
export default BackTop;
