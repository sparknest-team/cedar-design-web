declare var __VLS_5: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_5) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    popupContainer: {
        type: import("vue").PropType<import("..").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    visibleHeight: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    targetContainer: import("vue").PropType<import("./props").BackTopTarget>;
    easing: {
        type: import("vue").PropType<import("./props").BackTopEasing>;
        default: string;
        validator: (value: unknown) => boolean;
    };
    duration: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    right: (StringConstructor | NumberConstructor)[];
    bottom: (StringConstructor | NumberConstructor)[];
    elevation: {
        type: (BooleanConstructor | NumberConstructor)[];
        default: boolean;
    };
    ariaLabel: {
        type: StringConstructor;
        default: string;
    };
}>, {
    scrollToTop: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    click: (event: MouseEvent) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    popupContainer: {
        type: import("vue").PropType<import("..").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    visibleHeight: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    targetContainer: import("vue").PropType<import("./props").BackTopTarget>;
    easing: {
        type: import("vue").PropType<import("./props").BackTopEasing>;
        default: string;
        validator: (value: unknown) => boolean;
    };
    duration: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    right: (StringConstructor | NumberConstructor)[];
    bottom: (StringConstructor | NumberConstructor)[];
    elevation: {
        type: (BooleanConstructor | NumberConstructor)[];
        default: boolean;
    };
    ariaLabel: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onClick?: ((event: MouseEvent) => any) | undefined;
}>, {
    duration: number;
    elevation: number | boolean;
    popupContainer: import("..").PopupContainer;
    ariaLabel: string;
    visibleHeight: string | number;
    easing: import("./props").BackTopEasing;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
