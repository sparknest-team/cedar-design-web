export declare function validRateCount(value: unknown): boolean;
export declare function normalizeRateCount(value: unknown): number;
