import _Rate from './presentation';
import { rateProps } from './props';
declare const Rate: import('../_utils/global-config').ComponentWithInstall<typeof _Rate>;
export type RateInstance = import('./props').RateExpose & InstanceType<typeof _Rate>;
export { Rate, rateProps };
export type { RateColor, RateIcon, RateProps, RateExpose, RateEmits, RateCharacterSlotProps, RateSlots, RateReadScope } from './props';
export declare const _RateComponent: typeof Rate;
export default Rate;
