import _CheckboxGroup from './group-presentation';
import _Checkbox from './base';
import { checkboxGroupProps, checkboxProps } from './props';
declare const Checkbox: import('../_utils/global-config').CedarComponentWithInstall<typeof _Checkbox & {
    Group: typeof _CheckboxGroup;
}>;
export type CheckboxInstance = InstanceType<typeof _Checkbox> & import('./props').CheckboxMethods;
export type CheckboxGroupInstance = InstanceType<typeof _CheckboxGroup> & import('./use-checkbox-group-methods').CheckboxGroupMethods;
export { checkboxGroupProps, checkboxProps };
export type { CheckboxGroupProps, CheckboxProps, CheckboxValue } from './props';
export type { CheckboxOption } from './types';
export { Checkbox, _CheckboxGroup as CheckboxGroup };
export declare const _CheckboxComponent: typeof Checkbox;
export declare const _CheckboxGroupComponent: typeof _CheckboxGroup;
export default Checkbox;
export type { CheckboxMethods, CheckboxModel } from './props';
export type { ChoiceFieldNames } from './choice-options';
export type { CheckboxGroupMethods } from './use-checkbox-group-methods';
export type { CheckboxSlots, CheckboxGroupSlots } from './types';
