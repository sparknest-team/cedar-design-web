import type { VNodeChild } from 'vue';
import type { ChoiceValue } from './choice-value-props';
export interface ChoiceFieldNames {
    label?: string;
    value?: string;
    disabled?: string;
    readonly?: string;
    indeterminate?: string;
}
export interface ChoiceOption {
    value: ChoiceValue;
    label?: import("vue").VNodeChild | ((option: ChoiceOption, checked: boolean) => import("vue").VNodeChild);
    disabled?: boolean;
    readonly?: boolean;
    [key: string]: unknown;
}
export interface CheckboxOption extends ChoiceOption {
    indeterminate?: boolean;
}
export type ChoiceOptionInput = ChoiceValue | ChoiceOption | Record<string, unknown>;
/** Normalize copies only; async option changes never rewrite the model. */
export declare function normalizeChoiceOptions(options: readonly ChoiceOptionInput[] | undefined, fields?: ChoiceFieldNames): CheckboxOption[];
