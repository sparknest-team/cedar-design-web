import Checkbox from './presentation';
declare const Component: typeof Checkbox & {
    setPropsDefaults: (defaults: Record<string, any>) => void;
};
export default Component;
