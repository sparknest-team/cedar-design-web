import type { PropType } from 'vue';
export type ChoiceValue = string | number | boolean;
export type CheckboxModel = boolean | ChoiceValue[] | null;
export type RadioModel = ChoiceValue | null;
export declare const checkboxValueProps: {
    /** 受控值：布尔选中状态或选中值数组 */
    modelValue: {
        type: import("vue").PropType<CheckboxModel>;
        default: undefined;
    };
    /** 非受控初始值，只在初始化读取 */
    defaultValue: {
        type: import("vue").PropType<CheckboxModel>;
        default: boolean;
    };
    /** 数组/分组模式的选项标识；布尔模式不改变值类型 */
    value: {
        type: import("vue").PropType<ChoiceValue>;
        default: boolean;
    };
};
export declare const radioValueProps: {
    /** 受控选项值；null 表示未选中 */
    modelValue: {
        type: import("vue").PropType<RadioModel>;
        default: undefined;
    };
    /** 非受控初始选项值，只在初始化读取 */
    defaultValue: {
        type: import("vue").PropType<RadioModel>;
        default: null;
    };
    /** 当前选项标识 */
    value: {
        type: import("vue").PropType<ChoiceValue>;
        default: boolean;
    };
};
