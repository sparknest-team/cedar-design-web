import type { ChoiceValue } from './choice-value-props';
import type { CheckboxGroupSlots } from './types';
type __VLS_Slots = CheckboxGroupSlots;
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    orientation: {
        type: import("vue").PropType<import("..").Orientation>;
        default: string;
        validator: (value: string) => boolean;
    };
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    error: {
        type: BooleanConstructor;
        default: undefined;
    };
    name: StringConstructor;
    ariaLabel: StringConstructor;
    options: {
        type: import("vue").PropType<readonly import("./choice-options").ChoiceOptionInput[] | import("../_hooks/use-option-request").OptionsLoader<import("./choice-options").ChoiceOptionInput>>;
        default: undefined;
    };
    fieldNames: {
        type: import("vue").PropType<import("./choice-options").ChoiceFieldNames>;
        default: undefined;
    };
    modelValue: {
        type: import("vue").PropType<ChoiceValue[] | null>;
        default: undefined;
    };
    defaultValue: {
        type: import("vue").PropType<ChoiceValue[]>;
        default: () => never[];
    };
    max: {
        type: NumberConstructor;
        validator: (value: number) => boolean;
    };
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value").EmptyValue<ChoiceValue[]>>;
        default: undefined;
    };
    clearable: BooleanConstructor;
    editMode: {
        type: import("vue").PropType<import("..").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
    beforeCommit: import("vue").PropType<import("..").BeforeFieldCommit>;
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: BooleanConstructor;
    popupContainer: {
        type: import("vue").PropType<import("..").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
}>, {
    checkAll(): ChoiceValue[];
    inverseAll(): ChoiceValue[];
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    change: (value: ChoiceValue[] | null, event?: Event | undefined) => any;
    "update:open": (open: boolean) => any;
    "open-change": (open: boolean) => any;
    "load-error": (error: unknown) => any;
    "update:modelValue": (value: ChoiceValue[] | null) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    orientation: {
        type: import("vue").PropType<import("..").Orientation>;
        default: string;
        validator: (value: string) => boolean;
    };
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    error: {
        type: BooleanConstructor;
        default: undefined;
    };
    name: StringConstructor;
    ariaLabel: StringConstructor;
    options: {
        type: import("vue").PropType<readonly import("./choice-options").ChoiceOptionInput[] | import("../_hooks/use-option-request").OptionsLoader<import("./choice-options").ChoiceOptionInput>>;
        default: undefined;
    };
    fieldNames: {
        type: import("vue").PropType<import("./choice-options").ChoiceFieldNames>;
        default: undefined;
    };
    modelValue: {
        type: import("vue").PropType<ChoiceValue[] | null>;
        default: undefined;
    };
    defaultValue: {
        type: import("vue").PropType<ChoiceValue[]>;
        default: () => never[];
    };
    max: {
        type: NumberConstructor;
        validator: (value: number) => boolean;
    };
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value").EmptyValue<ChoiceValue[]>>;
        default: undefined;
    };
    clearable: BooleanConstructor;
    editMode: {
        type: import("vue").PropType<import("..").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
    beforeCommit: import("vue").PropType<import("..").BeforeFieldCommit>;
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: BooleanConstructor;
    popupContainer: {
        type: import("vue").PropType<import("..").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
}>> & Readonly<{
    onChange?: ((value: ChoiceValue[] | null, event?: Event | undefined) => any) | undefined;
    "onUpdate:open"?: ((open: boolean) => any) | undefined;
    "onOpen-change"?: ((open: boolean) => any) | undefined;
    "onLoad-error"?: ((error: unknown) => any) | undefined;
    "onUpdate:modelValue"?: ((value: ChoiceValue[] | null) => any) | undefined;
}>, {
    error: boolean;
    readonly: boolean;
    disabled: boolean;
    editMode: import("..").FieldEditMode;
    readPretty: boolean;
    clearable: boolean;
    emptyValue: import("../_utils/empty-value").EmptyValue<ChoiceValue[]>;
    emptyValues: readonly unknown[];
    emptyText: string;
    popupContainer: import("..").PopupContainer;
    open: boolean;
    defaultOpen: boolean;
    modelValue: ChoiceValue[] | null;
    defaultValue: ChoiceValue[];
    orientation: "horizontal" | "vertical";
    options: readonly import("./choice-options").ChoiceOptionInput[] | import("../_hooks/use-option-request").OptionsLoader<import("./choice-options").ChoiceOptionInput>;
    fieldNames: import("./choice-options").ChoiceFieldNames;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
