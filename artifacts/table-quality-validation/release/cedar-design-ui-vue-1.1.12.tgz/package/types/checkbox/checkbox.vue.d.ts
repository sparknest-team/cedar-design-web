import type { CheckboxModel } from './choice-value-props';
import type { CheckboxSlots } from './types';
type __VLS_Slots = CheckboxSlots;
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    error: {
        type: BooleanConstructor;
        default: undefined;
    };
    indeterminate: {
        type: BooleanConstructor;
        default: boolean;
    };
    uninjectGroupContext: {
        type: BooleanConstructor;
        default: boolean;
    };
    checkedColor: StringConstructor;
    uncheckedColor: StringConstructor;
    iconSize: {
        type: import("vue").PropType<string | number>;
        validator: (value: unknown) => boolean;
    };
    ripple: {
        type: BooleanConstructor;
        default: boolean;
    };
    name: StringConstructor;
    ariaLabel: StringConstructor;
    modelValue: {
        type: import("vue").PropType<CheckboxModel>;
        default: undefined;
    };
    defaultValue: {
        type: import("vue").PropType<CheckboxModel>;
        default: boolean;
    };
    value: {
        type: import("vue").PropType<import("./choice-value-props").ChoiceValue>;
        default: boolean;
    };
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value").EmptyValue<CheckboxModel>>;
        default: undefined;
    };
    clearable: BooleanConstructor;
    editMode: {
        type: import("vue").PropType<import("..").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
    beforeCommit: import("vue").PropType<import("..").BeforeFieldCommit>;
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: BooleanConstructor;
    popupContainer: {
        type: import("vue").PropType<import("..").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
}>, {
    toggle: (next?: boolean, event?: Event) => void;
    focus(options?: FocusOptions): void;
    blur(): void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    click: (event: MouseEvent) => any;
    focus: (event: FocusEvent) => any;
    blur: (event: FocusEvent) => any;
    change: (value: CheckboxModel, event?: Event | undefined) => any;
    "update:open": (open: boolean) => any;
    "open-change": (open: boolean) => any;
    "update:modelValue": (value: CheckboxModel) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    error: {
        type: BooleanConstructor;
        default: undefined;
    };
    indeterminate: {
        type: BooleanConstructor;
        default: boolean;
    };
    uninjectGroupContext: {
        type: BooleanConstructor;
        default: boolean;
    };
    checkedColor: StringConstructor;
    uncheckedColor: StringConstructor;
    iconSize: {
        type: import("vue").PropType<string | number>;
        validator: (value: unknown) => boolean;
    };
    ripple: {
        type: BooleanConstructor;
        default: boolean;
    };
    name: StringConstructor;
    ariaLabel: StringConstructor;
    modelValue: {
        type: import("vue").PropType<CheckboxModel>;
        default: undefined;
    };
    defaultValue: {
        type: import("vue").PropType<CheckboxModel>;
        default: boolean;
    };
    value: {
        type: import("vue").PropType<import("./choice-value-props").ChoiceValue>;
        default: boolean;
    };
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value").EmptyValue<CheckboxModel>>;
        default: undefined;
    };
    clearable: BooleanConstructor;
    editMode: {
        type: import("vue").PropType<import("..").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
    beforeCommit: import("vue").PropType<import("..").BeforeFieldCommit>;
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: BooleanConstructor;
    popupContainer: {
        type: import("vue").PropType<import("..").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
}>> & Readonly<{
    onClick?: ((event: MouseEvent) => any) | undefined;
    onFocus?: ((event: FocusEvent) => any) | undefined;
    onBlur?: ((event: FocusEvent) => any) | undefined;
    onChange?: ((value: CheckboxModel, event?: Event | undefined) => any) | undefined;
    "onUpdate:open"?: ((open: boolean) => any) | undefined;
    "onOpen-change"?: ((open: boolean) => any) | undefined;
    "onUpdate:modelValue"?: ((value: CheckboxModel) => any) | undefined;
}>, {
    value: import("./choice-value-props").ChoiceValue;
    error: boolean;
    readonly: boolean;
    disabled: boolean;
    editMode: import("..").FieldEditMode;
    readPretty: boolean;
    clearable: boolean;
    emptyValue: import("../_utils/empty-value").EmptyValue<CheckboxModel>;
    emptyValues: readonly unknown[];
    emptyText: string;
    popupContainer: import("..").PopupContainer;
    open: boolean;
    defaultOpen: boolean;
    modelValue: CheckboxModel;
    defaultValue: CheckboxModel;
    ripple: boolean;
    indeterminate: boolean;
    uninjectGroupContext: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
