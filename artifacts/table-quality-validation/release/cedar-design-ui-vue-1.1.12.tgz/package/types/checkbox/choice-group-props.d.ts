import type { PropType } from 'vue';
import type { OptionsLoader } from '../_hooks/use-option-request';
import type { ChoiceFieldNames, ChoiceOptionInput } from './choice-options';
import type { ChoiceValue } from './choice-value-props';
export declare const choiceOptionsProps: {
    /** 选项数据；传入数组（包括空数组）时替代默认插槽 */
    options: {
        type: import("vue").PropType<readonly ChoiceOptionInput[] | OptionsLoader<ChoiceOptionInput>>;
        default: undefined;
    };
    /** 业务字段映射 */
    fieldNames: {
        type: import("vue").PropType<ChoiceFieldNames>;
        default: undefined;
    };
};
export declare const checkboxGroupValueProps: {
    /** 受控值 */
    modelValue: {
        type: import("vue").PropType<ChoiceValue[] | null>;
        default: undefined;
    };
    /** 非受控初始值 */
    defaultValue: {
        type: import("vue").PropType<ChoiceValue[]>;
        default: () => never[];
    };
    /** 最多可选数量 */
    max: {
        type: NumberConstructor;
        validator: (value: number) => boolean;
    };
};
export declare const radioGroupValueProps: {
    modelValue: {
        type: import("vue").PropType<import("./choice-value-props").RadioModel>;
        default: undefined;
    };
    defaultValue: {
        type: import("vue").PropType<import("./choice-value-props").RadioModel>;
        default: null;
    };
};
