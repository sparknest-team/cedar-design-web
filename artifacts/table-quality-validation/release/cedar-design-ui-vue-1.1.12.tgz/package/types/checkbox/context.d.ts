import type { InjectionKey, Slots } from 'vue';
import type { RegisterChoice } from './use-checkbox-group-methods';
import type { ChoiceValue } from './choice-value-props';
export interface CheckboxGroupContext {
    registerChoice: RegisterChoice;
    computedValue: ChoiceValue[];
    disabled: boolean;
    readonly: boolean;
    error: boolean;
    formErrorId?: string;
    isMaxed: boolean;
    name?: string;
    slots: import("vue").Slots;
    handleChange(value: ChoiceValue[], event?: Event): void;
}
export declare const checkboxGroupKey: import("vue").InjectionKey<CheckboxGroupContext>;
