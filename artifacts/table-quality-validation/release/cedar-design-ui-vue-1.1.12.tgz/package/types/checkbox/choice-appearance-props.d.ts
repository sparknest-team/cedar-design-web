import type { PropType } from 'vue';
import type { Orientation } from '../_utils/constant';
export declare const choiceOrientationProp: {
    type: import("vue").PropType<Orientation>;
    default: string;
    validator: (value: string) => boolean;
};
export declare const choiceIconSizeProp: {
    type: import("vue").PropType<string | number>;
    validator: (value: unknown) => boolean;
};
