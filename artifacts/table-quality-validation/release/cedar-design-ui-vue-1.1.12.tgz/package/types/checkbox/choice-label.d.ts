import type { FunctionalComponent, VNodeChild } from 'vue';
/** Render label content without narrowing Vue's supported child types. */
export declare const ChoiceLabel: import("vue").FunctionalComponent<{
    content: import("vue").VNodeChild;
}>;
