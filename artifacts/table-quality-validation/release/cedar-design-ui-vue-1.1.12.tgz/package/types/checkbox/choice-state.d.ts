/** A controlled proposal never becomes local state until the parent accepts it. */
export declare function useChoiceState<T>(model: () => T | undefined, initial: T, notify: (value: T, event?: Event) => void, blocked?: () => boolean): {
    value: import("vue").ComputedRef<any>;
    commit: (next: T, event?: Event) => boolean;
};
export declare function choiceLimit(max?: number | string): number;
export declare function toggleChoice<T>(values: readonly T[], value: T, checked: boolean, max?: number | string): T[];
export interface ChoiceCandidate<T> {
    value: T;
    disabled?: boolean;
    readonly?: boolean;
}
/** Bulk operations keep selected locked/unloaded values and only edit known enabled candidates. */
export declare function bulkChoices<T>(values: readonly T[], candidates: readonly ChoiceCandidate<T>[], inverse: boolean, max?: number | string): T[];
