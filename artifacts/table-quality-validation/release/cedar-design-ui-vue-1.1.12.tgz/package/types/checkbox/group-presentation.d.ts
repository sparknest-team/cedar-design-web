import Base from './checkbox-group.vue';
declare const Presented: typeof Base;
export default Presented;
