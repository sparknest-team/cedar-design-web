import _Overlay from "./overlay.vue";
import { overlayProps } from "./props";
declare const Overlay: import('../_utils/global-config').ComponentWithInstall<typeof _Overlay>;
export type OverlayInstance = InstanceType<typeof _Overlay>;
export type { OverlayProps } from "./props";
export { Overlay, overlayProps };
export declare const _OverlayComponent: typeof Overlay;
export default Overlay;
