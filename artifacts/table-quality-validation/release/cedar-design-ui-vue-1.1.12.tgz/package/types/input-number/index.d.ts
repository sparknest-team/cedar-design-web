import _InputNumber from './presentation';
import { inputNumberProps } from './props';
declare const InputNumber: import('../_utils/global-config').ComponentWithInstall<typeof _InputNumber>;
export type InputNumberInstance = InstanceType<typeof _InputNumber>;
export { InputNumber, inputNumberProps };
export type { InputNumberMode, InputNumberSize, InputNumberVariant, InputNumberFormatter, InputNumberModelEvent, InputNumberParser, InputNumberProps, } from './props';
export declare const _InputNumberComponent: typeof InputNumber;
export default InputNumber;
export type { InputNumberEmits, InputNumberSlots, InputNumberExpose } from './types';
