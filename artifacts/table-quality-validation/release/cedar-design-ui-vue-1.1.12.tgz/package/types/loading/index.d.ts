import { type Directive } from "vue";
import _Loading from "./Loading.vue";
import { loadingProps } from "./props";
import type { LoadingSize, LoadingType } from "./props";
declare const INSTANCE_KEY: unique symbol;
export interface LoadingOptions {
    loading: boolean;
    tip?: string;
    type?: LoadingType;
    size?: LoadingSize | number;
    radius?: string | number;
    hideIcon?: boolean;
    color?: string;
    fullscreen?: boolean;
    background?: string;
}
type LoadingRenderOptions = Omit<LoadingOptions, "loading">;
export interface ElementLoading extends HTMLElement {
    [INSTANCE_KEY]?: {
        container: HTMLElement;
        options: LoadingRenderOptions;
        restorePosition: boolean;
        releaseBodyLock?: () => void;
        fullscreen: boolean;
        previousBusy: string | null;
    };
}
export declare const vLoading: import("vue").Directive<ElementLoading, boolean | LoadingOptions>;
declare const Loading: import('../_utils/global-config').ComponentWithInstall<typeof _Loading>;
export type LoadingInstance = InstanceType<typeof _Loading>;
export type { LoadingProps, LoadingSize, LoadingType } from "./props";
export { Loading, loadingProps };
export declare const _LoadingComponent: typeof Loading;
export default Loading;
