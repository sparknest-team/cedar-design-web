import { type App } from 'vue';
import HoverOverlay from './HoverOverlay.vue';
import { hoverOverlayProps } from './overlay-props';
export type HoverValue = Record<string, any> | ((isHovering: boolean) => void);
type SavedStyle = {
    value: string;
    priority: string;
};
type HoverState = {
    value: HoverValue;
    hovering: boolean;
    rawStyle: Record<string, SavedStyle>;
};
export type HoverHTMLElement = HTMLElement & {
    _hover?: HoverState;
};
type HoverPlugin = import("vue").ObjectDirective & {
    install: (app: import("vue").App, ...options: any[]) => any;
} & {
    Overlay: typeof HoverOverlay;
    install(app: import("vue").App): void;
};
declare const Hover: HoverPlugin;
export declare function useHoverOverlay(): {
    hovering: import("vue").Ref<boolean>;
    handleHovering: (value: boolean) => void;
};
export type HoverOverlayInstance = InstanceType<typeof HoverOverlay>;
export type { HoverOverlayProps } from './overlay-props';
export { hoverOverlayProps, HoverOverlay };
export declare const _HoverComponent: HoverPlugin;
export declare const _HoverOverlayComponent: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    hovering: BooleanConstructor;
    focusing: BooleanConstructor;
}>, {
    n: (suffix?: string) => string;
    classes: (...names: ((string | null | undefined) | [
        any,
        string | null | undefined,
        (string | null | undefined)?
    ])[]) => any[];
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    hovering: BooleanConstructor;
    focusing: BooleanConstructor;
}>> & Readonly<{}>, {
    hovering: boolean;
    focusing: boolean;
}>;
export { Hover };
export default Hover;
