declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    hovering: BooleanConstructor;
    focusing: BooleanConstructor;
}>, {
    n: (suffix?: string) => string;
    classes: (...names: ((string | null | undefined) | [
        any,
        string | null | undefined,
        (string | null | undefined)?
    ])[]) => any[];
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    hovering: BooleanConstructor;
    focusing: BooleanConstructor;
}>> & Readonly<{}>, {
    hovering: boolean;
    focusing: boolean;
}>;
export default _default;
