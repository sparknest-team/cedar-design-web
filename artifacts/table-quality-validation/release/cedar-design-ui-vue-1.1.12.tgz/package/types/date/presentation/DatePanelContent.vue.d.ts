import type { DatePanelContentProps } from '../panel-state';
declare var __VLS_12: string, __VLS_13: any, __VLS_25: string | number, __VLS_26: any;
type __VLS_Slots = {} & {
    [K in NonNullable<typeof __VLS_12>]?: (props: typeof __VLS_13) => any;
} & {
    [K in NonNullable<typeof __VLS_25>]?: (props: typeof __VLS_26) => any;
};
declare const __VLS_component: import("vue").DefineComponent<DatePanelContentProps, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    select: (...args: any[]) => void;
    confirm: (...args: any[]) => void;
    navigate: (...args: any[]) => void;
}, string, import("../../vue-compat").PublicProps, Readonly<DatePanelContentProps> & Readonly<{
    onSelect?: ((...args: any[]) => any) | undefined;
    onConfirm?: ((...args: any[]) => any) | undefined;
    onNavigate?: ((...args: any[]) => any) | undefined;
}>, {}>;
declare const _default_1: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default_1;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
