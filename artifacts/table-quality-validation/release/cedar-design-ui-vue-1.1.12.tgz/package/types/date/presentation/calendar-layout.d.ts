import type { InjectionKey } from 'vue';
/** Floating and standalone panels keep date and time controls visible together. */
export declare const simultaneousDateLayout: import("vue").InjectionKey<boolean>;
