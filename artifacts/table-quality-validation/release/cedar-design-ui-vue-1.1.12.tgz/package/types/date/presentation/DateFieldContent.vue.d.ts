import type { DateFieldContentProps } from "../field-state";
declare var __VLS_9: {}, __VLS_26: string, __VLS_27: any, __VLS_29: {
    focus: boolean;
    popupOpen: boolean;
}, __VLS_38: {}, __VLS_53: string, __VLS_54: any;
type __VLS_Slots = {} & {
    [K in NonNullable<typeof __VLS_26>]?: (props: typeof __VLS_27) => any;
} & {
    [K in NonNullable<typeof __VLS_53>]?: (props: typeof __VLS_54) => any;
} & {
    default?: (props: typeof __VLS_9) => any;
} & {
    'suffix-icon'?: (props: typeof __VLS_29) => any;
} & {
    suffix?: (props: typeof __VLS_38) => any;
};
declare const __VLS_component: import("vue").DefineComponent<DateFieldContentProps, {
    focus: (index?: number) => void | undefined;
    blur: () => void | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "select-shortcut": (...args: any[]) => void;
    "picker-value-change": (...args: any[]) => void;
    "update:pickerValue": (...args: any[]) => void;
}, string, import("../../vue-compat").PublicProps, Readonly<DateFieldContentProps> & Readonly<{
    "onSelect-shortcut"?: ((...args: any[]) => any) | undefined;
    "onPicker-value-change"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pickerValue"?: ((...args: any[]) => any) | undefined;
}>, {}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
