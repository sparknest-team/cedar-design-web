import type { Dayjs } from 'dayjs';
import { PropType } from 'vue';
import type { Cell, DisabledDate, IsSameTime, Mode } from '../types';
import { RenderFunc } from '../../../_components/render-function';
import { getDateValue } from '../../../_utils/date';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    prefixCls: {
        type: StringConstructor;
        required: true;
    };
    rows: {
        type: import("vue").PropType<Cell[][]>;
        default: () => never[];
    };
    value: {
        type: import("vue").PropType<Dayjs>;
    };
    disabledDate: {
        type: import("vue").PropType<DisabledDate>;
    };
    isSameTime: {
        type: import("vue").PropType<IsSameTime>;
        required: true;
    };
    mode: {
        type: import("vue").PropType<Mode>;
    };
    rangeValues: {
        type: import("vue").PropType<Array<Dayjs | undefined>>;
    };
    dateRender: {
        type: import("vue").PropType<RenderFunc>;
    };
}>, {
    onGridKeydown: (event: KeyboardEvent) => void;
    isWeek: import("vue").ComputedRef<boolean>;
    getCellClassName: (cellData: Cell) => (string | {
        [x: string]: boolean | undefined;
    } | undefined)[];
    isCellDisabled: (cellData: Cell) => boolean;
    isCellSelected: (cellData: Cell) => boolean;
    onCellClick: (cellData: Cell) => void;
    onCellMouseEnter: (cellData: Cell) => void;
    getDateValue: typeof getDateValue;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("cell-click" | "cell-mouse-enter")[], "cell-click" | "cell-mouse-enter", import("../../../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    prefixCls: {
        type: StringConstructor;
        required: true;
    };
    rows: {
        type: import("vue").PropType<Cell[][]>;
        default: () => never[];
    };
    value: {
        type: import("vue").PropType<Dayjs>;
    };
    disabledDate: {
        type: import("vue").PropType<DisabledDate>;
    };
    isSameTime: {
        type: import("vue").PropType<IsSameTime>;
        required: true;
    };
    mode: {
        type: import("vue").PropType<Mode>;
    };
    rangeValues: {
        type: import("vue").PropType<Array<Dayjs | undefined>>;
    };
    dateRender: {
        type: import("vue").PropType<RenderFunc>;
    };
}>> & Readonly<{
    "onCell-click"?: ((...args: any[]) => any) | undefined;
    "onCell-mouse-enter"?: ((...args: any[]) => any) | undefined;
}>, {
    rows: Cell[][];
}>;
export default _default;
