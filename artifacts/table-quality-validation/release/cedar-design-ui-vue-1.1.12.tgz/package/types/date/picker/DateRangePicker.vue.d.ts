import type { Dayjs } from "dayjs";
import { CalendarValue, Mode, ShortcutType } from "./types";
import pick from "../../_utils/pick";
import { getDateValue } from "../../_utils/date";
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    disableConfirm: BooleanConstructor;
    mode: {
        type: import("vue").PropType<"date" | "year" | "quarter" | "month" | "week">;
        default: string;
        validator: (value: string) => boolean;
    };
    modelValue: {
        type: import("vue").PropType<(Date | string | number)[]>;
    };
    defaultValue: {
        type: import("vue").PropType<(Date | string | number)[]>;
    };
    pickerValue: {
        type: import("vue").PropType<(Date | string | number)[]>;
    };
    defaultPickerValue: {
        type: import("vue").PropType<(Date | string | number)[]>;
    };
    disabled: {
        type: import("vue").PropType<boolean | boolean[]>;
        default: boolean;
    };
    dayStartOfWeek: {
        type: import("vue").PropType<import("./types").WeekStart>;
        default: number;
        validator: (value: number) => boolean;
    };
    format: {
        type: StringConstructor;
    };
    valueFormat: {
        type: import("vue").PropType<"timestamp" | "Date" | string>;
    };
    showTime: {
        type: BooleanConstructor;
    };
    timePickerProps: {
        type: import("vue").PropType<Partial<import("../../index.ts").TimePickerProps>>;
    };
    placeholder: {
        type: import("vue").PropType<string[]>;
    };
    disabledDate: {
        type: import("vue").PropType<(current: Date, type: "start" | "end") => boolean>;
    };
    disabledTime: {
        type: import("vue").PropType<(current: Date, type: "start" | "end") => import("./types").DisabledTimeProps>;
    };
    separator: {
        type: StringConstructor;
    };
    exchangeTime: {
        type: BooleanConstructor;
        default: boolean;
    };
    popupContainer: {
        type: import("vue").PropType<import("../../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    clearable: {
        type: BooleanConstructor;
        default: boolean;
    };
    readonly: {
        type: BooleanConstructor;
    };
    error: {
        type: BooleanConstructor;
    };
    size: {
        type: import("vue").PropType<import("../../index.ts").ComponentSize>;
        validator: (value: import("../../index.ts").ComponentSize) => boolean;
    };
    variant: {
        type: import("vue").PropType<import("../../_utils/form-control.ts").FormControlVariant>;
        default: string;
        validator: (value: import("../../_utils/form-control.ts").FormControlVariant) => boolean;
    };
    shortcuts: {
        type: import("vue").PropType<ShortcutType[]>;
        default: () => never[];
    };
    shortcutsPosition: {
        type: import("vue").PropType<"left" | "bottom" | "right">;
        default: string;
    };
    placement: {
        type: import("vue").PropType<"top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end">;
        default: string;
    };
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: {
        type: BooleanConstructor;
    };
    triggerProps: {
        type: import("vue").PropType<import("../../index.ts").TriggerProps>;
    };
    unmountOnClose: {
        type: BooleanConstructor;
    };
    previewShortcut: {
        type: BooleanConstructor;
        default: boolean;
    };
    showConfirmBtn: {
        type: BooleanConstructor;
    };
    disabledInput: {
        type: BooleanConstructor;
        default: boolean;
    };
    abbreviation: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {
    prefixCls: string;
    computedFormat: import("vue").ComputedRef<string>;
    computedPlaceholder: import("vue").ComputedRef<string[]>;
    panelVisible: import("vue").ComputedRef<boolean>;
    panelValue: import("vue").ComputedRef<(Dayjs | undefined)[]>;
    inputValue: import("vue").Ref<(string | undefined)[] | undefined>;
    focusedIndex: import("vue").WritableComputedRef<number>;
    triggerDisabled: import("vue").ComputedRef<boolean>;
    mergedSize: import("vue").Ref<"xs" | "sm" | "md" | "lg" | "xl" | undefined>;
    mergedError: import("vue").Ref<boolean>;
    onPanelVisibleChange: (visible: boolean) => void;
    rangePanelProps: import("vue").ComputedRef<{
        prefixCls: string;
        format: string;
        value: (Dayjs | undefined)[];
        showConfirmBtn: boolean;
        confirmBtnDisabled: boolean | undefined;
        timePickerValue: Dayjs[];
        timePickerProps: {
            visible: boolean;
            readonly?: boolean | undefined;
            type?: "time" | "time-range" | undefined;
            disabled?: boolean | undefined;
            step?: import("../../index.ts").TimeStep | undefined;
            modelValue?: import("../../index.ts").TimeValue | import("../../index.ts").TimeValue[] | undefined;
            disableConfirm?: boolean | undefined;
            min?: string | undefined;
            max?: string | undefined;
            format: string;
            disabledHours?: (() => number[]) | undefined;
            disabledMinutes?: ((hour?: number) => number[]) | undefined;
            use12Hours?: boolean | undefined;
            hideDisabledOptions?: boolean | undefined;
            disabledSeconds?: ((hour?: number, minute?: number) => number[]) | undefined;
            showNextDay?: boolean | undefined;
        };
        extra: import("vue").Slot | undefined;
        dateRender: import("vue").Slot | undefined;
        startHeaderProps: {
            headerValue: Dayjs;
            headerOperations: {
                onPrev?: (() => void) | undefined;
                onSuperPrev: () => void;
            };
            headerIcons: {
                prev: import("vue").Slot | undefined;
                prevDouble: import("vue").Slot | undefined;
                next: import("vue").Slot | undefined;
                nextDouble: import("vue").Slot | undefined;
            };
        };
        endHeaderProps: {
            headerValue: Dayjs;
            headerOperations: {
                onNext?: (() => void) | undefined;
                onSuperNext: () => void;
            };
            headerIcons: {
                prev: import("vue").Slot | undefined;
                prevDouble: import("vue").Slot | undefined;
                next: import("vue").Slot | undefined;
                nextDouble: import("vue").Slot | undefined;
            };
        };
        footerValue: {
            clone: () => Dayjs;
            isValid: () => boolean;
            year: {
                (): number;
                (value: number): Dayjs;
            };
            month: {
                (): number;
                (value: number): Dayjs;
            };
            date: {
                (): number;
                (value: number): Dayjs;
            };
            day: {
                (): 0 | 1 | 2 | 3 | 4 | 5 | 6;
                (value: number): Dayjs;
            };
            hour: {
                (): number;
                (value: number): Dayjs;
            };
            minute: {
                (): number;
                (value: number): Dayjs;
            };
            second: {
                (): number;
                (value: number): Dayjs;
            };
            millisecond: {
                (): number;
                (value: number): Dayjs;
            };
            set: (unit: import("dayjs").UnitType, value: number) => Dayjs;
            get: (unit: import("dayjs").UnitType) => number;
            add: {
                (value: number, unit?: import("dayjs").ManipulateType): Dayjs;
                (value: number, unit: import("dayjs").QUnitType): Dayjs;
            };
            subtract: {
                (value: number, unit?: import("dayjs").ManipulateType): Dayjs;
                (value: number, unit: import("dayjs").QUnitType): Dayjs;
            };
            startOf: {
                (unit: import("dayjs").OpUnitType): Dayjs;
                (unit: import("dayjs").QUnitType | import("dayjs").OpUnitType): Dayjs;
            };
            endOf: {
                (unit: import("dayjs").OpUnitType): Dayjs;
                (unit: import("dayjs").QUnitType | import("dayjs").OpUnitType): Dayjs;
            };
            format: (template?: string) => string;
            diff: (date?: import("dayjs").ConfigType, unit?: import("dayjs").QUnitType | import("dayjs").OpUnitType, float?: boolean) => number;
            valueOf: () => number;
            unix: () => number;
            daysInMonth: () => number;
            toDate: () => Date;
            toJSON: () => string;
            toISOString: () => string;
            toString: () => string;
            utcOffset: {
                (): number;
                (offset: number | string, keepLocalTime?: boolean): Dayjs;
            };
            isBefore: {
                (date?: import("dayjs").ConfigType, unit?: import("dayjs").OpUnitType): boolean;
                (date?: import("dayjs").ConfigType, unit?: import("dayjs").QUnitType): boolean;
            };
            isSame: {
                (date?: import("dayjs").ConfigType, unit?: import("dayjs").OpUnitType): boolean;
                (date?: import("dayjs").ConfigType, unit?: import("dayjs").QUnitType): boolean;
            };
            isAfter: {
                (date?: import("dayjs").ConfigType, unit?: import("dayjs").OpUnitType): boolean;
                (date?: import("dayjs").ConfigType, unit?: import("dayjs").QUnitType): boolean;
            };
            locale: {
                (): string;
                (preset: string | ILocale, object?: Partial<ILocale>): Dayjs;
            };
            isBetween: (a: import("dayjs").ConfigType, b: import("dayjs").ConfigType, c?: import("dayjs").OpUnitType | null, d?: "()" | "[]" | "[)" | "(]") => boolean;
            week: {
                (): number;
                (value: number): Dayjs;
            };
            weekYear: () => number;
            quarter: {
                (): number;
                (quarter: number): Dayjs;
            };
            utc: (keepLocalTime?: boolean) => Dayjs;
            local: () => Dayjs;
            isUTC: () => boolean;
            tz: (timezone?: string, keepLocalTime?: boolean) => Dayjs;
            offsetName: (type?: "short" | "long") => string | undefined;
        }[];
        disabled: boolean[];
        visible: boolean;
        onCellClick: (date: Dayjs) => void;
        onCellMouseEnter: (date: Dayjs) => void;
        onRangeMouseLeave: () => void;
        onShortcutClick: (value: Array<Dayjs | undefined>, shortcut: ShortcutType) => void;
        onShortcutMouseEnter: ((value: Array<Dayjs | undefined>) => void) | undefined;
        onShortcutMouseLeave: (() => void) | undefined;
        onConfirm: () => void;
        onTimePickerSelect: (time: Dayjs, type: "start" | "end") => void;
        startHeaderMode: "month" | "year" | undefined;
        endHeaderMode: "month" | "year" | undefined;
        onStartHeaderLabelClick: (type: "year" | "month") => void;
        onEndHeaderLabelClick: (type: "year" | "month") => void;
        onStartHeaderSelect: (date: Dayjs) => void;
        onEndHeaderSelect: (date: Dayjs) => void;
        mode: "month" | "week" | "date" | "year" | "quarter";
        dayStartOfWeek: import("./types").WeekStart;
        showTime: boolean;
        shortcuts: ShortcutType[];
        disabledDate: ((current: Date, type: "start" | "end") => boolean) | undefined;
        disabledTime: ((current: Date, type: "start" | "end") => import("./types").DisabledTimeProps) | undefined;
        abbreviation: boolean;
        shortcutsPosition: "bottom" | "left" | "right";
    }>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    /**
     * @zh 组件值发生改变
     * @en The component value changes
     * @param {(Date | string | number | undefined)[] | undefined} value
     * @param {(Date | undefined)[] | undefined} date
     * @param {(string | undefined)[] | undefined} dateString
     */
    change: (value: (CalendarValue | undefined)[] | undefined, date: (Date | undefined)[] | undefined, dateString: (string | undefined)[] | undefined) => true;
    "update:modelValue": (value: (CalendarValue | undefined)[] | undefined) => true;
    /**
     * @zh 选中日期发生改变但组件值未改变
     * @en The selected date has changed but the component value has not changed
     * @param {(Date | string | number | undefined)[]} value
     * @param {(Date | undefined)[]} date
     * @param {(string | undefined)[]} dateString
     */
    select: (value: (CalendarValue | undefined)[], date: (Date | undefined)[], dateString: (string | undefined)[]) => true;
    /**
     * @zh 打开或关闭弹出框
     * @en Open or close the pop-up box
     * @param {boolean} visible
     */
    "open-change": (visible: boolean) => true;
    "update:open": (visible: boolean) => true;
    /**
     * @zh 点击确认按钮
     * @en Click the confirm button
     * @param {Date | string | number[]} value
     * @param {Date[]} date
     * @param {string[]} dateString
     */
    ok: (value: (CalendarValue | undefined)[] | undefined, date: (Date | undefined)[] | undefined, dateString: (string | undefined)[] | undefined) => true;
    /**
     * @zh 点击清除按钮
     * @en Click the clear button
     */
    clear: () => true;
    /**
     * @zh 点击快捷选项
     * @en Click on the shortcut option
     * @param {ShortcutType} shortcut
     */
    "select-shortcut": (shortcut: ShortcutType) => true;
    /**
     * @zh 面板日期改变
     * @en Panel date change
     * @param {Date | string | number[]} value
     * @param {Date[]} date
     * @param {string[]} dateString
     */
    "picker-value-change": (value: CalendarValue[], date: Date[], dateString: string[]) => true;
    "update:pickerValue": (value: CalendarValue[]) => true;
}, string, import("../../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    disableConfirm: BooleanConstructor;
    mode: {
        type: import("vue").PropType<"date" | "year" | "quarter" | "month" | "week">;
        default: string;
        validator: (value: string) => boolean;
    };
    modelValue: {
        type: import("vue").PropType<(Date | string | number)[]>;
    };
    defaultValue: {
        type: import("vue").PropType<(Date | string | number)[]>;
    };
    pickerValue: {
        type: import("vue").PropType<(Date | string | number)[]>;
    };
    defaultPickerValue: {
        type: import("vue").PropType<(Date | string | number)[]>;
    };
    disabled: {
        type: import("vue").PropType<boolean | boolean[]>;
        default: boolean;
    };
    dayStartOfWeek: {
        type: import("vue").PropType<import("./types").WeekStart>;
        default: number;
        validator: (value: number) => boolean;
    };
    format: {
        type: StringConstructor;
    };
    valueFormat: {
        type: import("vue").PropType<"timestamp" | "Date" | string>;
    };
    showTime: {
        type: BooleanConstructor;
    };
    timePickerProps: {
        type: import("vue").PropType<Partial<import("../../index.ts").TimePickerProps>>;
    };
    placeholder: {
        type: import("vue").PropType<string[]>;
    };
    disabledDate: {
        type: import("vue").PropType<(current: Date, type: "start" | "end") => boolean>;
    };
    disabledTime: {
        type: import("vue").PropType<(current: Date, type: "start" | "end") => import("./types").DisabledTimeProps>;
    };
    separator: {
        type: StringConstructor;
    };
    exchangeTime: {
        type: BooleanConstructor;
        default: boolean;
    };
    popupContainer: {
        type: import("vue").PropType<import("../../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    clearable: {
        type: BooleanConstructor;
        default: boolean;
    };
    readonly: {
        type: BooleanConstructor;
    };
    error: {
        type: BooleanConstructor;
    };
    size: {
        type: import("vue").PropType<import("../../index.ts").ComponentSize>;
        validator: (value: import("../../index.ts").ComponentSize) => boolean;
    };
    variant: {
        type: import("vue").PropType<import("../../_utils/form-control.ts").FormControlVariant>;
        default: string;
        validator: (value: import("../../_utils/form-control.ts").FormControlVariant) => boolean;
    };
    shortcuts: {
        type: import("vue").PropType<ShortcutType[]>;
        default: () => never[];
    };
    shortcutsPosition: {
        type: import("vue").PropType<"left" | "bottom" | "right">;
        default: string;
    };
    placement: {
        type: import("vue").PropType<"top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end">;
        default: string;
    };
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: {
        type: BooleanConstructor;
    };
    triggerProps: {
        type: import("vue").PropType<import("../../index.ts").TriggerProps>;
    };
    unmountOnClose: {
        type: BooleanConstructor;
    };
    previewShortcut: {
        type: BooleanConstructor;
        default: boolean;
    };
    showConfirmBtn: {
        type: BooleanConstructor;
    };
    disabledInput: {
        type: BooleanConstructor;
        default: boolean;
    };
    abbreviation: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    onClear?: (() => any) | undefined;
    onSelect?: ((value: (CalendarValue | undefined)[], date: (Date | undefined)[], dateString: (string | undefined)[]) => any) | undefined;
    onChange?: ((value: (CalendarValue | undefined)[] | undefined, date: (Date | undefined)[] | undefined, dateString: (string | undefined)[] | undefined) => any) | undefined;
    "onUpdate:open"?: ((visible: boolean) => any) | undefined;
    "onOpen-change"?: ((visible: boolean) => any) | undefined;
    "onUpdate:modelValue"?: ((value: (CalendarValue | undefined)[] | undefined) => any) | undefined;
    onOk?: ((value: (CalendarValue | undefined)[] | undefined, date: (Date | undefined)[] | undefined, dateString: (string | undefined)[] | undefined) => any) | undefined;
    "onSelect-shortcut"?: ((shortcut: ShortcutType) => any) | undefined;
    "onPicker-value-change"?: ((value: CalendarValue[], date: Date[], dateString: string[]) => any) | undefined;
    "onUpdate:pickerValue"?: ((value: CalendarValue[]) => any) | undefined;
}>, {
    error: boolean;
    readonly: boolean;
    mode: "month" | "week" | "date" | "year" | "quarter";
    disabled: boolean | boolean[];
    variant: "outline" | "standard" | "filled";
    clearable: boolean;
    popupContainer: import("../../index.ts").PopupContainer;
    open: boolean;
    defaultOpen: boolean;
    placement: "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end";
    unmountOnClose: boolean;
    disableConfirm: boolean;
    dayStartOfWeek: import("./types").WeekStart;
    showTime: boolean;
    shortcuts: ShortcutType[];
    abbreviation: boolean;
    exchangeTime: boolean;
    shortcutsPosition: "bottom" | "left" | "right";
    previewShortcut: boolean;
    showConfirmBtn: boolean;
    disabledInput: boolean;
}>;
export default _default;
