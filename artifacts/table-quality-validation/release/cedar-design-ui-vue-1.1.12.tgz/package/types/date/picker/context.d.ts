import type { InjectionKey } from 'vue';
export declare const PickerInjectionKey: import("vue").InjectionKey<PickerContext>;
export type PickerContext = Readonly<{
    datePickerT: (key: string, ...args: any[]) => any;
}>;
