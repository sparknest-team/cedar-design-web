import { PropType } from 'vue';
import type { Dayjs } from 'dayjs';
import { isFunction } from '../../_utils/is';
import pick from '../../_utils/pick';
import type { ShortcutType, DateRangePickerProps, Mode, RangeDisabledTime, RangeDisabledDate, WeekStart, StartHeaderProps } from './types';
import { RenderFunc } from '../../_components/render-function';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    mode: {
        type: import("vue").PropType<Mode>;
        default: string;
    };
    value: {
        type: import("vue").PropType<Array<Dayjs | undefined>>;
        default: () => never[];
    };
    footerValue: {
        type: import("vue").PropType<Array<Dayjs | undefined>>;
    };
    timePickerValue: {
        type: import("vue").PropType<Dayjs[]>;
    };
    showTime: {
        type: BooleanConstructor;
    };
    showConfirmBtn: {
        type: BooleanConstructor;
    };
    prefixCls: {
        type: StringConstructor;
        required: true;
    };
    shortcuts: {
        type: import("vue").PropType<ShortcutType[]>;
        default: () => never[];
    };
    shortcutsPosition: {
        type: import("vue").PropType<DateRangePickerProps["shortcutsPosition"]>;
        default: string;
    };
    format: {
        type: StringConstructor;
        required: true;
    };
    dayStartOfWeek: {
        type: import("vue").PropType<WeekStart>;
        default: number;
    };
    disabledDate: {
        type: import("vue").PropType<RangeDisabledDate>;
    };
    disabledTime: {
        type: import("vue").PropType<RangeDisabledTime>;
    };
    timePickerProps: {
        type: import("vue").PropType<DateRangePickerProps["timePickerProps"]>;
    };
    extra: {
        type: import("vue").PropType<RenderFunc>;
    };
    dateRender: {
        type: import("vue").PropType<RenderFunc>;
    };
    startHeaderProps: {
        type: import("vue").PropType<StartHeaderProps>;
        default: () => {};
    };
    endHeaderProps: {
        type: import("vue").PropType<StartHeaderProps>;
        default: () => {};
    };
    confirmBtnDisabled: {
        type: BooleanConstructor;
    };
    disabled: {
        type: import("vue").PropType<boolean[]>;
        default: () => boolean[];
    };
    visible: {
        type: BooleanConstructor;
    };
    startHeaderMode: {
        type: import("vue").PropType<"year" | "month">;
    };
    endHeaderMode: {
        type: import("vue").PropType<"year" | "month">;
    };
    abbreviation: {
        type: BooleanConstructor;
    };
}>, {
    pick: typeof pick;
    classNames: import("vue").ComputedRef<(string | {
        [x: string]: boolean | 0;
    })[]>;
    showShortcuts: import("vue").ComputedRef<number | false>;
    shortcutsProps: {
        prefixCls: string;
        shortcuts: ShortcutType[];
        onItemClick: (shortcut: ShortcutType) => void;
        onItemMouseEnter: (shortcut: ShortcutType) => void;
        onItemMouseLeave: (shortcut: ShortcutType) => void;
    };
    startPanelProps: import("vue").ComputedRef<{
        rangeValues: (Dayjs | undefined)[];
        disabledDate: (current: Date) => boolean;
        dateRender: RenderFunc | undefined;
        onSelect: (date: Dayjs) => void;
        onCellMouseEnter: (date: Dayjs) => void;
        onHeaderLabelClick: (type: "year" | "month") => void;
        headerValue: Dayjs;
        headerOperations: Pick<any, string>;
        headerIcons: {
            prev: import("vue").Slot | undefined;
            prevDouble: import("vue").Slot | undefined;
            next: import("vue").Slot | undefined;
            nextDouble: import("vue").Slot | undefined;
        };
    }>;
    endPanelProps: import("vue").ComputedRef<{
        rangeValues: (Dayjs | undefined)[];
        disabledDate: (current: Date) => boolean;
        dateRender: RenderFunc | undefined;
        onSelect: (date: Dayjs) => void;
        onCellMouseEnter: (date: Dayjs) => void;
        onHeaderLabelClick: (type: "year" | "month") => void;
        headerValue: Dayjs;
        headerOperations: Pick<any, string>;
        headerIcons: {
            prev: import("vue").Slot | undefined;
            prevDouble: import("vue").Slot | undefined;
            next: import("vue").Slot | undefined;
            nextDouble: import("vue").Slot | undefined;
        };
    }>;
    getDisabledTimeFunc: (index: 0 | 1) => ((current: Date) => import("./types").DisabledTimeProps) | undefined;
    onConfirmBtnClick: () => void;
    currentDateView: import("vue").Ref<"time" | "date">;
    onStartTimePickerSelect: (time: Dayjs) => void;
    onEndTimePickerSelect: (time: Dayjs) => void;
    onStartHeaderPanelSelect: (date: Dayjs) => void;
    onEndHeaderPanelSelect: (date: Dayjs) => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("confirm" | "cell-click" | "cell-mouse-enter" | "time-picker-select" | "range-mouse-leave" | "shortcut-click" | "shortcut-mouse-enter" | "shortcut-mouse-leave" | "start-header-label-click" | "end-header-label-click" | "start-header-select" | "end-header-select")[], "confirm" | "cell-click" | "cell-mouse-enter" | "time-picker-select" | "range-mouse-leave" | "shortcut-click" | "shortcut-mouse-enter" | "shortcut-mouse-leave" | "start-header-label-click" | "end-header-label-click" | "start-header-select" | "end-header-select", import("../../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    mode: {
        type: import("vue").PropType<Mode>;
        default: string;
    };
    value: {
        type: import("vue").PropType<Array<Dayjs | undefined>>;
        default: () => never[];
    };
    footerValue: {
        type: import("vue").PropType<Array<Dayjs | undefined>>;
    };
    timePickerValue: {
        type: import("vue").PropType<Dayjs[]>;
    };
    showTime: {
        type: BooleanConstructor;
    };
    showConfirmBtn: {
        type: BooleanConstructor;
    };
    prefixCls: {
        type: StringConstructor;
        required: true;
    };
    shortcuts: {
        type: import("vue").PropType<ShortcutType[]>;
        default: () => never[];
    };
    shortcutsPosition: {
        type: import("vue").PropType<DateRangePickerProps["shortcutsPosition"]>;
        default: string;
    };
    format: {
        type: StringConstructor;
        required: true;
    };
    dayStartOfWeek: {
        type: import("vue").PropType<WeekStart>;
        default: number;
    };
    disabledDate: {
        type: import("vue").PropType<RangeDisabledDate>;
    };
    disabledTime: {
        type: import("vue").PropType<RangeDisabledTime>;
    };
    timePickerProps: {
        type: import("vue").PropType<DateRangePickerProps["timePickerProps"]>;
    };
    extra: {
        type: import("vue").PropType<RenderFunc>;
    };
    dateRender: {
        type: import("vue").PropType<RenderFunc>;
    };
    startHeaderProps: {
        type: import("vue").PropType<StartHeaderProps>;
        default: () => {};
    };
    endHeaderProps: {
        type: import("vue").PropType<StartHeaderProps>;
        default: () => {};
    };
    confirmBtnDisabled: {
        type: BooleanConstructor;
    };
    disabled: {
        type: import("vue").PropType<boolean[]>;
        default: () => boolean[];
    };
    visible: {
        type: BooleanConstructor;
    };
    startHeaderMode: {
        type: import("vue").PropType<"year" | "month">;
    };
    endHeaderMode: {
        type: import("vue").PropType<"year" | "month">;
    };
    abbreviation: {
        type: BooleanConstructor;
    };
}>> & Readonly<{
    onConfirm?: ((...args: any[]) => any) | undefined;
    "onCell-click"?: ((...args: any[]) => any) | undefined;
    "onCell-mouse-enter"?: ((...args: any[]) => any) | undefined;
    "onTime-picker-select"?: ((...args: any[]) => any) | undefined;
    "onRange-mouse-leave"?: ((...args: any[]) => any) | undefined;
    "onShortcut-click"?: ((...args: any[]) => any) | undefined;
    "onShortcut-mouse-enter"?: ((...args: any[]) => any) | undefined;
    "onShortcut-mouse-leave"?: ((...args: any[]) => any) | undefined;
    "onStart-header-label-click"?: ((...args: any[]) => any) | undefined;
    "onEnd-header-label-click"?: ((...args: any[]) => any) | undefined;
    "onStart-header-select"?: ((...args: any[]) => any) | undefined;
    "onEnd-header-select"?: ((...args: any[]) => any) | undefined;
}>, {
    value: (Dayjs | undefined)[];
    mode: Mode;
    disabled: boolean[];
    visible: boolean;
    dayStartOfWeek: WeekStart;
    showTime: boolean;
    shortcuts: ShortcutType[];
    abbreviation: boolean;
    shortcutsPosition: "bottom" | "left" | "right";
    showConfirmBtn: boolean;
    confirmBtnDisabled: boolean;
    startHeaderProps: StartHeaderProps;
    endHeaderProps: StartHeaderProps;
}>;
export default _default;
