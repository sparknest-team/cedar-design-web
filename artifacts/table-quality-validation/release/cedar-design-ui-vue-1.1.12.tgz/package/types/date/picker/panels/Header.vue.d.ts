import { PropType } from 'vue';
import type { Dayjs } from 'dayjs';
import { HeaderIcons, Mode } from '../types';
type ClickCallbackFunc = (payload: MouseEvent) => void;
export type HeaderLabelClickFunc = (label: 'year' | 'month') => void;
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    prefixCls: {
        type: StringConstructor;
        required: true;
    };
    title: {
        type: StringConstructor;
        required: true;
    };
    mode: {
        type: import("vue").PropType<Mode>;
        default: string;
    };
    value: {
        type: import("vue").PropType<Dayjs>;
    };
    icons: {
        type: import("vue").PropType<HeaderIcons>;
    };
    onPrev: {
        type: import("vue").PropType<ClickCallbackFunc>;
    };
    onSuperPrev: {
        type: import("vue").PropType<ClickCallbackFunc>;
    };
    onNext: {
        type: import("vue").PropType<ClickCallbackFunc>;
    };
    onSuperNext: {
        type: import("vue").PropType<ClickCallbackFunc>;
    };
    onLabelClick: {
        type: import("vue").PropType<HeaderLabelClickFunc>;
    };
}>, {
    showPrev: import("vue").ComputedRef<boolean>;
    showSuperPrev: import("vue").ComputedRef<boolean>;
    showNext: import("vue").ComputedRef<boolean>;
    showSuperNext: import("vue").ComputedRef<boolean>;
    year: import("vue").ComputedRef<string>;
    month: import("vue").ComputedRef<string>;
    getIconClassName: (show?: boolean) => (string | {
        [x: string]: boolean;
    })[];
    previousYearLabel: import("vue").ComputedRef<string>;
    previousMonthLabel: import("vue").ComputedRef<string>;
    nextMonthLabel: import("vue").ComputedRef<string>;
    nextYearLabel: import("vue").ComputedRef<string>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "label-click"[], "label-click", import("../../../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    prefixCls: {
        type: StringConstructor;
        required: true;
    };
    title: {
        type: StringConstructor;
        required: true;
    };
    mode: {
        type: import("vue").PropType<Mode>;
        default: string;
    };
    value: {
        type: import("vue").PropType<Dayjs>;
    };
    icons: {
        type: import("vue").PropType<HeaderIcons>;
    };
    onPrev: {
        type: import("vue").PropType<ClickCallbackFunc>;
    };
    onSuperPrev: {
        type: import("vue").PropType<ClickCallbackFunc>;
    };
    onNext: {
        type: import("vue").PropType<ClickCallbackFunc>;
    };
    onSuperNext: {
        type: import("vue").PropType<ClickCallbackFunc>;
    };
    onLabelClick: {
        type: import("vue").PropType<HeaderLabelClickFunc>;
    };
}>> & Readonly<{
    "onLabel-click"?: ((...args: any[]) => any) | undefined;
}>, {
    mode: Mode;
}>;
export default _default;
