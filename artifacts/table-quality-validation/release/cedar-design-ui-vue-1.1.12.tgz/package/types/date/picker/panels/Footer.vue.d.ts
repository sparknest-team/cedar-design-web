declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    prefixCls: {
        type: StringConstructor;
        required: true;
    };
    showTodayBtn: {
        type: BooleanConstructor;
    };
    showConfirmBtn: {
        type: BooleanConstructor;
    };
    confirmBtnDisabled: {
        type: BooleanConstructor;
    };
}>, {
    datePickerT: (key: string, ...args: any[]) => any;
    onTodayClick: () => void;
    onConfirmBtnClick: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("today-btn-click" | "confirm-btn-click")[], "today-btn-click" | "confirm-btn-click", import("../../../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    prefixCls: {
        type: StringConstructor;
        required: true;
    };
    showTodayBtn: {
        type: BooleanConstructor;
    };
    showConfirmBtn: {
        type: BooleanConstructor;
    };
    confirmBtnDisabled: {
        type: BooleanConstructor;
    };
}>> & Readonly<{
    "onToday-btn-click"?: ((...args: any[]) => any) | undefined;
    "onConfirm-btn-click"?: ((...args: any[]) => any) | undefined;
}>, {
    showTodayBtn: boolean;
    showConfirmBtn: boolean;
    confirmBtnDisabled: boolean;
}>;
export default _default;
