import type { DateDisabledTime, DateRules } from './date-rules';
import { type DateSide } from './date-value';
import type { DisabledTime } from './time-constraints';
/** Evaluate only the requested candidate; quick choices do not need every second in a minute. */
export declare function dateTimeDisabledPredicates(current: Date, options: DateRules, side?: DateSide): DisabledTime;
/** Hierarchical time constraints: a partly available hour/minute must remain selectable. */
export declare function dateTimeDisabledRules(current: Date, options: DateRules, side?: DateSide): DateDisabledTime;
