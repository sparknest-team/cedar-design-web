import dayjs from 'dayjs';
import { type DateFormatMode } from './date-format';
import { type DateLocaleOptions } from './date-locale';
export type DateValue = Date | string | number;
export type DateSelection = null | DateValue | (DateValue | null | undefined)[] | undefined;
export type DateSide = 'start' | 'end';
export interface DateValueOptions extends DateLocaleOptions {
    timeZone?: string;
    type?: DateFormatMode;
    showTime?: boolean;
    format?: string | ((date: Date) => string);
    valueFormat?: string;
}
export declare function dateDisplayFormat(options?: DateValueOptions): string;
export declare function dateUsesSeconds(options?: DateValueOptions): boolean;
export declare function dateValueFormat(options?: DateValueOptions): string;
export declare function parseDateValue(value: DateValue | null | undefined, options?: DateValueOptions): dayjs.Dayjs | undefined;
/** 手输文本遵守展示 format 与界面语言，不能当作模型 valueFormat 解析。 */
export declare function parseDateText(text: string, options?: DateValueOptions): dayjs.Dayjs | undefined;
export declare function outputDateValue(date: Date, options?: DateValueOptions): DateValue;
export declare function formatDateValue(value: DateValue | null | undefined, options?: DateValueOptions): string;
export declare function dateEventPayload(value: DateSelection, options?: DateValueOptions): {
    dates: (Date | undefined)[];
    texts: string[];
} | {
    dates: Date | undefined;
    texts: string;
};
export declare function sameDateSelection(a: DateSelection, b: DateSelection, options?: DateValueOptions): boolean;
