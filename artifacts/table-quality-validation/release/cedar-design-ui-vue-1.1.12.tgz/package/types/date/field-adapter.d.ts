import type { FieldPresentationAdapter } from "../_components/field-presentation/with-field-presentation";
export declare function dateFieldAdapter(range: boolean): FieldPresentationAdapter;
