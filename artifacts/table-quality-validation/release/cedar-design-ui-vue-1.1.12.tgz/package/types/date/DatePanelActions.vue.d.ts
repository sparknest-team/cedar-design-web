type __VLS_Props = {
    showNow: boolean;
    showConfirm: boolean;
    nowDisabled: boolean;
    canConfirm: boolean;
};
declare var __VLS_1: {
    confirm: () => void;
    disabled: boolean;
    selectNow: () => void;
    nowDisabled: boolean;
};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_component: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    confirm: () => any;
    "select-now": () => any;
}, string, import("../vue-compat").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onConfirm?: (() => any) | undefined;
    "onSelect-now"?: (() => any) | undefined;
}>, {}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
