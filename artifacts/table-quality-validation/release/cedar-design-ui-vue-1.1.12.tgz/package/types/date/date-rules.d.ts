import { type DateSelection, type DateSide, type DateValue, type DateValueOptions } from './date-value';
export interface DateDisabledTime {
    disabledHours?: () => number[];
    disabledMinutes?: (hour: number) => number[];
    disabledSeconds?: (hour: number, minute: number) => number[];
}
export interface DateRules extends DateValueOptions {
    min?: DateValue;
    max?: DateValue;
    disabledDate?: (date: Date, side: DateSide) => boolean;
    disabledTime?: (date: Date, side: DateSide) => DateDisabledTime;
}
export declare function isDateDisabled(value: DateValue | null | undefined, options?: DateRules, side?: DateSide): boolean;
/** Calendar day cells ignore time precision only after parsing the original model and bounds. */
export declare function isCalendarDateDisabled(value: DateValue | null | undefined, options?: DateRules, side?: DateSide): boolean;
export declare function isDateEndpointSelectionValid(value: DateSelection, options?: DateRules, endpoint?: number): boolean;
export declare function isDateSelectionValid(value: DateSelection, options?: DateRules, range?: boolean, multiple?: boolean): boolean;
