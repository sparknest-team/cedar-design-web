import type { ComputedRef, ExtractPropTypes, Ref } from 'vue';
import type { pickerFieldProps } from '../_components/picker-field/props';
import type { DateRangeProps } from '../date-range/props';
import type { DateSelection } from './date-value';
import type { DateProps } from './props';
export type DateFieldProps = DateProps | DateRangeProps;
export type DateFieldControlProps = Partial<import("vue").ExtractPropTypes<typeof pickerFieldProps>>;
export interface DateFieldState {
    open: import("vue").Ref<boolean>;
    setOpen: (value: boolean) => void;
    draft: import("vue").Ref<DateSelection>;
    canConfirm: import("vue").ComputedRef<boolean>;
    disabled: import("vue").ComputedRef<boolean>;
    readonly: import("vue").ComputedRef<boolean>;
    disabledParts: import("vue").ComputedRef<boolean[]>;
    controlProps: import("vue").ComputedRef<DateFieldControlProps>;
    feedback: import("vue").Ref<string | undefined>;
    focus: () => void;
    blur: () => void;
    click: (event: Event) => void;
    clear: () => boolean;
    initialize: (value: DateSelection) => boolean;
    select: (value: DateSelection, commit?: boolean) => boolean;
    confirm: (value?: DateSelection) => boolean;
    cancel: () => void;
    commitText: (value: string[]) => void;
}
export interface DateFieldContentProps {
    fieldProps: DateFieldProps;
    range: boolean;
    rootClass?: string;
    state: DateFieldState;
}
