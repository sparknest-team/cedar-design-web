/** Shared date-format rules, copied independently into each library. */
export type DateFormatMode = 'date' | 'month' | 'year' | 'week' | 'quarter';
export declare function getDefaultFormat(mode?: DateFormatMode, showTime?: boolean, useSeconds?: boolean): "YYYY-MM-DD HH:mm:ss" | "YYYY" | "YYYY-MM-DD" | "YYYY-MM" | "YYYY-MM-DD HH:mm" | "gggg-wo" | "YYYY-[Q]Q";
/** Week and quarter labels are not their serialized model formats. */
export declare function getDefaultValueFormat(mode?: DateFormatMode, showTime?: boolean, useSeconds?: boolean): "YYYY-MM-DD HH:mm:ss" | "YYYY" | "YYYY-MM-DD" | "YYYY-MM" | "YYYY-MM-DD HH:mm" | "gggg-wo" | "YYYY-[Q]Q";
