declare var __VLS_16: string | number, __VLS_17: any;
type __VLS_Slots = {} & {
    [K in NonNullable<typeof __VLS_16>]?: (props: typeof __VLS_17) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<import("./date-value.ts").DateValue | undefined>>;
        default: undefined;
    };
    modelValue: import("vue").PropType<import("./date-value.ts").DateValue | null>;
    defaultValue: import("vue").PropType<import("./date-value.ts").DateValue>;
    showNowButton: {
        type: BooleanConstructor;
        default: boolean;
    };
    readonly: BooleanConstructor;
    disabled: BooleanConstructor;
    dayStartOfWeek: {
        type: import("vue").PropType<import("./panel-props.ts").DateWeekStart>;
        default: number;
        validator: (value: number) => boolean;
    };
    timePickerProps: {
        type: import("vue").PropType<import("./time-picker-options.ts").DateTimePickerOptions>;
    };
    abbreviation: {
        type: BooleanConstructor;
        default: boolean;
    };
    showCurrent: {
        type: BooleanConstructor;
        default: boolean;
    };
    shortcuts: {
        type: import("vue").PropType<import("./panel-tools-props.ts").DateShortcut[]>;
        default: () => never[];
    };
    shortcutsPosition: {
        type: import("vue").PropType<import("./panel-tools-props.ts").DateShortcutsPosition>;
        default: string;
    };
    previewShortcut: {
        type: BooleanConstructor;
        default: boolean;
    };
    pickerValue: import("vue").PropType<import("./date-value.ts").DateSelection>;
    defaultPickerValue: import("vue").PropType<import("./date-value.ts").DateSelection>;
    type: {
        type: import("vue").PropType<import("./date-format.ts").DateFormatMode>;
        default: string;
        validator: (value: string) => boolean;
    };
    timeZone: StringConstructor;
    showTime: BooleanConstructor;
    format: import("vue").PropType<import("./date-value.ts").DateValueOptions["format"]>;
    valueFormat: StringConstructor;
    min: import("vue").PropType<import("./date-value.ts").DateValue>;
    max: import("vue").PropType<import("./date-value.ts").DateValue>;
    disabledDate: import("vue").PropType<import("./date-rules.ts").DateRules["disabledDate"]>;
    disabledTime: import("vue").PropType<import("./date-rules.ts").DateRules["disabledTime"]>;
    disableConfirm: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    select: (value: import("./date-value.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any;
    change: (value: import("./date-value.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any;
    confirm: (value: import("./date-value.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any;
    "update:modelValue": (value: import("./date-value.ts").DateSelection) => any;
    "select-shortcut": (shortcut: import("./panel-tools-props.ts").DateShortcut) => any;
    "picker-value-change": (value: import("./date-value.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any;
    "update:pickerValue": (value: import("./date-value.ts").DateSelection) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<import("./date-value.ts").DateValue | undefined>>;
        default: undefined;
    };
    modelValue: import("vue").PropType<import("./date-value.ts").DateValue | null>;
    defaultValue: import("vue").PropType<import("./date-value.ts").DateValue>;
    showNowButton: {
        type: BooleanConstructor;
        default: boolean;
    };
    readonly: BooleanConstructor;
    disabled: BooleanConstructor;
    dayStartOfWeek: {
        type: import("vue").PropType<import("./panel-props.ts").DateWeekStart>;
        default: number;
        validator: (value: number) => boolean;
    };
    timePickerProps: {
        type: import("vue").PropType<import("./time-picker-options.ts").DateTimePickerOptions>;
    };
    abbreviation: {
        type: BooleanConstructor;
        default: boolean;
    };
    showCurrent: {
        type: BooleanConstructor;
        default: boolean;
    };
    shortcuts: {
        type: import("vue").PropType<import("./panel-tools-props.ts").DateShortcut[]>;
        default: () => never[];
    };
    shortcutsPosition: {
        type: import("vue").PropType<import("./panel-tools-props.ts").DateShortcutsPosition>;
        default: string;
    };
    previewShortcut: {
        type: BooleanConstructor;
        default: boolean;
    };
    pickerValue: import("vue").PropType<import("./date-value.ts").DateSelection>;
    defaultPickerValue: import("vue").PropType<import("./date-value.ts").DateSelection>;
    type: {
        type: import("vue").PropType<import("./date-format.ts").DateFormatMode>;
        default: string;
        validator: (value: string) => boolean;
    };
    timeZone: StringConstructor;
    showTime: BooleanConstructor;
    format: import("vue").PropType<import("./date-value.ts").DateValueOptions["format"]>;
    valueFormat: StringConstructor;
    min: import("vue").PropType<import("./date-value.ts").DateValue>;
    max: import("vue").PropType<import("./date-value.ts").DateValue>;
    disabledDate: import("vue").PropType<import("./date-rules.ts").DateRules["disabledDate"]>;
    disabledTime: import("vue").PropType<import("./date-rules.ts").DateRules["disabledTime"]>;
    disableConfirm: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    onSelect?: ((value: import("./date-value.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any) | undefined;
    onChange?: ((value: import("./date-value.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any) | undefined;
    onConfirm?: ((value: import("./date-value.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any) | undefined;
    "onUpdate:modelValue"?: ((value: import("./date-value.ts").DateSelection) => any) | undefined;
    "onSelect-shortcut"?: ((shortcut: import("./panel-tools-props.ts").DateShortcut) => any) | undefined;
    "onPicker-value-change"?: ((value: import("./date-value.ts").DateSelection, dates: Date | (Date | undefined)[] | undefined, texts: string | string[]) => any) | undefined;
    "onUpdate:pickerValue"?: ((value: import("./date-value.ts").DateSelection) => any) | undefined;
}>, {
    readonly: boolean;
    type: import("./date-format.ts").DateFormatMode;
    disabled: boolean;
    emptyValue: import("../_utils/empty-value.ts").EmptyValue<import("./date-value.ts").DateValue | undefined>;
    disableConfirm: boolean;
    dayStartOfWeek: import("./panel-props.ts").DateWeekStart;
    showTime: boolean;
    shortcuts: import("./panel-tools-props.ts").DateShortcut[];
    abbreviation: boolean;
    showCurrent: boolean;
    showNowButton: boolean;
    shortcutsPosition: import("./panel-tools-props.ts").DateShortcutsPosition;
    previewShortcut: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
