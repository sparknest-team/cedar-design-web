import type { PropType } from 'vue';
import type { DateFormatMode } from './date-format';
import type { DateRules } from './date-rules';
import type { DateValue, DateValueOptions } from './date-value';
export declare const dateRuleProps: {
    /** 日期精度；展示方式由各端 presentation 文件决定。 */
    type: {
        type: import("vue").PropType<DateFormatMode>;
        default: string;
        validator: (value: string) => boolean;
    };
    timeZone: StringConstructor;
    showTime: BooleanConstructor;
    format: import("vue").PropType<DateValueOptions["format"]>;
    valueFormat: StringConstructor;
    min: import("vue").PropType<DateValue>;
    max: import("vue").PropType<DateValue>;
    disabledDate: import("vue").PropType<DateRules["disabledDate"]>;
    disabledTime: import("vue").PropType<DateRules["disabledTime"]>;
    /** 默认选择即提交；设为 false 可先预览再确认。字段弹层另行控制提交。 */
    disableConfirm: {
        type: BooleanConstructor;
        default: boolean;
    };
};
export declare const dateSingleValueProps: {
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value").EmptyValue<DateValue | undefined>>;
        default: undefined;
    };
    modelValue: import("vue").PropType<DateValue | null>;
    defaultValue: import("vue").PropType<DateValue>;
};
export declare const dateRangeValueProps: {
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value").EmptyValue<(DateValue | undefined)[] | undefined>>;
        default: undefined;
    };
    modelValue: import("vue").PropType<(DateValue | undefined)[] | null>;
    defaultValue: import("vue").PropType<(DateValue | undefined)[]>;
};
