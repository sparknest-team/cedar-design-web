import { type PropType } from 'vue';
import type { DateFieldProps } from './field-state';
declare var __VLS_13: string | number, __VLS_14: any;
type __VLS_Slots = {} & {
    [K in NonNullable<typeof __VLS_13>]?: (props: typeof __VLS_14) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    fieldProps: {
        type: import("vue").PropType<DateFieldProps>;
        required: true;
    };
    range: BooleanConstructor;
    endpointSelection: BooleanConstructor;
    rootClass: StringConstructor;
}>, {
    focus: (index?: number) => void | undefined;
    blur: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    click: (...args: any[]) => void;
    focus: (...args: any[]) => void;
    clear: (...args: any[]) => void;
    select: (...args: any[]) => void;
    blur: (...args: any[]) => void;
    change: (...args: any[]) => void;
    "update:open": (...args: any[]) => void;
    "open-change": (...args: any[]) => void;
    "update:modelValue": (...args: any[]) => void;
    "select-shortcut": (...args: any[]) => void;
    "picker-value-change": (...args: any[]) => void;
    "update:pickerValue": (...args: any[]) => void;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    fieldProps: {
        type: import("vue").PropType<DateFieldProps>;
        required: true;
    };
    range: BooleanConstructor;
    endpointSelection: BooleanConstructor;
    rootClass: StringConstructor;
}>> & Readonly<{
    onClick?: ((...args: any[]) => any) | undefined;
    onFocus?: ((...args: any[]) => any) | undefined;
    onClear?: ((...args: any[]) => any) | undefined;
    onSelect?: ((...args: any[]) => any) | undefined;
    onBlur?: ((...args: any[]) => any) | undefined;
    onChange?: ((...args: any[]) => any) | undefined;
    "onUpdate:open"?: ((...args: any[]) => any) | undefined;
    "onOpen-change"?: ((...args: any[]) => any) | undefined;
    "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
    "onSelect-shortcut"?: ((...args: any[]) => any) | undefined;
    "onPicker-value-change"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pickerValue"?: ((...args: any[]) => any) | undefined;
}>, {
    range: boolean;
    endpointSelection: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
