import dayjs from 'dayjs';
import type { ConfigType } from 'dayjs';
import 'dayjs/locale/zh-cn.js';
import 'dayjs/locale/zh-tw.js';
import 'dayjs/locale/zh-hk.js';
import 'dayjs/locale/ja.js';
import 'dayjs/locale/fa.js';
/** 内部实例上下文，不是组件 locale Prop 或覆盖字典。 */
export declare const dateLocaleScopeKey: unique symbol;
export interface DateLocaleScope {
    language: string;
    weekStart: number;
}
export interface DateLocaleOptions {
    [dateLocaleScopeKey]?: Readonly<DateLocaleScope>;
}
export declare function scopeDateOptions<T extends object>(options: T, language: string, weekStart?: number): T & DateLocaleOptions;
export declare function dateLocaleName(options?: DateLocaleOptions): string;
export declare function scopedDate(value: ConfigType, options?: DateLocaleOptions): dayjs.Dayjs;
export declare function provideDateLocale(options: () => DateLocaleOptions): void;
export declare function useScopedDate(): (value: ConfigType) => dayjs.Dayjs;
/** 模型协议使用稳定英文日期数据，界面切换不改变模型解析。 */
export declare function dateModelLocaleName(options?: DateLocaleOptions): string;
