import { type DateSelection, type DateValueOptions } from './date-value';
export declare function calendarValueFormat(options: DateValueOptions): "YYYY-MM-DD HH:mm:ss" | "YYYY" | "YYYY-MM-DD" | "YYYY-MM" | "YYYY-MM-DD HH:mm" | "gggg-wo" | "YYYY-[Q]Q";
export declare function toCalendarValue(value: DateSelection, options: DateValueOptions): string | (string | undefined)[] | undefined;
export declare function fromCalendarValue(value: DateSelection, options: DateValueOptions, previous?: DateSelection): DateSelection;
