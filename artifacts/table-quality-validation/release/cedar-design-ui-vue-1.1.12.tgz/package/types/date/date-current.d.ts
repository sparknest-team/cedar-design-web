import { type ComputedRef } from 'vue';
import { type DateValueOptions } from './date-value';
export declare const dateCurrentProps: {
    /** 仅控制日历中的当前日期高亮，不改变选择。 */
    showCurrent: {
        type: BooleanConstructor;
        default: boolean;
    };
};
export declare const dateNowProps: {
    /** 单选面板的选择当前按钮，仍走普通选择与确认校验。 */
    showNowButton: {
        type: BooleanConstructor;
        default: boolean;
    };
};
export declare const dateRangeInteractionProps: {
    /** 交互候选反序时，是否连同日期交换时间；模型/手输/快捷项不重排。 */
    exchangeTime: {
        type: BooleanConstructor;
        default: boolean;
    };
};
export declare function provideDateCurrent(value: () => boolean): void;
export declare function useDateCurrent(fallback?: () => boolean): import("vue").ComputedRef<boolean>;
export declare function currentDateValue(options: DateValueOptions & {
    dayStartOfWeek?: number;
}, now?: Date): import("./date-value").DateValue | undefined;
