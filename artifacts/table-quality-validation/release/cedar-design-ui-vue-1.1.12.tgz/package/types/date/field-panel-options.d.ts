import type { DateFieldProps } from "./field-state";
import type { DatePanelOptions } from "./panel-state";
export declare function dateFieldPanelOptions(options: DateFieldProps, range: boolean): DatePanelOptions & Record<string, unknown>;
