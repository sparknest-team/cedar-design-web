import { type PropType } from 'vue';
import type { DatePanelOptions } from './panel-state';
declare var __VLS_19: string, __VLS_20: any, __VLS_30: {
    confirm: () => void;
    disabled: boolean;
    selectNow: () => void;
    nowDisabled: boolean;
};
type __VLS_Slots = {} & {
    [K in NonNullable<typeof __VLS_19>]?: (props: typeof __VLS_20) => any;
} & {
    actions?: (props: typeof __VLS_30) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    options: {
        type: import("vue").PropType<DatePanelOptions>;
        required: true;
    };
    range: BooleanConstructor;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    select: (...args: any[]) => void;
    change: (...args: any[]) => void;
    confirm: (...args: any[]) => void;
    "update:modelValue": (...args: any[]) => void;
    "select-shortcut": (...args: any[]) => void;
    "picker-value-change": (...args: any[]) => void;
    "update:pickerValue": (...args: any[]) => void;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    options: {
        type: import("vue").PropType<DatePanelOptions>;
        required: true;
    };
    range: BooleanConstructor;
}>> & Readonly<{
    onSelect?: ((...args: any[]) => any) | undefined;
    onChange?: ((...args: any[]) => any) | undefined;
    onConfirm?: ((...args: any[]) => any) | undefined;
    "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
    "onSelect-shortcut"?: ((...args: any[]) => any) | undefined;
    "onPicker-value-change"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pickerValue"?: ((...args: any[]) => any) | undefined;
}>, {
    range: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
