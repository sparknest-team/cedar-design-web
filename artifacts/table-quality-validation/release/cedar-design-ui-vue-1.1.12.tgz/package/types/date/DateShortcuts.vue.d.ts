import type { DateShortcut, DateShortcutsPosition } from './panel-tools-props';
type __VLS_Props = {
    shortcuts: DateShortcut[];
    position: DateShortcutsPosition;
    blocked: boolean;
};
declare const _default: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    preview: (shortcut?: DateShortcut | undefined) => any;
    choose: (shortcut: DateShortcut) => any;
}, string, import("../vue-compat").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onPreview?: ((shortcut?: DateShortcut | undefined) => any) | undefined;
    onChoose?: ((shortcut: DateShortcut) => any) | undefined;
}>, {}>;
export default _default;
