declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    bordered: BooleanConstructor;
}>, {
    classNames: string[];
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    bordered: BooleanConstructor;
}>> & Readonly<{}>, {
    bordered: boolean;
}>;
export default _default;
