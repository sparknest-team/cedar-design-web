declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    scrollable: BooleanConstructor;
}>, {
    classNames: string[];
    scrollRef: import("vue").Ref<HTMLElement | undefined>;
    scrollTo: {
        (options: ScrollToOptions): void;
        (x: number, y: number): void;
    };
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    scroll: (event: Event) => true;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    scrollable: BooleanConstructor;
}>> & Readonly<{
    onScroll?: ((event: Event) => any) | undefined;
}>, {
    scrollable: boolean;
}>;
export default _default;
