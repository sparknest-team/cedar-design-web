import { InjectionKey } from 'vue';
export interface LayoutSiderContext {
    onSiderMount?: (id: string) => void;
    onSiderUnMount?: (id: string) => void;
}
export declare const LayoutSiderInjectionKey: import("vue").InjectionKey<LayoutSiderContext>;
export interface SiderContext {
    collapsed: boolean;
    collapsedWidth: string | number;
}
export declare const SiderInjectionKey: import("vue").InjectionKey<SiderContext>;
