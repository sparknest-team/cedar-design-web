import _Scrollbar from './Scrollbar.vue';
import { scrollbarProps } from './props';
declare const Scrollbar: import('../_utils/global-config').ComponentWithInstall<typeof _Scrollbar>;
export type ScrollbarInstance = InstanceType<typeof _Scrollbar>;
export type { ScrollbarProps } from './types';
export declare const _ScrollbarComponent: typeof Scrollbar;
export { Scrollbar };
export { scrollbarProps };
export default Scrollbar;
