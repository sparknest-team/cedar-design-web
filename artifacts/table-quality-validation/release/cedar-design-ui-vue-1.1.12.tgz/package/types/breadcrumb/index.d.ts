import _Breadcrumb from './breadcrumb';
import _BreadcrumbItem from './breadcrumb-item';
import { breadcrumbProps, breadcrumbItemProps } from './props';
declare const Breadcrumb: import('../_utils/global-config').CedarComponentWithInstall<typeof _Breadcrumb & {
    Item: typeof _BreadcrumbItem;
}>;
export type BreadcrumbInstance = InstanceType<typeof _Breadcrumb>;
export type BreadcrumbItemInstance = InstanceType<typeof _BreadcrumbItem>;
export type { BreadcrumbRoute, BreadcrumbMoreIconSlotData } from './types';
export type { BreadcrumbProps, BreadcrumbItemProps } from './props';
export { breadcrumbProps, breadcrumbItemProps };
export { _BreadcrumbItem as BreadcrumbItem };
export { _Breadcrumb as Breadcrumb };
export declare const _BreadcrumbComponent: typeof Breadcrumb;
export declare const _BreadcrumbItemComponent: typeof _BreadcrumbItem;
export default Breadcrumb;
