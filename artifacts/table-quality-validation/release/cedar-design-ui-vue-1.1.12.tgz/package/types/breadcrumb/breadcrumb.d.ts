import type { BreadcrumbRoute } from './types';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    maxCount: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    routes: {
        type: import("vue").PropType<BreadcrumbRoute[]>;
    };
    separator: {
        type: import("vue").PropType<string | number>;
        default: string;
    };
}>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    select: (_route: BreadcrumbRoute, _event?: Event) => true;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    maxCount: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    routes: {
        type: import("vue").PropType<BreadcrumbRoute[]>;
    };
    separator: {
        type: import("vue").PropType<string | number>;
        default: string;
    };
}>> & Readonly<{
    onSelect?: ((_route: BreadcrumbRoute, _event?: Event | undefined) => any) | undefined;
}>, {
    separator: string | number;
    maxCount: number;
}>;
export default _default;
