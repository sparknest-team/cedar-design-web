import { type VNode } from 'vue';
export declare function flatChildren(nodes: import("vue").VNode[]): import("vue").VNode[];
