import { type FilterFormField, type FilterFormSlots } from './types';
type __VLS_Slots = FilterFormSlots;
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    modelValue: {
        type: import("vue").PropType<Record<string, unknown>>;
        default: undefined;
    };
    defaultValue: {
        type: import("vue").PropType<Record<string, unknown>>;
        default: () => {};
    };
    fields: {
        type: import("vue").PropType<FilterFormField[]>;
        default: () => never[];
    };
    fieldMap: {
        type: import("vue").PropType<import("./types").FilterFormFieldMap>;
        default: () => {};
    };
    rules: {
        type: import("vue").PropType<Record<string, import("..").FieldRule | import("..").FieldRule[]>>;
    };
    collapsed: {
        type: BooleanConstructor;
        default: boolean;
    };
    collapsible: {
        type: BooleanConstructor;
        default: boolean;
    };
    cols: {
        type: import("vue").PropType<number | Record<string, number>>;
        default: () => {
            xs: number;
            sm: number;
            md: number;
            lg: number;
            xl: number;
            xxl: number;
        };
    };
    gridProps: {
        type: import("vue").PropType<Record<string, unknown>>;
    };
    changeDebounce: {
        type: NumberConstructor;
        default: number;
    };
}>, {
    formRef: import("vue").Ref<(import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        model: {
            type: ObjectConstructor;
            default: () => {};
        };
        layout: {
            type: import("vue").PropType<import("..").FormLayout>;
            default: string;
        };
        size: {
            type: import("vue").PropType<import("..").ComponentSize>;
        };
        disabled: {
            type: BooleanConstructor;
            default: undefined;
        };
        readonly: {
            type: BooleanConstructor;
            default: undefined;
        };
        rules: {
            type: import("vue").PropType<Record<string, import("..").FieldRule | import("..").FieldRule[]>>;
        };
        id: {
            type: StringConstructor;
        };
        scrollToError: {
            type: import("vue").PropType<"start" | "end">;
        };
        scrollToErrorOffsetY: {
            type: (StringConstructor | NumberConstructor)[];
            default: number;
        };
        contentAlign: {
            type: import("vue").PropType<import("..").FormContentAlign>;
            default: string;
        };
        labelAlign: {
            type: import("vue").PropType<import("..").FormLabelAlign>;
            default: string;
        };
        labelColProps: {
            type: import("vue").PropType<import("..").FormColProps>;
            default: () => {
                span: number;
                offset: number;
            };
        };
        wrapperColProps: {
            type: import("vue").PropType<import("..").FormColProps>;
            default: () => {
                span: number;
                offset: number;
            };
        };
        autoLabelWidth: {
            type: BooleanConstructor;
            default: boolean;
        };
        labelColStyle: import("vue").PropType<import("vue").CSSProperties>;
        wrapperColStyle: import("vue").PropType<import("vue").CSSProperties>;
        labelColFlex: import("vue").PropType<import("..").FormLabelFlex>;
        editMode: {
            type: import("vue").PropType<import("..").FieldEditMode>;
            default: undefined;
            validator: (value: string) => boolean;
        };
        readPretty: {
            type: BooleanConstructor;
            default: undefined;
        };
        emptyValues: {
            type: import("vue").PropType<readonly unknown[]>;
            default: undefined;
        };
        emptyText: {
            type: StringConstructor;
            default: undefined;
        };
    }>> & Readonly<{
        onReset?: ((ev: Event) => any) | undefined;
        onSubmit?: ((data: {
            values: Record<string, any>;
            errors: Record<string, import("..").ValidatedError> | undefined;
        }, ev: Event) => any) | undefined;
        "onSubmit-success"?: ((values: Record<string, any>, ev: Event) => any) | undefined;
        "onSubmit-failed"?: ((data: {
            values: Record<string, any>;
            errors: Record<string, import("..").FormSubmitError>;
        }, ev: Event) => any) | undefined;
    }>, {
        cls: import("vue").ComputedRef<(string | {
            [x: string]: boolean;
        })[]>;
        formRef: import("vue").Ref<HTMLFormElement | undefined>;
        handleSubmit: (e: Event) => Promise<void> | undefined;
        handleReset: (e: Event) => void;
        innerValidate: (callback?: (errors: import("../form/form-controller").FormValidateErrors<import("..").ValidatedError>) => void) => Promise<import("../form/form-controller").FormValidateErrors<import("..").ValidatedError>>;
        innerValidateField: (field: string | string[], callback?: (errors: import("../form/form-controller").FormValidateErrors<import("..").ValidatedError>) => void) => Promise<import("../form/form-controller").FormValidateErrors<import("..").ValidatedError>>;
        innerResetFields: (field?: string | string[]) => void;
        innerClearValidate: (field?: string | string[]) => void;
        innerSetFields: (data: Record<string, import("..").FieldData>) => void;
        innerScrollToField: (field: string, options?: import("../form/scroll-options").FormScrollOptions, offset?: number, isEligible?: () => boolean) => void;
    }, {}, {}, {
        validate(callback?: (errors: undefined | Record<string, import("..").ValidatedError>) => void): Promise<undefined | Record<string, import("..").ValidatedError>>;
        validateField(field: string | string[], callback?: (errors: undefined | Record<string, import("..").ValidatedError>) => void): Promise<undefined | Record<string, import("..").ValidatedError>>;
        resetFields(field?: string | string[]): void;
        clearValidate(field?: string | string[]): void;
        setFields(data: Record<string, import("..").FieldData>): void;
        scrollToField(field: string): void;
    }, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        submit: (data: {
            values: Record<string, any>;
            errors: Record<string, import("..").ValidatedError> | undefined;
        }, ev: Event) => true;
        "submit-success": (values: Record<string, any>, ev: Event) => true;
        "submit-failed": (data: {
            values: Record<string, any>;
            errors: Record<string, import("..").FormSubmitError>;
        }, ev: Event) => true;
        reset: (ev: Event) => true;
    }, import("../vue-compat").PublicProps, {
        readonly: boolean;
        disabled: boolean;
        editMode: import("..").FieldEditMode;
        readPretty: boolean;
        emptyValues: readonly unknown[];
        emptyText: string;
        layout: import("..").FormLayout;
        model: Record<string, any>;
        scrollToErrorOffsetY: string | number;
        contentAlign: import("..").FormContentAlign;
        labelAlign: import("..").FormLabelAlign;
        labelColProps: Partial<{
            span: number;
        }> & Omit<{
            readonly span: number;
            readonly xs?: import("..").ColBreakpoint | undefined;
            readonly sm?: import("..").ColBreakpoint | undefined;
            readonly md?: import("..").ColBreakpoint | undefined;
            readonly lg?: import("..").ColBreakpoint | undefined;
            readonly xl?: import("..").ColBreakpoint | undefined;
            readonly order?: number | undefined;
            readonly flex?: import("..").FlexType | undefined;
            readonly offset?: number | undefined;
            readonly xxl?: import("..").ColBreakpoint | undefined;
            readonly onClick?: ((value: MouseEvent) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "span">;
        wrapperColProps: Partial<{
            span: number;
        }> & Omit<{
            readonly span: number;
            readonly xs?: import("..").ColBreakpoint | undefined;
            readonly sm?: import("..").ColBreakpoint | undefined;
            readonly md?: import("..").ColBreakpoint | undefined;
            readonly lg?: import("..").ColBreakpoint | undefined;
            readonly xl?: import("..").ColBreakpoint | undefined;
            readonly order?: number | undefined;
            readonly flex?: import("..").FlexType | undefined;
            readonly offset?: number | undefined;
            readonly xxl?: import("..").ColBreakpoint | undefined;
            readonly onClick?: ((value: MouseEvent) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "span">;
        autoLabelWidth: boolean;
    }, true> & {
        $slots: import("..").FormSlots;
    }) | undefined>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    change: (value: Record<string, unknown>, field: string) => any;
    "update:modelValue": (value: Record<string, unknown>) => any;
    "update:collapsed": (collapsed: boolean) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    modelValue: {
        type: import("vue").PropType<Record<string, unknown>>;
        default: undefined;
    };
    defaultValue: {
        type: import("vue").PropType<Record<string, unknown>>;
        default: () => {};
    };
    fields: {
        type: import("vue").PropType<FilterFormField[]>;
        default: () => never[];
    };
    fieldMap: {
        type: import("vue").PropType<import("./types").FilterFormFieldMap>;
        default: () => {};
    };
    rules: {
        type: import("vue").PropType<Record<string, import("..").FieldRule | import("..").FieldRule[]>>;
    };
    collapsed: {
        type: BooleanConstructor;
        default: boolean;
    };
    collapsible: {
        type: BooleanConstructor;
        default: boolean;
    };
    cols: {
        type: import("vue").PropType<number | Record<string, number>>;
        default: () => {
            xs: number;
            sm: number;
            md: number;
            lg: number;
            xl: number;
            xxl: number;
        };
    };
    gridProps: {
        type: import("vue").PropType<Record<string, unknown>>;
    };
    changeDebounce: {
        type: NumberConstructor;
        default: number;
    };
}>> & Readonly<{
    onChange?: ((value: Record<string, unknown>, field: string) => any) | undefined;
    "onUpdate:modelValue"?: ((value: Record<string, unknown>) => any) | undefined;
    "onUpdate:collapsed"?: ((collapsed: boolean) => any) | undefined;
}>, {
    modelValue: Record<string, unknown>;
    defaultValue: Record<string, unknown>;
    fields: FilterFormField[];
    cols: number | Record<string, number>;
    collapsed: boolean;
    fieldMap: import("./types").FilterFormFieldMap;
    collapsible: boolean;
    changeDebounce: number;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
