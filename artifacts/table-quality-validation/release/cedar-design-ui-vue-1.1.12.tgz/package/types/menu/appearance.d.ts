import type { MenuOptionSlots } from './types';
import type { MenuSubmenuTrigger } from './types';
import type { CSSProperties, Slots, Ref } from 'vue';
import type { MenuProps } from './props';
import type { MenuViewOptions } from './view';
export interface OptionState {
    optionSelected: import("vue").Ref<boolean>;
    disabled: import("vue").Ref<boolean>;
    size: import("vue").Ref<string>;
    isFocusing: import("vue").Ref<boolean>;
    labelVNode: import("vue").Ref<any>;
}
export declare function rootTriggerAppearance(props: MenuProps): {
    popupOffset: number;
    animationName: string;
    autoFitTransformOrigin: boolean;
    openedClass: string;
    disabled: boolean | undefined;
    placement: "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "left" | "left-start" | "left-end" | "right" | "right-start" | "right-end" | undefined;
    cover: boolean | undefined;
    popupContainer: import("..").PopupContainer | undefined;
    popupClass: string | Record<string, any> | unknown[] | undefined;
    popupTranslate: number[];
    autoFitPopupWidth: boolean | undefined;
    reference: import("./types").MenuReference | undefined;
    strategy: import("..").TriggerStrategy | undefined;
    mouseEnterDelay: number | undefined;
    mouseLeaveDelay: number | undefined;
    closeOnClickReference: boolean | undefined;
    alignPoint: boolean | undefined;
};
export declare function submenuTriggerAppearance(): {
    popupOffset: number;
    cascadeOptimization: boolean;
    mouseEnterDelay: number;
    mouseLeaveDelay: number;
    closeOnClickReference: boolean;
};
export declare function panelAppearance(props: {
    isEmpty: boolean;
    submenu: boolean;
    elevation: boolean | number;
}, slots: import("vue").Slots, style?: import("vue").CSSProperties): MenuViewOptions;
export declare function useOptionAppearance(props: {
    highlight: boolean;
    childrenTrigger: boolean;
}, state: OptionState, slots: MenuOptionSlots): import("vue").ComputedRef<MenuViewOptions>;
/** Hover needs a grace period: the popup sits `popupOffset` away, so a zero delay closes it mid-travel. */
export declare const menuDefaults: {
    unmountOnClose: boolean;
    closeOnClickReference: boolean;
    mouseEnterDelay: number;
    mouseLeaveDelay: number;
    submenuTrigger: MenuSubmenuTrigger;
};
