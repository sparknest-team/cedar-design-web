import type { InjectionKey, Ref } from 'vue';
import type { MenuSubmenuTrigger, MenuStrategy } from './types';
import type { MenuValue } from './types';
export interface MenuOptionInfo {
    value?: MenuValue;
    label?: any;
    disabled?: boolean;
}
export interface MenuContext {
    strategy: import("vue").Ref<MenuStrategy>;
    popupMaxHeight: import("vue").Ref<boolean | number>;
    modelValue?: import("vue").Ref<MenuValue>;
    /** Owned by the root so every level expands the same way. */
    submenuTrigger: import("vue").Ref<MenuSubmenuTrigger>;
    closeMenu?: () => void;
    onOptionClick: (value: MenuValue, option: MenuOptionInfo, ev: Event) => void;
}
export declare const menuInjectionKey: import("vue").InjectionKey<MenuContext>;
export interface MenuBranch {
    close(): void;
    allowClose(): void;
    focus?(): void;
}
export interface MenuLevel {
    visible: import("vue").Ref<boolean>;
    register(branch: MenuBranch): () => void;
    activate(branch?: MenuBranch): void;
    leave?: () => void;
}
export declare const menuLevelKey: import("vue").InjectionKey<MenuLevel>;
/** Private row depth for declarative MenuOption rendering callbacks. */
export declare const menuRenderLevelKey: import("vue").InjectionKey<Readonly<import("vue").Ref<number>>>;
