import type { PropType, VNodeChild } from 'vue';
import type { MenuFieldNames } from './selection';
import type { MenuOptionData } from './types';
export interface MenuOptionRenderers {
    label: (option: MenuOptionData, active: boolean, level: number) => import("vue").VNodeChild;
    icon: (option: MenuOptionData, active: boolean, level: number) => import("vue").VNodeChild;
    extra: (option: MenuOptionData, active: boolean, level: number) => import("vue").VNodeChild;
    hasIcon: (option: MenuOptionData) => boolean;
    hasExtra: (option: MenuOptionData) => boolean;
}
export declare const menuBranchProps: {
    option: {
        type: import("vue").PropType<MenuOptionData>;
        required: true;
    };
    fieldNames: import("vue").PropType<MenuFieldNames>;
    level: {
        type: NumberConstructor;
        default: number;
    };
    disabled: BooleanConstructor;
    renderers: {
        type: import("vue").PropType<MenuOptionRenderers>;
        required: true;
    };
};
