import type { PropType } from 'vue';
export declare const imagePreviewGroupProps: {
    images: import("vue").PropType<string[]>;
    modelValue: {
        type: NumberConstructor;
        default: undefined;
    };
    defaultValue: {
        type: NumberConstructor;
        default: number;
    };
    loop: {
        type: BooleanConstructor;
        default: boolean;
    };
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: {
        type: BooleanConstructor;
        default: boolean;
    };
    interaction: {
        type: import("vue").PropType<import("./api").ImageInteraction>;
        default: string;
    };
    popupContainer: {
        type: import("vue").PropType<import("..").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    lockScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    closable: {
        type: BooleanConstructor;
        default: boolean;
    };
    overlayClosable: {
        type: BooleanConstructor;
        default: boolean;
    };
    escToClose: {
        type: BooleanConstructor;
        default: boolean;
    };
    imagePreventDefault: BooleanConstructor;
    defaultScale: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    minScale: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    maxScale: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    scaleStep: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    wheelZoom: {
        type: BooleanConstructor;
        default: undefined;
    };
    keyboard: {
        type: BooleanConstructor;
        default: undefined;
    };
    draggable: {
        type: BooleanConstructor;
        default: boolean;
    };
    keepDragOffset: BooleanConstructor;
    showToolbar: {
        type: BooleanConstructor;
        default: boolean;
    };
    actionsLayout: import("vue").PropType<import("./api").ImagePreviewActionName[]>;
};
