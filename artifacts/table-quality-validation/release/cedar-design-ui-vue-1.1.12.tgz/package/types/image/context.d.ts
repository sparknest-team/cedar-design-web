import type { InjectionKey } from 'vue';
import type { PreviewGroupContext } from './api';
export type { PreviewGroupContext };
export declare const PreviewGroupInjectionKey: import("vue").InjectionKey<PreviewGroupContext>;
