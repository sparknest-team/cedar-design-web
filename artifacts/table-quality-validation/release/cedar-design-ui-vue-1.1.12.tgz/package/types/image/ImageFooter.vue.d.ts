declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    title: StringConstructor;
    description: StringConstructor;
}>, {
    n: (suffix?: string) => string;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    title: StringConstructor;
    description: StringConstructor;
}>> & Readonly<{}>, {}>;
export default _default;
