export declare const DEFAULT_COLUMN_MIN_WIDTH = 80;
export declare const DEFAULT_OPERATION_WIDTH = 40;
export interface WidthColumnInput {
    /** Stable layout identity, independent of the business field. */
    key?: string;
    dataIndex?: string;
    width?: number;
    minWidth?: number;
    _resizeWidth?: number;
    /** Keep this column out of proportional expansion. */
    exact?: boolean;
}
export interface ColumnWidthsInput {
    containerWidth: number;
    dataColumns: readonly WidthColumnInput[];
    operations: readonly {
        width?: number;
    }[];
    fit: boolean;
}
export interface ColumnWidthUpdate {
    index: number;
    width: number;
}
export interface ColumnWidthsResult {
    hasHorizontalOverflow: boolean;
    bodyWidth: number;
    columnRealWidth: Record<string, number>;
    /** Ordered writes preserve the legacy adapter's per-column mutation behavior. */
    widthUpdates: ColumnWidthUpdate[];
}
/**
 * Element Plus 风格列宽分配：
 * - 有 width（或拖拽宽度）→ 固定列
 * - 无 width → 弹性列：fit=true 时按 minWidth（默认 80）比例吸收剩余空间
 * - 列最小宽之和超过容器 → 开启横向滚动
 * - 列宽之和不足容器 → 剩余空间按各列基础宽度比例放大撑满（与 fit 无关；
 *   标记为 exact 的钉死列 不参与放大，保持原宽）
 */
export declare const calculateColumnWidths: ({ containerWidth, dataColumns: sourceColumns, operations, fit, }: ColumnWidthsInput) => ColumnWidthsResult;
