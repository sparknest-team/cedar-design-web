/** Minimal structural inputs: this module does not import the UI column model. */
export interface FrozenColumn {
    dataIndex?: string;
    fixed?: 'left' | 'right';
    width?: number;
    _resizeWidth?: number;
    _realWidth?: number;
    children?: readonly FrozenColumn[];
}
export interface FrozenOperation {
    name: string;
    fixed?: boolean;
    width?: number;
    _realWidth?: number;
}
export type LayoutMode = 'fixed' | 'auto';
export type LayoutDirection = 'ltr' | 'rtl';
/** LTR operation lookup deliberately uses the first matching name, as before. */
export declare function operationFixedOffset(column: FrozenOperation, operations: readonly FrozenOperation[]): number;
export declare function frozenColumnOffset(column: FrozenColumn, { dataColumns, operations, keyOf, }: {
    dataColumns: readonly FrozenColumn[];
    operations: readonly FrozenOperation[];
    /** The adapter owns special-column identity; the kernel knows no symbols. */
    keyOf: (column: FrozenColumn) => string | undefined;
}, mode?: LayoutMode, direction?: LayoutDirection): number;
export declare function operationStickyOffset(column: FrozenOperation, operations: readonly FrozenOperation[], direction?: LayoutDirection, dataColumns?: readonly FrozenColumn[], mode?: LayoutMode): number;
