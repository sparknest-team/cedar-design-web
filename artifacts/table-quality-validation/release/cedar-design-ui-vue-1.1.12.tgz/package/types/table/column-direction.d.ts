import type { ReadingDirection } from '../_utils/direction';
/** Stable visual partitions: public fixed sides are physical, normal columns retain reading order. */
export declare function orderPhysicalColumns<T>(items: T[], fixed: (item: T) => 'left' | 'right' | undefined, dir?: ReadingDirection): T[];
