import type { Slot } from 'vue';
export declare function forwardTableSlot(slot: import("vue").Slot | undefined): {
    default: import("vue").Slot | undefined;
    _: 2;
};
export declare function forwardTableColumnSlot(slot: import("vue").Slot): {
    default: (...args: unknown[]) => any[] | undefined;
    _: 2;
};
