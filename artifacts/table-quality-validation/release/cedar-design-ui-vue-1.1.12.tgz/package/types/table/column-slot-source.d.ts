export declare const TABLE_COLUMN_COMPONENT: unique symbol;
export declare function isComponentColumn(column: object): boolean;
