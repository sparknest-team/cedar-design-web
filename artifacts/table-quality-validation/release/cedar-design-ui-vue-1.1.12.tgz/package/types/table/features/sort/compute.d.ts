import type { Sorter, TableColumnData, TableData } from '../../types';
/** Sort the supplied array, leaving cloning/row identity to its owning pipeline. */
export declare function sortRecords<Row>(data: Row[], sorter: Sorter | undefined, column: TableColumnData | undefined, raw: (record: Row) => TableData): Row[];
