import type { Filters, TableColumnData, TableData, TableDataWithRaw } from '../../types';
export declare function matchesRecord(record: TableData, filters: () => Filters, columnFor: (field: string) => TableColumnData | undefined): boolean;
/** Preserve the complete Table's tree filtering and wrapper mutation semantics. */
export declare function filterTableRows(data: TableDataWithRaw[], valid: (record: TableDataWithRaw) => boolean): TableDataWithRaw[];
