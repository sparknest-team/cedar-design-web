export declare function leafColumns<Column extends {
    children?: Column[];
}>(columns: readonly Column[]): Column[];
