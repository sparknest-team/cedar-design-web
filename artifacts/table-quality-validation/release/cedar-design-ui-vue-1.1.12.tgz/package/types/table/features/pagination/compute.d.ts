export declare function pageTableRows<Row>(data: Row[], enabled: unknown, page: number, pageSize: number): Row[];
