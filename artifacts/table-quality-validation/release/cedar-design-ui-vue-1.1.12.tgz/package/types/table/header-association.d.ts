/** A header cell in DOM order. Spans describe its occupied table grid. */
export interface HeaderGridCell {
    id: string;
    colSpan?: number;
    rowSpan?: number;
}
/**
 * Build the header chain for each physical DOM column. The input includes
 * operation headers, so a merged cell can cover both operation and data columns.
 */
export declare function buildHeaderAssociations(rows: readonly (readonly HeaderGridCell[])[]): {
    columnHeaders: string[][];
    headersForSpan(start: number, span?: number): string[];
};
