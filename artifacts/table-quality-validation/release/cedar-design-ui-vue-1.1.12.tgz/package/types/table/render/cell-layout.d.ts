import type { CSSProperties } from 'vue';
import type { TableColumnData, TableOperationColumn } from '../types';
export declare const getOperationFixedNumber: (column: TableOperationColumn, operations: TableOperationColumn[]) => number;
export declare const getFixedNumber: (column: TableColumnData, { dataColumns, operations, }: {
    dataColumns: TableColumnData[];
    operations: TableOperationColumn[];
}, tableLayout?: "fixed" | "auto", dir?: "ltr" | "rtl") => number;
export declare const getOperationFixedCls: (prefixCls: string, column: TableOperationColumn) => any[];
export declare const getFixedCls: (prefixCls: string, column: Pick<TableColumnData, "fixed" | "isLastLeftFixed" | "isFirstRightFixed">, hideLeftBoundary?: boolean) => any[];
export declare const getStyle: (column: TableColumnData, { dataColumns, operations, }: {
    dataColumns: TableColumnData[];
    operations: TableOperationColumn[];
}, tableLayout?: "fixed" | "auto", dir?: "ltr" | "rtl") => import("vue").CSSProperties;
export declare const getOperationStyle: (column: TableOperationColumn, operations: TableOperationColumn[], dir?: "ltr" | "rtl", dataColumns?: TableColumnData[], tableLayout?: "fixed" | "auto") => {
    left: string;
} | {
    left?: undefined;
};
