import type { Slots } from 'vue';
import type { TableColumnData, TableData } from '../types';
export declare function renderDataContent(props: {
    record: {
        raw: TableData;
    };
    column: TableColumnData;
    rowIndex?: number;
}, slots: import("vue").Slots, tableSlots?: import("vue").Slots): import("vue").VNodeChild;
