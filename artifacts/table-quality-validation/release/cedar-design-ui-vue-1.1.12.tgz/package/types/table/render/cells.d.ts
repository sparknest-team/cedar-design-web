import type { HTMLAttributes, VNode, VNodeChild } from 'vue';
/** Shared DOM only. Features supply content and interaction; no desktop imports. */
export declare function renderCellElement(tag: 'th' | 'td', custom: import("vue").VNode | undefined, column: {
    dataIndex?: string;
}, attributes: Record<string, unknown>, children: () => import("vue").VNodeChild): import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>;
export declare function renderHeaderContent(prefix: string, options: {
    class: import("vue").HTMLAttributes['class'];
    interaction?: Record<string, unknown>;
    title: () => import("vue").VNodeChild;
    sorter?: () => import("vue").VNodeChild;
    inlineFilter?: () => import("vue").VNodeChild;
    actions?: () => import("vue").VNodeChild;
}): import("vue/jsx-runtime").JSX.Element;
export declare function renderTextContent(prefix: string, content: import("vue").VNodeChild, ellipsis?: boolean): import("vue/jsx-runtime").JSX.Element;
export declare function renderBodyContent(prefix: string, options: {
    align?: string;
    fixedExpand?: boolean;
    hasExpand?: boolean;
    style?: Record<string, string>;
    indent?: number;
    expand?: () => import("vue").VNodeChild;
    onExpand?: (event: Event) => unknown;
    content: () => import("vue").VNodeChild;
}): import("vue/jsx-runtime").JSX.Element;
