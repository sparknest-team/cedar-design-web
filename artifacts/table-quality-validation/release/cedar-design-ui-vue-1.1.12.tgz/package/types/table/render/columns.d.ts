import type { TableColumnData } from '../types';
export declare const getGroupColumns: (columns: TableColumnData[], columnMap: Map<string, TableColumnData>, columnWidth: Record<string, number>, dir?: "ltr" | "rtl") => {
    dataColumns: TableColumnData[];
    groupColumns: TableColumnData[][];
};
