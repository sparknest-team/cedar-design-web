import type { AutoCompleteOption, AutoCompleteOptionInfo } from './props';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<string>>;
        default: undefined;
    };
    modelValue: import("vue").PropType<string | null>;
    defaultValue: {
        type: StringConstructor;
        default: string;
    };
    options: {
        type: import("vue").PropType<readonly (AutoCompleteOption | import("../index.ts").SelectOptionGroup)[] | import("../_hooks/use-option-request").OptionsLoader<AutoCompleteOption | import("../index.ts").SelectOptionGroup>>;
        default: undefined;
    };
    fieldNames: import("vue").PropType<import("./props").AutoCompleteFieldNames>;
    filterOption: {
        type: import("vue").PropType<import("./props").AutoCompleteFilterOption>;
        default: undefined;
    };
    caseSensitive: {
        type: BooleanConstructor;
        default: boolean;
    };
    searchFields: {
        type: import("vue").PropType<readonly import("../index.ts").OptionSearchField[]>;
        default: () => string[];
    };
    popupContainer: {
        type: import("vue").PropType<import("../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    shouldOpen: {
        type: import("vue").PropType<(inputValue: string) => boolean>;
        default: (inputValue: string) => boolean;
    };
    triggerProps: import("vue").PropType<import("../trigger").TriggerProps>;
    virtualListProps: import("vue").PropType<import("../_components/virtual-list-v2/interface.ts").VirtualListProps>;
    variant: {
        type: import("vue").PropType<import("../index.ts").InputVariant>;
        validator: (value: import("../index.ts").InputVariant) => boolean;
    };
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
        validator: (value: import("../index.ts").ComponentSize) => boolean;
    };
    hint: {
        type: BooleanConstructor;
        default: undefined;
    };
    line: {
        type: BooleanConstructor;
        default: boolean;
    };
    textColor: StringConstructor;
    focusColor: StringConstructor;
    blurColor: StringConstructor;
    enterkeyhint: import("vue").PropType<"search" | "done" | "previous" | "next" | "enter" | "go" | "send">;
    ariaLabel: StringConstructor;
    clearable: {
        type: BooleanConstructor;
        default: boolean;
    };
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    error: {
        type: BooleanConstructor;
        default: undefined;
    };
    placeholder: StringConstructor;
    maxLength: {
        type: import("vue").PropType<import("../index.ts").InputMaxLength>;
        default: number;
        validator: typeof import("../_utils/text-input-value").isValidTextInputMaxLength;
    };
    showWordLimit: {
        type: BooleanConstructor;
        default: boolean;
    };
    wordLength: import("vue").PropType<import("../index.ts").WordLength>;
    wordSlice: import("vue").PropType<import("../index.ts").WordSlice>;
    inputAttrs: import("vue").PropType<Record<string, unknown>>;
    editMode: {
        type: import("vue").PropType<import("../index.ts").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
    beforeCommit: import("vue").PropType<import("../index.ts").BeforeFieldCommit>;
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: BooleanConstructor;
    needConfirm: {
        type: BooleanConstructor;
        default: undefined;
    };
    searchDelay: {
        type: NumberConstructor;
        default: number;
    };
    loading: BooleanConstructor;
    loadingMode: {
        type: import("vue").PropType<import("../index.ts").FieldLoadingMode>;
        default: string;
        validator: (value: import("../index.ts").FieldLoadingMode) => boolean;
    };
}>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    keydown: (_event: KeyboardEvent) => boolean;
    'load-error': (error: unknown) => boolean;
    'update:modelValue': (value: string | null) => boolean;
    input: (value: string, ev: Event) => boolean;
    search: (value: string, ev: Event) => boolean;
    change: (value: string | null, ev: Event) => boolean;
    select: (value: string, option: AutoCompleteOptionInfo, ev: Event) => boolean;
    clear: (ev: Event) => boolean;
    focus: (ev: FocusEvent) => boolean;
    blur: (ev: FocusEvent) => boolean;
    'dropdown-scroll': (ev: Event) => boolean;
    'dropdown-reach-bottom': (ev: Event) => boolean;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<string>>;
        default: undefined;
    };
    modelValue: import("vue").PropType<string | null>;
    defaultValue: {
        type: StringConstructor;
        default: string;
    };
    options: {
        type: import("vue").PropType<readonly (AutoCompleteOption | import("../index.ts").SelectOptionGroup)[] | import("../_hooks/use-option-request").OptionsLoader<AutoCompleteOption | import("../index.ts").SelectOptionGroup>>;
        default: undefined;
    };
    fieldNames: import("vue").PropType<import("./props").AutoCompleteFieldNames>;
    filterOption: {
        type: import("vue").PropType<import("./props").AutoCompleteFilterOption>;
        default: undefined;
    };
    caseSensitive: {
        type: BooleanConstructor;
        default: boolean;
    };
    searchFields: {
        type: import("vue").PropType<readonly import("../index.ts").OptionSearchField[]>;
        default: () => string[];
    };
    popupContainer: {
        type: import("vue").PropType<import("../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    shouldOpen: {
        type: import("vue").PropType<(inputValue: string) => boolean>;
        default: (inputValue: string) => boolean;
    };
    triggerProps: import("vue").PropType<import("../trigger").TriggerProps>;
    virtualListProps: import("vue").PropType<import("../_components/virtual-list-v2/interface.ts").VirtualListProps>;
    variant: {
        type: import("vue").PropType<import("../index.ts").InputVariant>;
        validator: (value: import("../index.ts").InputVariant) => boolean;
    };
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
        validator: (value: import("../index.ts").ComponentSize) => boolean;
    };
    hint: {
        type: BooleanConstructor;
        default: undefined;
    };
    line: {
        type: BooleanConstructor;
        default: boolean;
    };
    textColor: StringConstructor;
    focusColor: StringConstructor;
    blurColor: StringConstructor;
    enterkeyhint: import("vue").PropType<"search" | "done" | "previous" | "next" | "enter" | "go" | "send">;
    ariaLabel: StringConstructor;
    clearable: {
        type: BooleanConstructor;
        default: boolean;
    };
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    error: {
        type: BooleanConstructor;
        default: undefined;
    };
    placeholder: StringConstructor;
    maxLength: {
        type: import("vue").PropType<import("../index.ts").InputMaxLength>;
        default: number;
        validator: typeof import("../_utils/text-input-value").isValidTextInputMaxLength;
    };
    showWordLimit: {
        type: BooleanConstructor;
        default: boolean;
    };
    wordLength: import("vue").PropType<import("../index.ts").WordLength>;
    wordSlice: import("vue").PropType<import("../index.ts").WordSlice>;
    inputAttrs: import("vue").PropType<Record<string, unknown>>;
    editMode: {
        type: import("vue").PropType<import("../index.ts").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
    beforeCommit: import("vue").PropType<import("../index.ts").BeforeFieldCommit>;
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    defaultOpen: BooleanConstructor;
    needConfirm: {
        type: BooleanConstructor;
        default: undefined;
    };
    searchDelay: {
        type: NumberConstructor;
        default: number;
    };
    loading: BooleanConstructor;
    loadingMode: {
        type: import("vue").PropType<import("../index.ts").FieldLoadingMode>;
        default: string;
        validator: (value: import("../index.ts").FieldLoadingMode) => boolean;
    };
}>> & Readonly<{
    onFocus?: ((ev: FocusEvent) => any) | undefined;
    onClear?: ((ev: Event) => any) | undefined;
    onInput?: ((value: string, ev: Event) => any) | undefined;
    onSearch?: ((value: string, ev: Event) => any) | undefined;
    onSelect?: ((value: string, option: AutoCompleteOptionInfo, ev: Event) => any) | undefined;
    onBlur?: ((ev: FocusEvent) => any) | undefined;
    onChange?: ((value: string | null, ev: Event) => any) | undefined;
    onKeydown?: ((_event: KeyboardEvent) => any) | undefined;
    "onLoad-error"?: ((error: unknown) => any) | undefined;
    "onUpdate:modelValue"?: ((value: string | null) => any) | undefined;
    "onDropdown-scroll"?: ((ev: Event) => any) | undefined;
    "onDropdown-reach-bottom"?: ((ev: Event) => any) | undefined;
}>, {
    error: boolean;
    readonly: boolean;
    line: boolean;
    disabled: boolean;
    loading: boolean;
    editMode: import("../index.ts").FieldEditMode;
    readPretty: boolean;
    loadingMode: "default" | "line";
    hint: boolean;
    clearable: boolean;
    emptyValue: import("../_utils/empty-value.ts").EmptyValue<string>;
    emptyValues: readonly unknown[];
    emptyText: string;
    popupContainer: import("../index.ts").PopupContainer;
    open: boolean;
    defaultOpen: boolean;
    defaultValue: string;
    maxLength: import("../_utils/text-input-value").TextInputMaxLength;
    showWordLimit: boolean;
    needConfirm: boolean;
    options: readonly (import("../index.ts").SelectOptionGroup | AutoCompleteOption)[] | import("../_hooks/use-option-request").OptionsLoader<import("../index.ts").SelectOptionGroup | AutoCompleteOption>;
    searchDelay: number;
    filterOption: import("./props").AutoCompleteFilterOption;
    caseSensitive: boolean;
    searchFields: readonly import("../index.ts").OptionSearchField[];
    shouldOpen: (inputValue: string) => boolean;
}>;
export default _default;
