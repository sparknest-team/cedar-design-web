import type { AutoCompleteOptionInfo } from './props';
export declare const autoCompleteEmits: {
    /** @zh 字段按键事件 @en Field keyboard event */
    keydown: (_event: KeyboardEvent) => boolean;
    'load-error': (error: unknown) => boolean;
    'update:modelValue': (value: string | null) => boolean;
    input: (value: string, ev: Event) => boolean;
    search: (value: string, ev: Event) => boolean;
    change: (value: string | null, ev: Event) => boolean;
    select: (value: string, option: AutoCompleteOptionInfo, ev: Event) => boolean;
    clear: (ev: Event) => boolean;
    focus: (ev: FocusEvent) => boolean;
    blur: (ev: FocusEvent) => boolean;
    'dropdown-scroll': (ev: Event) => boolean;
    'dropdown-reach-bottom': (ev: Event) => boolean;
};
