import _Affix from './Affix.vue';
import { affixProps } from './props';
declare const Affix: import('../_utils/global-config').ComponentWithInstall<typeof _Affix>;
export type AffixInstance = InstanceType<typeof _Affix>;
export type { AffixProps, AffixTarget } from './props';
export { Affix, affixProps };
export declare const _AffixComponent: typeof Affix;
export default Affix;
