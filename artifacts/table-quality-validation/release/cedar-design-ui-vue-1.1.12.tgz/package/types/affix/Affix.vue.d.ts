import { isAffixOffset } from './offset';
declare function resize(): Promise<void>;
declare var __VLS_1: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    offsetTop: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
        validator: typeof isAffixOffset;
    };
    offsetBottom: {
        type: (StringConstructor | NumberConstructor)[];
        validator: typeof isAffixOffset;
    };
    target: import("vue").PropType<import("./props").AffixTarget>;
    targetContainer: import("vue").PropType<import("./props").AffixTarget>;
    zIndex: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    disabled: BooleanConstructor;
    cssMode: BooleanConstructor;
}>, {
    updatePosition: typeof resize;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    change: (fixed: boolean, offset: number) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    offsetTop: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
        validator: typeof isAffixOffset;
    };
    offsetBottom: {
        type: (StringConstructor | NumberConstructor)[];
        validator: typeof isAffixOffset;
    };
    target: import("vue").PropType<import("./props").AffixTarget>;
    targetContainer: import("vue").PropType<import("./props").AffixTarget>;
    zIndex: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    disabled: BooleanConstructor;
    cssMode: BooleanConstructor;
}>> & Readonly<{
    onChange?: ((fixed: boolean, offset: number) => any) | undefined;
}>, {
    offsetTop: string | number;
    zIndex: string | number;
    disabled: boolean;
    cssMode: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
