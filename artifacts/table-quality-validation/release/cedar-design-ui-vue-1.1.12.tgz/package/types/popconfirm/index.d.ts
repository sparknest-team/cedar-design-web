import _Popconfirm from "./Popconfirm.vue";
import { popconfirmProps } from "./props";
declare const Popconfirm: import('../_utils/global-config').ComponentWithInstall<typeof _Popconfirm>;
export type PopconfirmInstance = InstanceType<typeof _Popconfirm>;
export type { PopconfirmBeforeConfirm, PopconfirmProps, PopconfirmBeforeCancel, } from "./props";
export { Popconfirm, popconfirmProps };
export declare const _PopconfirmComponent: typeof Popconfirm;
export default Popconfirm;
