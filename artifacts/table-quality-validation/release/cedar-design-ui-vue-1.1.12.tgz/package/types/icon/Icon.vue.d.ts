declare var __VLS_1: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    name: StringConstructor;
    size: (StringConstructor | NumberConstructor)[];
    color: StringConstructor;
    rotate: NumberConstructor;
    spin: BooleanConstructor;
    transition: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    animationClass: StringConstructor;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    click: (event: MouseEvent) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    name: StringConstructor;
    size: (StringConstructor | NumberConstructor)[];
    color: StringConstructor;
    rotate: NumberConstructor;
    spin: BooleanConstructor;
    transition: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    animationClass: StringConstructor;
}>> & Readonly<{
    onClick?: ((event: MouseEvent) => any) | undefined;
}>, {
    spin: boolean;
    transition: string | number;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
