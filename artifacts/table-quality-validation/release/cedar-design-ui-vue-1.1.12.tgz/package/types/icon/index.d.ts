import _Icon from "./Icon.vue";
import { iconProps } from "./props";
declare const Icon: import('../_utils/global-config').ComponentWithInstall<typeof _Icon>;
export type IconInstance = InstanceType<typeof _Icon>;
export type { IconProps } from "./props";
export declare const _IconComponent: typeof Icon;
export { Icon };
export { iconProps };
export default Icon;
