export type FormFieldName = string | string[];
export interface FormFieldError {
    field: string;
    message: string;
}
export type FormValidateErrors<Error extends FormFieldError = FormFieldError> = Record<string, Error> | undefined;
export interface FormFieldController<Error extends FormFieldError = FormFieldError, Data = unknown> {
    readonly field: string;
    validate: () => Promise<Error | undefined>;
    clearValidate: () => void;
    resetField: () => void;
    setField?: (data: Data) => void;
    getElement?: () => HTMLElement | undefined;
}
export interface FormControllerOptions<Error extends FormFieldError, Data> {
    onInvalid?: (errors: Record<string, Error>, fields: FormFieldController<Error, Data>[]) => void;
}
export declare function createFormController<Error extends FormFieldError = FormFieldError, Data = unknown>(options?: FormControllerOptions<Error, Data>): {
    fields: FormFieldController<Error, Data>[];
    registerField: (field: FormFieldController<Error, Data>) => () => void;
    matchFields: (field?: FormFieldName) => FormFieldController<Error, Data>[];
    validate: (field?: FormFieldName, callback?: (errors: FormValidateErrors<Error>) => void) => Promise<FormValidateErrors<Error>>;
    resetFields: (field?: FormFieldName) => void;
    clearValidate: (field?: FormFieldName) => void;
    setFields: (data: Record<string, Data>) => void;
    invalidate: () => void;
};
