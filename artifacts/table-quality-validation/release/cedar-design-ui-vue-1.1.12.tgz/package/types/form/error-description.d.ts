import { type ComputedRef } from 'vue';
export declare function provideFormErrorDescription(visible: () => boolean, noStyle: () => boolean, helpVisible?: () => boolean, feedback?: (kind: 'error' | 'help') => {
    element?: HTMLElement;
    text: string;
}): {
    current: import("vue").ComputedRef<string | undefined>;
    helpId: string;
    labelId: string;
};
export declare function provideFormErrorDescriptionBoundary(): void;
export declare function provideEditorErrorDescription(panel: () => HTMLElement | undefined, container: () => unknown): {
    localId: undefined;
    text: import("vue").ComputedRef<string>;
} | {
    localId: import("vue").Ref<string | undefined>;
    text: import("vue").Ref<string>;
};
export declare function useFormErrorDescription(): {
    errorId: import("vue").ComputedRef<string | undefined> | undefined;
    describe(value: unknown): string | undefined;
};
