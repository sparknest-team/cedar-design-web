import { PropType } from 'vue';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    error: {
        type: import("vue").PropType<string[]>;
        default: () => never[];
    };
    help: StringConstructor;
}>, {
    Transition: import("vue").FunctionalComponent<import("vue").TransitionProps, {}>;
    keyedErrors: import("vue").ComputedRef<{
        key: string;
        message: string;
    }[]>;
    prefixCls: string;
    errorId: import("vue").ComputedRef<string | undefined> | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    error: {
        type: import("vue").PropType<string[]>;
        default: () => never[];
    };
    help: StringConstructor;
}>> & Readonly<{}>, {
    error: string[];
}>;
export default _default;
