import type { PropType } from 'vue';
import type { FormLabelRegistry } from './use-form-label-width';
declare var __VLS_11: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_11) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    measureWidth: BooleanConstructor;
    registry: import("vue").PropType<FormLabelRegistry>;
    labelClass: {
        type: StringConstructor;
        default: string;
    };
    required: BooleanConstructor;
    showColon: {
        type: BooleanConstructor;
        default: boolean;
    };
    component: {
        type: StringConstructor;
        default: string;
    };
    asteriskPosition: {
        type: import("vue").PropType<import("./item-decoration").FormItemAsteriskPosition>;
        default: string;
    };
    tooltip: StringConstructor;
    attrs: import("vue").PropType<import("vue").HTMLAttributes & Record<string, unknown>>;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    measureWidth: BooleanConstructor;
    registry: import("vue").PropType<FormLabelRegistry>;
    labelClass: {
        type: StringConstructor;
        default: string;
    };
    required: BooleanConstructor;
    showColon: {
        type: BooleanConstructor;
        default: boolean;
    };
    component: {
        type: StringConstructor;
        default: string;
    };
    asteriskPosition: {
        type: import("vue").PropType<import("./item-decoration").FormItemAsteriskPosition>;
        default: string;
    };
    tooltip: StringConstructor;
    attrs: import("vue").PropType<import("vue").HTMLAttributes & Record<string, unknown>>;
}>> & Readonly<{}>, {
    required: boolean;
    component: string;
    labelClass: string;
    measureWidth: boolean;
    showColon: boolean;
    asteriskPosition: import("./item-decoration").FormItemAsteriskPosition;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
