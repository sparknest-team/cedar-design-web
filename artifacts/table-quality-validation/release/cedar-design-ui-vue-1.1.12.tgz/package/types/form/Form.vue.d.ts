import type { FormSlots } from "./types";
import type { FormScrollOptions } from "./scroll-options";
import { PropType } from "vue";
import { ComponentSize } from "../_utils/constant";
import { type FormValidateErrors } from "./form-controller";
import { FieldData, FieldRule, ValidatedError, FormSubmitError } from "./types";
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    model: {
        type: ObjectConstructor;
        default: () => {};
    };
    layout: {
        type: import("vue").PropType<import("./layout-props.ts").FormLayout>;
        default: string;
    };
    size: {
        type: import("vue").PropType<ComponentSize>;
    };
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    rules: {
        type: import("vue").PropType<Record<string, FieldRule | FieldRule[]>>;
    };
    id: {
        type: StringConstructor;
    };
    scrollToError: {
        type: import("vue").PropType<"start" | "end">;
    };
    scrollToErrorOffsetY: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    contentAlign: {
        type: import("vue").PropType<import("./layout-props.ts").FormContentAlign>;
        default: string;
    };
    labelAlign: {
        type: import("vue").PropType<import("./layout-props.ts").FormLabelAlign>;
        default: string;
    };
    labelColProps: {
        type: import("vue").PropType<import("./layout-props.ts").FormColProps>;
        default: () => {
            span: number;
            offset: number;
        };
    };
    wrapperColProps: {
        type: import("vue").PropType<import("./layout-props.ts").FormColProps>;
        default: () => {
            span: number;
            offset: number;
        };
    };
    autoLabelWidth: {
        type: BooleanConstructor;
        default: boolean;
    };
    labelColStyle: import("vue").PropType<import("vue").CSSProperties>;
    wrapperColStyle: import("vue").PropType<import("vue").CSSProperties>;
    labelColFlex: import("vue").PropType<import("./layout-props.ts").FormLabelFlex>;
    editMode: {
        type: import("vue").PropType<import("./index.ts").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
}>, {
    cls: import("vue").ComputedRef<(string | {
        [x: string]: boolean;
    })[]>;
    formRef: import("vue").Ref<HTMLFormElement | undefined>;
    handleSubmit: (e: Event) => Promise<void> | undefined;
    handleReset: (e: Event) => void;
    innerValidate: (callback?: (errors: FormValidateErrors<ValidatedError>) => void) => Promise<FormValidateErrors<ValidatedError>>;
    innerValidateField: (field: string | string[], callback?: (errors: FormValidateErrors<ValidatedError>) => void) => Promise<FormValidateErrors<ValidatedError>>;
    innerResetFields: (field?: string | string[]) => void;
    innerClearValidate: (field?: string | string[]) => void;
    innerSetFields: (data: Record<string, FieldData>) => void;
    innerScrollToField: (field: string, options?: FormScrollOptions, offset?: number, isEligible?: () => boolean) => void;
}, {}, {}, {
    /**
     * @zh 校验全部表单数据
     * @en Verify all form data
     * @public
     * @param {(errors: undefined | Record<string, ValidatedError>) => void} callback
     * @returns {Promise<undefined | Record<string, ValidatedError>>}
     */
    validate(callback?: (errors: undefined | Record<string, ValidatedError>) => void): Promise<undefined | Record<string, ValidatedError>>;
    /**
     * @zh 校验部分表单数据
     * @en Validate part of the form data
     * @public
     * @param {string | string[]} field
     * @param {(errors: undefined | Record<string, ValidatedError>) => void} callback
     * @returns {Promise<undefined | Record<string, ValidatedError>>}
     */
    validateField(field: string | string[], callback?: (errors: undefined | Record<string, ValidatedError>) => void): Promise<undefined | Record<string, ValidatedError>>;
    /**
     * @zh 重置表单数据
     * @en Reset form data
     * @public
     * @param {string | string[]} field
     */
    resetFields(field?: string | string[]): void;
    /**
     * @zh 清除校验状态
     * @en Clear verification status
     * @public
     * @param {string | string[]} field
     */
    clearValidate(field?: string | string[]): void;
    /**
     * @zh 设置表单项的值和状态
     * @en Set the value and status of the form item
     * @param {Record<string, FieldData>} data
     * @public
     */
    setFields(data: Record<string, FieldData>): void;
    /**
     * @zh 滚动到指定表单项
     * @en Scroll to the specified form item
     * @param {string} field
     * @public
     */
    scrollToField(field: string): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    /**
     * @zh 表单提交时触发
     * @en Triggered when the form is submitted
     * @param {{values: Record<string, any>; errors: Record<string, ValidatedError> | undefined}} data
     * @param {Event} ev
     */
    submit: (data: {
        values: Record<string, any>;
        errors: Record<string, ValidatedError> | undefined;
    }, ev: Event) => true;
    /**
     * @zh 验证成功时触发
     * @en Triggered when verification is successful
     * @param {Record<string, any>} values
     * @param {Event} ev
     */
    "submit-success": (values: Record<string, any>, ev: Event) => true;
    /**
     * @zh 验证失败时触发
     * @en Triggered when verification failed
     * @param {{values: Record<string, any>; errors: Record<string, ValidatedError>}} data
     * @param {Event} ev
     */
    "submit-failed": (data: {
        values: Record<string, any>;
        errors: Record<string, FormSubmitError>;
    }, ev: Event) => true;
    reset: (ev: Event) => true;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    model: {
        type: ObjectConstructor;
        default: () => {};
    };
    layout: {
        type: import("vue").PropType<import("./layout-props.ts").FormLayout>;
        default: string;
    };
    size: {
        type: import("vue").PropType<ComponentSize>;
    };
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    rules: {
        type: import("vue").PropType<Record<string, FieldRule | FieldRule[]>>;
    };
    id: {
        type: StringConstructor;
    };
    scrollToError: {
        type: import("vue").PropType<"start" | "end">;
    };
    scrollToErrorOffsetY: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
    };
    contentAlign: {
        type: import("vue").PropType<import("./layout-props.ts").FormContentAlign>;
        default: string;
    };
    labelAlign: {
        type: import("vue").PropType<import("./layout-props.ts").FormLabelAlign>;
        default: string;
    };
    labelColProps: {
        type: import("vue").PropType<import("./layout-props.ts").FormColProps>;
        default: () => {
            span: number;
            offset: number;
        };
    };
    wrapperColProps: {
        type: import("vue").PropType<import("./layout-props.ts").FormColProps>;
        default: () => {
            span: number;
            offset: number;
        };
    };
    autoLabelWidth: {
        type: BooleanConstructor;
        default: boolean;
    };
    labelColStyle: import("vue").PropType<import("vue").CSSProperties>;
    wrapperColStyle: import("vue").PropType<import("vue").CSSProperties>;
    labelColFlex: import("vue").PropType<import("./layout-props.ts").FormLabelFlex>;
    editMode: {
        type: import("vue").PropType<import("./index.ts").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
}>> & Readonly<{
    onReset?: ((ev: Event) => any) | undefined;
    onSubmit?: ((data: {
        values: Record<string, any>;
        errors: Record<string, ValidatedError> | undefined;
    }, ev: Event) => any) | undefined;
    "onSubmit-success"?: ((values: Record<string, any>, ev: Event) => any) | undefined;
    "onSubmit-failed"?: ((data: {
        values: Record<string, any>;
        errors: Record<string, FormSubmitError>;
    }, ev: Event) => any) | undefined;
}>, {
    readonly: boolean;
    disabled: boolean;
    editMode: import("./index.ts").FieldEditMode;
    readPretty: boolean;
    emptyValues: readonly unknown[];
    emptyText: string;
    layout: import("./layout-props.ts").FormLayout;
    model: Record<string, any>;
    scrollToErrorOffsetY: string | number;
    contentAlign: import("./layout-props.ts").FormContentAlign;
    labelAlign: import("./layout-props.ts").FormLabelAlign;
    labelColProps: Partial<{
        span: number;
    }> & Omit<{
        readonly span: number;
        readonly xs?: import("../index.ts").ColBreakpoint | undefined;
        readonly sm?: import("../index.ts").ColBreakpoint | undefined;
        readonly md?: import("../index.ts").ColBreakpoint | undefined;
        readonly lg?: import("../index.ts").ColBreakpoint | undefined;
        readonly xl?: import("../index.ts").ColBreakpoint | undefined;
        readonly order?: number | undefined;
        readonly flex?: import("../index.ts").FlexType | undefined;
        readonly offset?: number | undefined;
        readonly xxl?: import("../index.ts").ColBreakpoint | undefined;
        readonly onClick?: ((value: MouseEvent) => any) | undefined;
    } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "span">;
    wrapperColProps: Partial<{
        span: number;
    }> & Omit<{
        readonly span: number;
        readonly xs?: import("../index.ts").ColBreakpoint | undefined;
        readonly sm?: import("../index.ts").ColBreakpoint | undefined;
        readonly md?: import("../index.ts").ColBreakpoint | undefined;
        readonly lg?: import("../index.ts").ColBreakpoint | undefined;
        readonly xl?: import("../index.ts").ColBreakpoint | undefined;
        readonly order?: number | undefined;
        readonly flex?: import("../index.ts").FlexType | undefined;
        readonly offset?: number | undefined;
        readonly xxl?: import("../index.ts").ColBreakpoint | undefined;
        readonly onClick?: ((value: MouseEvent) => any) | undefined;
    } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "span">;
    autoLabelWidth: boolean;
}> & {
    new (): {
        $slots: FormSlots;
    };
};
export default _default;
