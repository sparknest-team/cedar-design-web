/** Native labels do not activate ARIA sliders, which are not labelable elements. */
export declare function focusExplicitSlider(event: MouseEvent): void;
