/** Stable explicit form prefix for field container IDs, including nested paths. */
export declare const getFormElementId: (prefix: string | undefined, field: string) => string;
