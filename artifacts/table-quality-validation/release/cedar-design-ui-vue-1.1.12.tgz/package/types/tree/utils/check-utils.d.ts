import { Key2TreeNode, Node, TreeNodeValue } from '../types';
export declare function isNodeCheckable(node: Node): boolean;
export declare function getCheckedStateByCheck(options: {
    node: Node;
    checked: boolean;
    checkedValues: TreeNodeValue[];
    indeterminateKeys: TreeNodeValue[];
    checkStrictly?: boolean;
}): TreeNodeValue[][];
export declare function getCheckedStateByInitKeys(options: {
    initCheckedValues: TreeNodeValue[];
    key2TreeNode: Key2TreeNode;
    checkStrictly?: boolean;
    onlyCheckLeaf?: boolean;
}): TreeNodeValue[][];
