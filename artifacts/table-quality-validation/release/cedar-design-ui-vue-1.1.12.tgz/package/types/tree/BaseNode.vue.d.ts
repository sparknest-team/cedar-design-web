import { PropType, VNode } from 'vue';
import type { RenderFunc } from '../_components/render-function';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    value: (StringConstructor | NumberConstructor)[];
    /** 标题 */
    label: {
        type: StringConstructor;
    };
    /** 是否允许选中  */
    selectable: {
        type: BooleanConstructor;
    };
    /** 是否禁用节点 */
    disabled: {
        type: BooleanConstructor;
    };
    /** 是否禁用checkbox   */
    disableCheckbox: {
        type: BooleanConstructor;
    };
    /** 是否显示多选框   */
    checkable: {
        type: BooleanConstructor;
    };
    /** 是否可以拖拽   */
    draggable: {
        type: BooleanConstructor;
    };
    /** 是否是叶子节点。动态加载时有效 */
    isLeaf: {
        type: BooleanConstructor;
    };
    icon: {
        type: import("vue").PropType<() => import("vue").VNode>;
    };
    switcherIcon: {
        type: import("vue").PropType<() => import("vue").VNode>;
    };
    loadingIcon: {
        type: import("vue").PropType<() => import("vue").VNode>;
    };
    dragIcon: {
        type: import("vue").PropType<() => import("vue").VNode>;
    };
    isTail: {
        type: BooleanConstructor;
    };
    blockNode: {
        type: BooleanConstructor;
    };
    showLine: {
        type: BooleanConstructor;
    };
    level: {
        type: NumberConstructor;
        default: number;
    };
    lineless: {
        type: import("vue").PropType<boolean[]>;
        default: () => never[];
    };
}>, {
    externallyManaged: boolean | undefined;
    nodekey: import("vue").Ref<import("./types").TreeNodeValue>;
    focused: import("vue").ComputedRef<boolean>;
    nodeId: import("vue").ComputedRef<string | undefined>;
    refTitle: import("vue").Ref<HTMLElement | undefined>;
    prefixCls: string;
    classNames: import("vue").ComputedRef<(string | {
        [x: string]: boolean | undefined;
    })[]>;
    titleClassNames: import("vue").ComputedRef<(string | {
        [x: string]: boolean;
    })[]>;
    indeterminate: import("vue").ComputedRef<boolean | undefined>;
    checked: import("vue").ComputedRef<boolean | undefined>;
    expanded: import("vue").ComputedRef<boolean | undefined>;
    selected: import("vue").ComputedRef<boolean | undefined>;
    treeTitle: import("vue").ComputedRef<RenderFunc | undefined>;
    treeNodeData: import("vue").ComputedRef<import("./types").TreeNodeData>;
    loading: import("vue").ComputedRef<boolean | undefined>;
    treeDragIcon: import("vue").ComputedRef<import("vue").Slot | undefined>;
    treeNodeIcon: import("vue").ComputedRef<import("vue").Slot | undefined>;
    extra: import("vue").ComputedRef<RenderFunc | undefined>;
    nodeStatus: {
        loading: boolean | undefined;
        checked: boolean | undefined;
        selected: boolean | undefined;
        indeterminate: boolean | undefined;
        expanded: boolean | undefined;
        isLeaf: boolean;
    };
    onCheckboxChange(checked: boolean | (string | number | boolean)[] | null, e?: Event): void;
    onCheckboxPointerClick(e: Event): void;
    onTitleClick(e: Event): void;
    onSwitcherClick: (e: Event) => void;
    onDragStart(e: DragEvent): void;
    onDragEnd(e: DragEvent): void;
    onDragOver(e: DragEvent): void;
    onDragLeave(e: DragEvent): void;
    onDrop(e: DragEvent): void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    value: (StringConstructor | NumberConstructor)[];
    /** 标题 */
    label: {
        type: StringConstructor;
    };
    /** 是否允许选中  */
    selectable: {
        type: BooleanConstructor;
    };
    /** 是否禁用节点 */
    disabled: {
        type: BooleanConstructor;
    };
    /** 是否禁用checkbox   */
    disableCheckbox: {
        type: BooleanConstructor;
    };
    /** 是否显示多选框   */
    checkable: {
        type: BooleanConstructor;
    };
    /** 是否可以拖拽   */
    draggable: {
        type: BooleanConstructor;
    };
    /** 是否是叶子节点。动态加载时有效 */
    isLeaf: {
        type: BooleanConstructor;
    };
    icon: {
        type: import("vue").PropType<() => import("vue").VNode>;
    };
    switcherIcon: {
        type: import("vue").PropType<() => import("vue").VNode>;
    };
    loadingIcon: {
        type: import("vue").PropType<() => import("vue").VNode>;
    };
    dragIcon: {
        type: import("vue").PropType<() => import("vue").VNode>;
    };
    isTail: {
        type: BooleanConstructor;
    };
    blockNode: {
        type: BooleanConstructor;
    };
    showLine: {
        type: BooleanConstructor;
    };
    level: {
        type: NumberConstructor;
        default: number;
    };
    lineless: {
        type: import("vue").PropType<boolean[]>;
        default: () => never[];
    };
}>> & Readonly<{}>, {
    disabled: boolean;
    showLine: boolean;
    draggable: boolean;
    checkable: boolean;
    level: number;
    isLeaf: boolean;
    selectable: boolean;
    disableCheckbox: boolean;
    isTail: boolean;
    blockNode: boolean;
    lineless: boolean[];
}>;
export default _default;
