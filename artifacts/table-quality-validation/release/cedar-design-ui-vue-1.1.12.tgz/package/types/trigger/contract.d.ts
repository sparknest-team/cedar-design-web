export declare const triggerEvents: readonly ["hover", "click", "focus", "contextMenu", "manual"];
export type TriggerEvent = (typeof triggerEvents)[number];
export declare const triggerPlacements: readonly ["top", "top-start", "top-end", "bottom", "bottom-start", "bottom-end", "left", "left-start", "left-end", "right", "right-start", "right-end"];
export type TriggerPlacement = (typeof triggerPlacements)[number];
