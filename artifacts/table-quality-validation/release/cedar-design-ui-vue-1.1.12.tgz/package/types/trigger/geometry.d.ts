import type { ReadingDirection } from '../_utils/direction';
import type { TriggerPlacement } from './contract';
export interface TriggerSize {
    width: number;
    height: number;
}
export interface PositioningSpace {
    x: number;
    y: number;
    scaleX: number;
    scaleY: number;
}
/** CSS coordinates belong to the actual containing block, not the Teleport target. */
export declare function getPositioningSpace(popup: HTMLElement, strategy?: 'absolute' | 'fixed'): PositioningSpace;
export declare function getRelativeRect(rect: Pick<DOMRect, 'top' | 'left' | 'width' | 'height'>, space: PositioningSpace): {
    scrollTop: number;
    scrollLeft: number;
    width: number;
    height: number;
};
/** Convert same-origin frame viewport coordinates into the popup document. */
export declare function translateRectBetweenDocuments(rect: Pick<DOMRect, 'top' | 'left' | 'width' | 'height'>, source: Document, target: Document): Pick<DOMRect, "top" | "left" | "width" | "height"> | undefined;
/** Screen-axis offsets remain screen-axis offsets even after a placement flips. */
export declare function getTriggerPosition(placement: TriggerPlacement, x: number, y: number, reference: TriggerSize, cover?: boolean): {
    placement: "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "left" | "left-start" | "left-end" | "right" | "right-start" | "right-end";
    skidding: number;
    distance: number;
};
export declare function getPlacementOffset(placement: TriggerPlacement, reference: {
    scrollLeft: number;
    scrollTop: number;
    width: number;
    height: number;
}, popup: TriggerSize, distance?: number, translate?: readonly number[], direction?: ReadingDirection): {
    left: number;
    top: number;
};
export declare function getTransformOrigin(position: TriggerPlacement, direction?: ReadingDirection): string;
