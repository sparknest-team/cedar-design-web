import type { CSSProperties } from 'vue';
import type { TriggerPlacement } from './contract';
interface ArrowRect {
    scrollLeft: number;
    scrollTop: number;
    width: number;
    height: number;
}
export declare function getArrowStyle(placement: TriggerPlacement, reference: ArrowRect, popup: ArrowRect, { customStyle, padding }?: {
    customStyle?: import("vue").CSSProperties;
    padding?: number;
}): import("vue").CSSProperties;
export {};
