import _Avatar from './Avatar.vue';
import _AvatarGroup from './AvatarGroup.vue';
import { avatarGroupProps, avatarProps } from './props';
declare const Avatar: import('../_utils/global-config').CedarComponentWithInstall<typeof _Avatar & {
    Group: typeof _AvatarGroup;
}>;
export type AvatarInstance = InstanceType<typeof _Avatar>;
export type AvatarGroupInstance = InstanceType<typeof _AvatarGroup>;
export { avatarGroupProps, avatarProps };
export type { AvatarGroupProps, AvatarObjectFit, AvatarProps, AvatarShape, AvatarTriggerType } from './props';
export { Avatar };
export { _AvatarGroup as AvatarGroup };
export declare const _AvatarComponent: typeof Avatar;
export declare const _AvatarGroupComponent: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    shape: {
        type: import("vue").PropType<import("./props").AvatarShape>;
        default: string;
        validator: (value: unknown) => value is import("./props").AvatarShape;
    };
    size: {
        type: import("vue").PropType<number | string>;
        validator: (value: number | string) => boolean;
    };
    autoFixFontSize: {
        type: BooleanConstructor;
        default: boolean;
    };
    maxCount: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    zIndexAscend: {
        type: BooleanConstructor;
        default: boolean;
    };
    maxStyle: import("vue").PropType<import("vue").CSSProperties>;
    maxPopoverProps: import("vue").PropType<import("../index.ts").PopoverProps>;
    offset: {
        type: import("vue").PropType<number | string>;
        validator: (value: number | string) => boolean;
    };
    vertical: BooleanConstructor;
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    shape: {
        type: import("vue").PropType<import("./props").AvatarShape>;
        default: string;
        validator: (value: unknown) => value is import("./props").AvatarShape;
    };
    size: {
        type: import("vue").PropType<number | string>;
        validator: (value: number | string) => boolean;
    };
    autoFixFontSize: {
        type: BooleanConstructor;
        default: boolean;
    };
    maxCount: {
        type: NumberConstructor;
        default: number;
        validator: (value: number) => boolean;
    };
    zIndexAscend: {
        type: BooleanConstructor;
        default: boolean;
    };
    maxStyle: import("vue").PropType<import("vue").CSSProperties>;
    maxPopoverProps: import("vue").PropType<import("../index.ts").PopoverProps>;
    offset: {
        type: import("vue").PropType<number | string>;
        validator: (value: number | string) => boolean;
    };
    vertical: BooleanConstructor;
}>> & Readonly<{}>, {
    vertical: boolean;
    shape: "square" | "circle";
    autoFixFontSize: boolean;
    maxCount: number;
    zIndexAscend: boolean;
}>;
export default Avatar;
