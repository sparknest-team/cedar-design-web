import { type CSSProperties } from 'vue';
declare var __VLS_1: {}, __VLS_7: {}, __VLS_13: {}, __VLS_15: {};
type __VLS_Slots = {} & {
    error?: (props: typeof __VLS_1) => any;
} & {
    default?: (props: typeof __VLS_7) => any;
} & {
    default?: (props: typeof __VLS_13) => any;
} & {
    'trigger-icon'?: (props: typeof __VLS_15) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    shape: {
        type: import("vue").PropType<import("./props").AvatarShape>;
        default: string;
        validator: (value: unknown) => value is import("./props").AvatarShape;
    };
    imageUrl: StringConstructor;
    alt: {
        type: StringConstructor;
        default: string;
    };
    size: {
        type: import("vue").PropType<number | string>;
        validator: (value: number | string) => boolean;
    };
    autoFixFontSize: {
        type: BooleanConstructor;
        default: boolean;
    };
    triggerType: {
        type: import("vue").PropType<import("./props").AvatarTriggerType>;
        default: string;
        validator: (value: unknown) => value is import("./props").AvatarTriggerType;
    };
    triggerAriaLabel: StringConstructor;
    triggerIconStyle: import("vue").PropType<import("vue").CSSProperties>;
    objectFit: {
        type: import("vue").PropType<import("./props").AvatarObjectFit>;
        default: string;
        validator: (value: unknown) => value is import("./props").AvatarObjectFit;
    };
    color: StringConstructor;
    bordered: BooleanConstructor;
    borderColor: StringConstructor;
    loading: StringConstructor;
    error: StringConstructor;
    lazy: BooleanConstructor;
    hoverable: BooleanConstructor;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    click: (event: MouseEvent) => any;
    error: () => any;
    load: () => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    shape: {
        type: import("vue").PropType<import("./props").AvatarShape>;
        default: string;
        validator: (value: unknown) => value is import("./props").AvatarShape;
    };
    imageUrl: StringConstructor;
    alt: {
        type: StringConstructor;
        default: string;
    };
    size: {
        type: import("vue").PropType<number | string>;
        validator: (value: number | string) => boolean;
    };
    autoFixFontSize: {
        type: BooleanConstructor;
        default: boolean;
    };
    triggerType: {
        type: import("vue").PropType<import("./props").AvatarTriggerType>;
        default: string;
        validator: (value: unknown) => value is import("./props").AvatarTriggerType;
    };
    triggerAriaLabel: StringConstructor;
    triggerIconStyle: import("vue").PropType<import("vue").CSSProperties>;
    objectFit: {
        type: import("vue").PropType<import("./props").AvatarObjectFit>;
        default: string;
        validator: (value: unknown) => value is import("./props").AvatarObjectFit;
    };
    color: StringConstructor;
    bordered: BooleanConstructor;
    borderColor: StringConstructor;
    loading: StringConstructor;
    error: StringConstructor;
    lazy: BooleanConstructor;
    hoverable: BooleanConstructor;
}>> & Readonly<{
    onClick?: ((event: MouseEvent) => any) | undefined;
    onError?: (() => any) | undefined;
    onLoad?: (() => any) | undefined;
}>, {
    lazy: boolean;
    objectFit: "fill" | "none" | "contain" | "cover" | "scale-down";
    alt: string;
    shape: "square" | "circle";
    autoFixFontSize: boolean;
    triggerType: "button" | "overlay";
    bordered: boolean;
    hoverable: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
