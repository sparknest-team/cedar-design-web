import type { ComputedRef, InjectionKey } from 'vue';
import type { AvatarShape } from './props';
export interface AvatarGroupContext {
    shape: import("vue").ComputedRef<AvatarShape>;
    size: import("vue").ComputedRef<number | string | undefined>;
    autoFixFontSize: import("vue").ComputedRef<boolean>;
}
export declare const avatarGroupInjectionKey: import("vue").InjectionKey<AvatarGroupContext>;
