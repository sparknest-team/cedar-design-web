import type { TreeSelectValue } from './types';
import type { TreeNodeData } from '../tree/types';
export declare const treeSelectEmits: {
    /** @zh 字段按键事件 @en Keyboard event from the field */
    keydown: (_event: KeyboardEvent) => boolean;
    change: (_value: TreeSelectValue | undefined) => boolean;
    'update:modelValue': (_value: TreeSelectValue | undefined) => boolean;
    'update:inputValue': (_inputValue: string) => boolean;
    'input-value-change': (_inputValue: string) => boolean;
    'open-change': (_visible: boolean) => boolean;
    'update:open': (_visible: boolean) => boolean;
    'load-error': (_error: unknown, _node?: TreeNodeData) => boolean;
    search: (_searchKey: string) => boolean;
    clear: () => boolean;
};
