import _ResizeBox from './ResizeBox.vue';
import { resizeBoxProps } from './props';
declare const ResizeBox: import('../_utils/global-config').ComponentWithInstall<typeof _ResizeBox>;
export type ResizeBoxInstance = InstanceType<typeof _ResizeBox>;
export declare const _ResizeBoxComponent: typeof ResizeBox;
export { ResizeBox };
export { resizeBoxProps };
export default ResizeBox;
export type { ResizeBoxProps, ResizeBoxDirection } from './props';
