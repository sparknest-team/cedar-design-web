declare var __VLS_5: {}, __VLS_11: {}, __VLS_13: {};
type __VLS_Slots = {} & {
    image?: (props: typeof __VLS_5) => any;
} & {
    default?: (props: typeof __VLS_11) => any;
} & {
    extra?: (props: typeof __VLS_13) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    description: StringConstructor;
    imageUrl: StringConstructor;
    alt: {
        type: StringConstructor;
        default: string;
    };
    imageSize: {
        type: import("vue").PropType<import("./props").EmptyImageSize>;
        default: string;
    };
    showIcon: {
        type: BooleanConstructor;
        default: boolean;
    };
    showDescription: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    click: (event: MouseEvent) => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    description: StringConstructor;
    imageUrl: StringConstructor;
    alt: {
        type: StringConstructor;
        default: string;
    };
    imageSize: {
        type: import("vue").PropType<import("./props").EmptyImageSize>;
        default: string;
    };
    showIcon: {
        type: BooleanConstructor;
        default: boolean;
    };
    showDescription: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    onClick?: ((event: MouseEvent) => any) | undefined;
}>, {
    showIcon: boolean;
    alt: string;
    imageSize: import("./props").EmptyImageSize;
    showDescription: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
