import _Empty from './Empty.vue';
import { emptyProps } from './props';
declare const Empty: import('../_utils/global-config').ComponentWithInstall<typeof _Empty>;
export type EmptyInstance = InstanceType<typeof _Empty>;
export { emptyProps };
export type { EmptyImageSize, EmptyProps } from './props';
export { Empty };
export declare const _EmptyComponent: typeof Empty;
export default Empty;
