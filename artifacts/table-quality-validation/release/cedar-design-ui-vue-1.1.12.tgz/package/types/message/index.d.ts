import type { App } from 'vue';
import MessageComponentSource from './Message.vue';
import { messageProps } from './props';
import type { MessageMethod } from './types';
declare const Message: MessageMethod;
declare const MessageComponent: typeof MessageComponentSource & {
    install: (app: import("vue").App) => void;
};
export type { MessageVariant, MessageConfig, MessageContent, MessageItem, MessageMethod, MessageOptions, MessagePosition, MessageReturn, MessageStatus, } from './types';
export type { MessageProps } from './props';
export { messageProps };
export declare const _MessageComponent: typeof MessageComponent;
export type MessageInstance = InstanceType<typeof MessageComponentSource>;
export { Message };
export default Message;
