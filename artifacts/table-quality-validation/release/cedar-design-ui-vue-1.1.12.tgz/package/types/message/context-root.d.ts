import { type AppContext, type PropType, type VNode } from 'vue';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    appContext: {
        type: import("vue").PropType<import("vue").AppContext | null>;
        default: null;
    };
    renderVNode: {
        type: import("vue").PropType<() => import("vue").VNode>;
        required: true;
    };
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    appContext: {
        type: import("vue").PropType<import("vue").AppContext | null>;
        default: null;
    };
    renderVNode: {
        type: import("vue").PropType<() => import("vue").VNode>;
        required: true;
    };
}>> & Readonly<{}>, {
    appContext: import("vue").AppContext | null;
}>;
export default _default;
