import type { ComputedRef, InjectionKey, Ref, Slot } from 'vue';
import type { Orientation } from './platform';
import type { StepStatus, StepsContentPlacement, StepsSize, StepsType } from './props';
export interface StepsContext {
    current: import("vue").ComputedRef<number>;
    orientation: import("vue").ComputedRef<Orientation>;
    contentPlacement: import("vue").ComputedRef<StepsContentPlacement>;
    size: import("vue").ComputedRef<StepsSize>;
    type: import("vue").ComputedRef<StepsType>;
    showLine: import("vue").ComputedRef<boolean>;
    changeable: import("vue").ComputedRef<boolean>;
    icons: import("vue").Ref<{
        finish?: import("vue").Slot;
        error?: import("vue").Slot;
    }>;
    getStatus: (index: number, status?: StepStatus) => StepStatus;
    select: (index: number, event: Event) => void;
}
export declare const stepsInjectionKey: import("vue").InjectionKey<StepsContext>;
