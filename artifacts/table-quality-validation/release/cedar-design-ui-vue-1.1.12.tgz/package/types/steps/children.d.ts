import { type VNode } from 'vue';
export declare function flatChildren(children: import("vue").VNode[]): import("vue").VNode[];
