type MapValue = Record<string, unknown>;
export declare const mapEmits: {
    change: (_scopedValue: MapValue, _fullValue: MapValue) => boolean;
    error: (_error: unknown) => boolean;
    init: (_initialValue: MapValue, _completedValue: MapValue) => boolean;
    'loading:address': () => boolean;
    'loaded:address': () => boolean;
    'update:modelValue': (_value: MapValue) => boolean;
};
export declare const mapSelectEmits: {
    change: (_scopedValue: MapValue, _fullValue: MapValue) => boolean;
    error: (_error: unknown) => boolean;
    init: (_initialValue: MapValue, _completedValue: MapValue) => boolean;
    clear: () => boolean;
    'update:modelValue': (_value: MapValue) => boolean;
};
export type MapEmits = {
    [Event in keyof typeof mapEmits]: Parameters<(typeof mapEmits)[Event]>;
};
export type MapSelectEmits = {
    [Event in keyof typeof mapSelectEmits]: Parameters<(typeof mapSelectEmits)[Event]>;
};
export {};
