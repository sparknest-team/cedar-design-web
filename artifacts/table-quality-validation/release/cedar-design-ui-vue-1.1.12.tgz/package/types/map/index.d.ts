import _Map from './map';
import _MapSelect from './map-select';
import { mapProps, mapSelectProps } from './props';
declare const Map: import('../_utils/global-config').ComponentWithInstall<typeof _Map & {
    Select: typeof _MapSelect;
}>;
export type MapInstance = InstanceType<typeof _Map>;
export type MapSelectInstance = InstanceType<typeof _MapSelect>;
export type { MapProps, MapSelectProps, MapFetch, MapGeocoderHandler, MapGeocoderResult, ModelValueType, PoiKeys } from './props';
export type { MapEmits, MapSelectEmits } from './emits';
export type { MapSdk, MapSdkLngLat, MapSdkMap, MapSdkMapOptions, MapSdkSearchCompletion, MapSdkSearchOptions, MapSdkSearchService } from './sdk';
export { mapProps, mapSelectProps };
export { Map };
export { _MapSelect as MapSelect };
export declare const _MapComponent: typeof Map;
export declare const _MapSelectComponent: typeof _MapSelect;
export default Map;
