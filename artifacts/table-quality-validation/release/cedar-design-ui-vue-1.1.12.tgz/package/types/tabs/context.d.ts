import { type ComputedRef, type InjectionKey, type VNode } from 'vue';
import type { TabsName, TabsProps } from './props';
export interface TabEntry {
    name: TabsName;
    disabled: boolean;
    hasPanel: boolean;
}
export interface TabsContext {
    props: Readonly<TabsProps>;
    entries: import("vue").ComputedRef<TabEntry[]>;
    active: import("vue").ComputedRef<TabsName | undefined>;
    focused: {
        value: TabsName | undefined;
    };
    rtl: import("vue").ComputedRef<boolean>;
    id: (key: TabsName, part: 'tab' | 'panel' | 'title' | 'close') => string;
    select: (key: TabsName) => void;
    click: (key: TabsName, event: Event) => void;
    add: (event: Event) => void;
    remove: (key: TabsName, event: Event) => void;
}
export declare const tabsInjectionKey: import("vue").InjectionKey<TabsContext>;
export declare function flatten(nodes: import("vue").VNode[] | import("vue").VNode): import("vue").VNode[];
