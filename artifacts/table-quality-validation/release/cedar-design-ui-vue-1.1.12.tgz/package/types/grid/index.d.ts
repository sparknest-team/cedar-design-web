import Component from './Grid.vue';
import ItemComponent from './GridItem.vue';
import { gridProps } from './props';
import { gridItemProps } from './item-props';
declare const GridItem: import('../_utils/global-config').CedarComponentWithInstall<typeof ItemComponent>;
declare const Grid: import('../_utils/global-config').CedarComponentWithInstall<typeof Component & {
    Item: typeof GridItem;
}>;
export { Grid, GridItem, gridProps, gridItemProps };
export type { GridProps, GridItemProps, ResponsiveValue, GridItemData } from './types';
export type GridInstance = InstanceType<typeof Grid>;
export type GridItemInstance = InstanceType<typeof GridItem>;
export declare const _GridComponent: typeof Grid;
export declare const _GridItemComponent: typeof GridItem;
export default Grid;
