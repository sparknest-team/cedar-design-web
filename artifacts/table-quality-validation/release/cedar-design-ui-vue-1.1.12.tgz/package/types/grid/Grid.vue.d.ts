declare var __VLS_1: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    cols: {
        type: import("vue").PropType<number | import("./types").ResponsiveValue>;
        default: number;
        validator: ((value: unknown) => boolean) | undefined;
    };
    rowGap: {
        type: import("vue").PropType<number | import("./types").ResponsiveValue>;
        default: number;
        validator: ((value: unknown) => boolean) | undefined;
    };
    colGap: {
        type: import("vue").PropType<number | import("./types").ResponsiveValue>;
        default: number;
        validator: ((value: unknown) => boolean) | undefined;
    };
    collapsed: {
        type: BooleanConstructor;
        default: boolean;
    };
    collapsedRows: {
        type: NumberConstructor;
        default: number;
        validator: ((value: unknown) => value is number) | undefined;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    cols: {
        type: import("vue").PropType<number | import("./types").ResponsiveValue>;
        default: number;
        validator: ((value: unknown) => boolean) | undefined;
    };
    rowGap: {
        type: import("vue").PropType<number | import("./types").ResponsiveValue>;
        default: number;
        validator: ((value: unknown) => boolean) | undefined;
    };
    colGap: {
        type: import("vue").PropType<number | import("./types").ResponsiveValue>;
        default: number;
        validator: ((value: unknown) => boolean) | undefined;
    };
    collapsed: {
        type: BooleanConstructor;
        default: boolean;
    };
    collapsedRows: {
        type: NumberConstructor;
        default: number;
        validator: ((value: unknown) => value is number) | undefined;
    };
}>> & Readonly<{}>, {
    rowGap: number | Partial<Record<import("./types").Breakpoint, number>>;
    cols: number | Partial<Record<import("./types").Breakpoint, number>>;
    colGap: number | Partial<Record<import("./types").Breakpoint, number>>;
    collapsed: boolean;
    collapsedRows: number;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
