import type { ComputedRef, InjectionKey, Ref } from 'vue';
import type { GridItemData } from './types';
export interface GridRecord {
    id: symbol;
    data: import("vue").ComputedRef<GridItemData>;
    element: import("vue").Ref<HTMLElement | undefined>;
}
export interface GridContext {
    cols: import("vue").ComputedRef<number>;
    colGap: import("vue").ComputedRef<number>;
    overflow: import("vue").ComputedRef<boolean>;
    visible: (id: symbol) => boolean;
    register: (record: GridRecord) => void;
    remove: (id: symbol) => void;
    reorder: () => void;
}
export declare const GRID_CONTEXT_KEY: import("vue").InjectionKey<GridContext>;
