export * from '../col/props';
