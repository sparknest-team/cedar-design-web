declare var __VLS_1: {
    overflow: boolean;
};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    span: {
        type: import("vue").PropType<number | import("./types").ResponsiveValue>;
        default: number;
        validator: ((value: unknown) => boolean) | undefined;
    };
    offset: {
        type: import("vue").PropType<number | import("./types").ResponsiveValue>;
        default: number;
        validator: ((value: unknown) => boolean) | undefined;
    };
    suffix: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    span: {
        type: import("vue").PropType<number | import("./types").ResponsiveValue>;
        default: number;
        validator: ((value: unknown) => boolean) | undefined;
    };
    offset: {
        type: import("vue").PropType<number | import("./types").ResponsiveValue>;
        default: number;
        validator: ((value: unknown) => boolean) | undefined;
    };
    suffix: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{}>, {
    span: number | Partial<Record<import("./types").Breakpoint, number>>;
    offset: number | Partial<Record<import("./types").Breakpoint, number>>;
    suffix: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
