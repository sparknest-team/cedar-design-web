import { PropType } from 'vue';
import { VirtualListProps } from '../_components/virtual-list-v2/interface';
import { CascaderOptionInfo } from './types';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    displayColumns: {
        type: import("vue").PropType<CascaderOptionInfo[][]>;
        required: true;
    };
    selectedPath: {
        type: import("vue").PropType<string[]>;
        required: true;
    };
    activeKey: StringConstructor;
    totalLevel: {
        type: NumberConstructor;
        required: true;
    };
    multiple: BooleanConstructor;
    checkStrictly: BooleanConstructor;
    loading: BooleanConstructor;
    dropdown: BooleanConstructor;
    virtualListProps: {
        type: import("vue").PropType<VirtualListProps>;
    };
}>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    displayColumns: {
        type: import("vue").PropType<CascaderOptionInfo[][]>;
        required: true;
    };
    selectedPath: {
        type: import("vue").PropType<string[]>;
        required: true;
    };
    activeKey: StringConstructor;
    totalLevel: {
        type: NumberConstructor;
        required: true;
    };
    multiple: BooleanConstructor;
    checkStrictly: BooleanConstructor;
    loading: BooleanConstructor;
    dropdown: BooleanConstructor;
    virtualListProps: {
        type: import("vue").PropType<VirtualListProps>;
    };
}>> & Readonly<{}>, {
    loading: boolean;
    multiple: boolean;
    dropdown: boolean;
    checkStrictly: boolean;
}>;
export default _default;
