import type { VirtualListProps } from '../_components/virtual-list-v2/interface';
import type { CascaderOptionInfo } from './types';
type __VLS_Props = {
    displayColumns: CascaderOptionInfo[][];
    selectedPath: string[];
    activeKey?: string;
    totalLevel: number;
    multiple?: boolean;
    checkStrictly?: boolean;
    loading?: boolean;
    virtualListProps?: VirtualListProps;
};
declare var __VLS_4: {}, __VLS_14: {};
type __VLS_Slots = {} & {
    empty?: (props: typeof __VLS_4) => any;
} & {
    empty?: (props: typeof __VLS_14) => any;
};
declare const __VLS_component: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
