export declare const cascaderEmits: {
    /** @zh 字段或编辑面板按键事件 @en Keyboard event from the field or editor panel */
    keydown: (_event: KeyboardEvent) => boolean;
    'load-error': (error: unknown) => boolean;
    'update:modelValue': (value: string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | null | undefined) => boolean;
    'update:open': (visible: boolean) => boolean;
    /**
     * @zh 选中值改变时触发
     * @en Triggered when the selected value changes
     * @property {string | number | (string | number | (string | number)[])[] | undefined} value
     */
    change: (value: string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | null | undefined) => boolean;
    /**
     * @zh 输入值改变时触发
     * @en Triggered when the input value changes
     * @property {string} value
     */
    'update:inputValue': (value: string) => boolean;
    'input-value-change': (value: string) => boolean;
    /**
     * @zh 点击清除按钮时触发
     * @en Triggered when the clear button is clicked
     */
    clear: (event: Event) => boolean;
    /**
     * @zh 用户搜索时触发
     * @en Triggered when the user searches
     * @property {string} value
     */
    search: (value: string) => boolean;
    /**
     * @zh 下拉框的显示状态改变时触发
     * @en Triggered when the display state of the dropdown changes
     * @property {boolean} visible
     */
    'open-change': (visible: boolean) => boolean;
    /**
     * @zh 获得焦点时触发
     * @en Triggered when focus
     * @param {FocusEvent} ev
     */
    focus: (ev: FocusEvent) => boolean;
    /**
     * @zh 失去焦点时触发
     * @en Triggered when blur
     * @param {FocusEvent} ev
     */
    blur: (ev: FocusEvent) => boolean;
};
