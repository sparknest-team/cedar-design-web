import { PropType } from 'vue';
import { VirtualListProps } from '../_components/virtual-list-v2/interface';
import { CascaderOptionInfo } from './types';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    column: {
        type: import("vue").PropType<CascaderOptionInfo[]>;
        required: true;
    };
    level: {
        type: NumberConstructor;
        default: number;
    };
    menuId: StringConstructor;
    nextMenuId: StringConstructor;
    selectedPath: {
        type: import("vue").PropType<string[]>;
        required: true;
    };
    activeKey: StringConstructor;
    focusedKey: StringConstructor;
    tabEntry: {
        type: BooleanConstructor;
        default: boolean;
    };
    totalLevel: {
        type: NumberConstructor;
        required: true;
    };
    displayedLevels: {
        type: NumberConstructor;
        default: number;
    };
    multiple: BooleanConstructor;
    checkStrictly: BooleanConstructor;
    virtualListProps: {
        type: import("vue").PropType<VirtualListProps>;
    };
}>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    column: {
        type: import("vue").PropType<CascaderOptionInfo[]>;
        required: true;
    };
    level: {
        type: NumberConstructor;
        default: number;
    };
    menuId: StringConstructor;
    nextMenuId: StringConstructor;
    selectedPath: {
        type: import("vue").PropType<string[]>;
        required: true;
    };
    activeKey: StringConstructor;
    focusedKey: StringConstructor;
    tabEntry: {
        type: BooleanConstructor;
        default: boolean;
    };
    totalLevel: {
        type: NumberConstructor;
        required: true;
    };
    displayedLevels: {
        type: NumberConstructor;
        default: number;
    };
    multiple: BooleanConstructor;
    checkStrictly: BooleanConstructor;
    virtualListProps: {
        type: import("vue").PropType<VirtualListProps>;
    };
}>> & Readonly<{}>, {
    multiple: boolean;
    level: number;
    checkStrictly: boolean;
    tabEntry: boolean;
    displayedLevels: number;
}>;
export default _default;
