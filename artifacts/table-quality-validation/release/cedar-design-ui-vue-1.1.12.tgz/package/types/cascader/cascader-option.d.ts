import type { PropType } from 'vue';
import type { CascaderOptionInfo } from './types';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    option: {
        type: import("vue").PropType<CascaderOptionInfo>;
        required: true;
    };
    active: BooleanConstructor;
    expanded: BooleanConstructor;
    childMenuId: StringConstructor;
    multiple: BooleanConstructor;
    checkStrictly: BooleanConstructor;
    searchOption: BooleanConstructor;
    multipleGroupOption: BooleanConstructor;
    pathLabel: BooleanConstructor;
    listboxOption: BooleanConstructor;
    listboxSelected: BooleanConstructor;
    optionId: StringConstructor;
    tabIndex: {
        type: NumberConstructor;
        default: number;
    };
}>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    option: {
        type: import("vue").PropType<CascaderOptionInfo>;
        required: true;
    };
    active: BooleanConstructor;
    expanded: BooleanConstructor;
    childMenuId: StringConstructor;
    multiple: BooleanConstructor;
    checkStrictly: BooleanConstructor;
    searchOption: BooleanConstructor;
    multipleGroupOption: BooleanConstructor;
    pathLabel: BooleanConstructor;
    listboxOption: BooleanConstructor;
    listboxSelected: BooleanConstructor;
    optionId: StringConstructor;
    tabIndex: {
        type: NumberConstructor;
        default: number;
    };
}>> & Readonly<{}>, {
    expanded: boolean;
    multiple: boolean;
    active: boolean;
    tabIndex: number;
    checkStrictly: boolean;
    searchOption: boolean;
    multipleGroupOption: boolean;
    pathLabel: boolean;
    listboxOption: boolean;
    listboxSelected: boolean;
}>;
export default _default;
