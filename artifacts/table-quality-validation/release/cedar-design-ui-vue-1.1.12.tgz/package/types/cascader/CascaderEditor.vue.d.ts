type __VLS_Props = {
    options: Record<string, any>;
    modelValue?: any;
};
declare var __VLS_13: string | number, __VLS_14: any;
type __VLS_Slots = {} & {
    [K in NonNullable<typeof __VLS_13>]?: (props: typeof __VLS_14) => any;
};
declare const __VLS_component: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    search: (query: string) => any;
    keydown: (event: KeyboardEvent) => any;
    "update:modelValue": (value: any) => any;
    "update:inputValue": (query: string) => any;
    "input-value-change": (query: string) => any;
}, string, import("../vue-compat").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onSearch?: ((query: string) => any) | undefined;
    onKeydown?: ((event: KeyboardEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: any) => any) | undefined;
    "onUpdate:inputValue"?: ((query: string) => any) | undefined;
    "onInput-value-change"?: ((query: string) => any) | undefined;
}>, {}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
