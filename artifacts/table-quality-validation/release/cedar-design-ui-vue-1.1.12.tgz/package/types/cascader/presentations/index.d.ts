export declare const presentations: {
    inline: {
        component: {
            new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<{
                controller: {
                    props: {
                        openTriggerTarget?: "field" | "icon";
                        triggerProps?: import("../../index.ts").TriggerProps;
                        popupContainer?: import("../../index.ts").TriggerProps["popupContainer"];
                        autoFitPopupWidth?: boolean;
                        unmountOnClose?: boolean;
                        filterable?: boolean | object;
                        creatable?: boolean;
                    };
                    computedOpen: boolean;
                    mergedDisabled: boolean;
                    mergedReadonly: boolean;
                    handleOpenChange: (open: boolean) => void;
                };
            }> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("../../vue-compat").PublicProps, {}, false>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<{
            controller: {
                props: {
                    openTriggerTarget?: "field" | "icon";
                    triggerProps?: import("../../index.ts").TriggerProps;
                    popupContainer?: import("../../index.ts").TriggerProps["popupContainer"];
                    autoFitPopupWidth?: boolean;
                    unmountOnClose?: boolean;
                    filterable?: boolean | object;
                    creatable?: boolean;
                };
                computedOpen: boolean;
                mergedDisabled: boolean;
                mergedReadonly: boolean;
                handleOpenChange: (open: boolean) => void;
            };
        }> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
            $slots: {
                reference?: (props: {}) => any;
            } & {
                default?: (props: {}) => any;
            };
        });
        deferred: (_multiple: boolean) => boolean;
    };
};
