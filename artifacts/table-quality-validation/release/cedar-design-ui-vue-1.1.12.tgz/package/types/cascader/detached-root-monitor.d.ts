export declare function watchDetachedRoots(check: () => void): () => void;
