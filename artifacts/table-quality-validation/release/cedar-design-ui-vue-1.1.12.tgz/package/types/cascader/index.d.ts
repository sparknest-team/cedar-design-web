import _CascaderPanel from './CascaderPanel.vue';
import _Cascader from './presentation';
import { cascaderProps } from './props';
import { cascaderPanelProps } from './panel-props';
declare const Cascader: import('../_utils/global-config').ComponentWithInstall<typeof _Cascader & {
    CascaderPanel: typeof _CascaderPanel;
}>;
export type CascaderInstance = InstanceType<typeof _Cascader> & import('./types').CascaderExpose;
export type CascaderPanelInstance = InstanceType<typeof _CascaderPanel>;
export type CascaderPanelProps = import('../_utils/public-props').CompatiblePublicProps<typeof cascaderPanelProps>;
export { cascaderPanelProps };
export type { CascaderOption, CascaderFieldNames } from './types';
export { _CascaderPanel as CascaderPanel };
export declare const _CascaderComponent: typeof Cascader;
export declare const _CascaderPanelComponent: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    pathMode: {
        type: BooleanConstructor;
        default: boolean;
    };
    multiple: {
        type: BooleanConstructor;
        default: boolean;
    };
    modelValue: {
        type: import("vue").PropType<string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined>;
    };
    defaultValue: {
        type: import("vue").PropType<string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined>;
        default: (props: import("../_utils/types.ts").Data) => "" | never[] | undefined;
    };
    options: {
        type: import("vue").PropType<import("./types").CascaderOption[]>;
        default: () => never[];
    };
    expandTrigger: {
        type: import("vue").PropType<"click" | "hover">;
        default: string;
    };
    checkStrictly: {
        type: BooleanConstructor;
        default: boolean;
    };
    loadMore: {
        type: import("vue").PropType<(option: import("./types").CascaderOption, done: (children?: import("./types").CascaderOption[]) => void) => void>;
    };
    fieldNames: {
        type: import("vue").PropType<import("./types").CascaderFieldNames>;
    };
    expandChild: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {
    panelRef: import("vue").Ref<{
        $el: HTMLElement;
    } | undefined>;
    optionInfos: import("vue").Ref<{
        [x: string]: any;
        raw: Record<string, unknown>;
        key: string;
        valueKey: string;
        level: number;
        index: number;
        value: import("../_utils/types.ts").BaseType | Record<string, any>;
        label: string;
        disabled: boolean;
        selectionDisabled: boolean;
        isLeaf: boolean;
        parent?: any | undefined;
        children?: any[] | undefined;
        path: any[];
        pathValue: any[];
        totalLeafOptions?: number | undefined;
        render?: import("vue").RenderFunction | undefined;
        tagProps?: {
            closable?: boolean | undefined;
            round?: boolean | undefined;
            size?: "xs" | "sm" | "md" | "lg" | "xl" | undefined;
            status?: "default" | "primary" | "secondary" | "tertiary" | "info" | "success" | "warning" | "danger" | undefined;
            variant?: import("../index.ts").TagVariant | undefined;
            color?: string | undefined;
            loading?: boolean | undefined;
            textColor?: string | undefined;
            modelValue?: boolean | undefined;
            defaultValue?: boolean | undefined;
            show?: boolean | undefined;
            nowrap?: boolean | undefined;
            defaultShow?: boolean | undefined;
            closeButtonAriaLabel?: string | undefined;
            checkable?: boolean | undefined;
        } | undefined;
    }[]>;
    filteredLeafOptions: import("vue").ComputedRef<{
        [x: string]: any;
        raw: Record<string, unknown>;
        key: string;
        valueKey: string;
        level: number;
        index: number;
        value: import("../_utils/types.ts").BaseType | Record<string, any>;
        label: string;
        disabled: boolean;
        selectionDisabled: boolean;
        isLeaf: boolean;
        parent?: any | undefined;
        children?: any[] | undefined;
        path: any[];
        pathValue: any[];
        totalLeafOptions?: number | undefined;
        render?: import("vue").RenderFunction | undefined;
        tagProps?: {
            closable?: boolean | undefined;
            round?: boolean | undefined;
            size?: "xs" | "sm" | "md" | "lg" | "xl" | undefined;
            status?: "default" | "primary" | "secondary" | "tertiary" | "info" | "success" | "warning" | "danger" | undefined;
            variant?: import("../index.ts").TagVariant | undefined;
            color?: string | undefined;
            loading?: boolean | undefined;
            textColor?: string | undefined;
            modelValue?: boolean | undefined;
            defaultValue?: boolean | undefined;
            show?: boolean | undefined;
            nowrap?: boolean | undefined;
            defaultShow?: boolean | undefined;
            closeButtonAriaLabel?: string | undefined;
            checkable?: boolean | undefined;
        } | undefined;
    }[]>;
    selectedPath: import("vue").Ref<string[]>;
    activeKey: import("vue").Ref<string | undefined>;
    displayColumns: import("vue").ComputedRef<import("./types").CascaderOptionInfo[][]>;
    handleKeyDown: (event: KeyboardEvent) => Promise<void> | undefined;
    totalLevel: import("vue").Ref<number>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    'update:modelValue': (value: string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined) => true;
    change: (value: string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined) => true;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    pathMode: {
        type: BooleanConstructor;
        default: boolean;
    };
    multiple: {
        type: BooleanConstructor;
        default: boolean;
    };
    modelValue: {
        type: import("vue").PropType<string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined>;
    };
    defaultValue: {
        type: import("vue").PropType<string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined>;
        default: (props: import("../_utils/types.ts").Data) => "" | never[] | undefined;
    };
    options: {
        type: import("vue").PropType<import("./types").CascaderOption[]>;
        default: () => never[];
    };
    expandTrigger: {
        type: import("vue").PropType<"click" | "hover">;
        default: string;
    };
    checkStrictly: {
        type: BooleanConstructor;
        default: boolean;
    };
    loadMore: {
        type: import("vue").PropType<(option: import("./types").CascaderOption, done: (children?: import("./types").CascaderOption[]) => void) => void>;
    };
    fieldNames: {
        type: import("vue").PropType<import("./types").CascaderFieldNames>;
    };
    expandChild: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    onChange?: ((value: string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined) => any) | undefined;
    "onUpdate:modelValue"?: ((value: string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined) => any) | undefined;
}>, {
    defaultValue: string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined;
    multiple: boolean;
    options: import("./types").CascaderOption[];
    pathMode: boolean;
    checkStrictly: boolean;
    expandTrigger: "hover" | "click";
    expandChild: boolean;
}>;
export { Cascader };
export { cascaderProps };
export default Cascader;
export type CascaderProps = import('../_utils/public-props').CompatiblePublicProps<typeof import('./props').cascaderProps>;
export type { CascaderTriggerOptions } from './trigger-options';
export type { CascaderEditMode } from './props';
export type { CascaderBaseValue, CascaderOptionInfo, CascaderReadScope, CascaderEmits, CascaderSlots, CascaderExpose } from './types';
