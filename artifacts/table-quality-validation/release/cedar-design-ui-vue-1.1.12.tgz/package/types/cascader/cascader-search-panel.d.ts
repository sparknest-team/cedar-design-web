import { PropType } from 'vue';
import { CascaderOptionInfo } from './types';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    options: {
        type: import("vue").PropType<CascaderOptionInfo[]>;
        required: true;
    };
    loading: BooleanConstructor;
    activeKey: StringConstructor;
    multiple: BooleanConstructor;
    multipleGroup: BooleanConstructor;
    multipleDialog: BooleanConstructor;
    reportPopupElement: import("vue").PropType<(element: HTMLElement | null) => void>;
    focusRecoveryEnabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    focusFallback: import("vue").PropType<() => void>;
    checkStrictly: BooleanConstructor;
    pathLabel: BooleanConstructor;
    listboxId: StringConstructor;
    listboxLabel: StringConstructor;
}>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    options: {
        type: import("vue").PropType<CascaderOptionInfo[]>;
        required: true;
    };
    loading: BooleanConstructor;
    activeKey: StringConstructor;
    multiple: BooleanConstructor;
    multipleGroup: BooleanConstructor;
    multipleDialog: BooleanConstructor;
    reportPopupElement: import("vue").PropType<(element: HTMLElement | null) => void>;
    focusRecoveryEnabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    focusFallback: import("vue").PropType<() => void>;
    checkStrictly: BooleanConstructor;
    pathLabel: BooleanConstructor;
    listboxId: StringConstructor;
    listboxLabel: StringConstructor;
}>> & Readonly<{}>, {
    loading: boolean;
    multiple: boolean;
    checkStrictly: boolean;
    pathLabel: boolean;
    multipleGroup: boolean;
    multipleDialog: boolean;
    focusRecoveryEnabled: boolean;
}>;
export default _default;
