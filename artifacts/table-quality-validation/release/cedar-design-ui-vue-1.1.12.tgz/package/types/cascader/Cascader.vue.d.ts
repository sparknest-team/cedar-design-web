declare var __VLS_20: {
    data: import("../_components/selection-field/props.ts").SelectionFieldItem;
}, __VLS_22: {}, __VLS_24: {}, __VLS_26: {}, __VLS_28: {
    clear: (event?: Event) => void;
}, __VLS_30: {
    focus: boolean;
    menuOpen: boolean;
}, __VLS_32: {}, __VLS_34: {}, __VLS_42: string | number, __VLS_43: any;
type __VLS_Slots = {} & {
    [K in NonNullable<typeof __VLS_42>]?: (props: typeof __VLS_43) => any;
} & {
    label?: (props: typeof __VLS_20) => any;
} & {
    prefix?: (props: typeof __VLS_22) => any;
} & {
    selected?: (props: typeof __VLS_24) => any;
} & {
    suffix?: (props: typeof __VLS_26) => any;
} & {
    'clear-icon'?: (props: typeof __VLS_28) => any;
} & {
    'arrow-icon'?: (props: typeof __VLS_30) => any;
} & {
    'loading-icon'?: (props: typeof __VLS_32) => any;
} & {
    'search-icon'?: (props: typeof __VLS_34) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<string | number | (string | number)[] | (string | number)[][]>>;
        default: undefined;
    };
    showTags: {
        type: BooleanConstructor;
        default: boolean;
    };
    separator: {
        type: StringConstructor;
        default: string;
    };
    textAlign: {
        type: import("vue").PropType<"left" | "right" | "center">;
    };
    autoFitPopupWidth: {
        type: BooleanConstructor;
        default: boolean;
    };
    hint: {
        type: BooleanConstructor;
        default: boolean;
    };
    line: {
        type: BooleanConstructor;
        default: boolean;
    };
    textColor: StringConstructor;
    focusColor: StringConstructor;
    blurColor: StringConstructor;
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    variant: {
        type: import("vue").PropType<import("../_utils/form-control.ts").FormControlVariant>;
        default: undefined;
        validator: (value: import("../_utils/form-control.ts").FormControlVariant) => boolean;
    };
    pathMode: {
        type: BooleanConstructor;
        default: boolean;
    };
    multiple: {
        type: BooleanConstructor;
        default: boolean;
    };
    modelValue: {
        type: import("vue").PropType<string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined>;
    };
    defaultValue: {
        type: import("vue").PropType<string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined>;
        default: (props: import("../_utils/types.ts").Data) => "" | never[] | undefined;
    };
    options: {
        type: import("vue").PropType<readonly import("./types.ts").CascaderOption[] | import("../_hooks/use-option-request.ts").OptionsLoader<import("./types.ts").CascaderOption>>;
        default: undefined;
    };
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    error: {
        type: BooleanConstructor;
        default: undefined;
    };
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
    };
    filterable: {
        type: BooleanConstructor;
        default: (props: import("../_utils/types.ts").Data) => boolean;
    };
    clearable: {
        type: BooleanConstructor;
        default: boolean;
    };
    inputValue: {
        type: StringConstructor;
        default: undefined;
    };
    defaultInputValue: {
        type: StringConstructor;
        default: string;
    };
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    expandTrigger: {
        type: import("vue").PropType<"click" | "hover">;
        default: string;
    };
    defaultOpen: {
        type: BooleanConstructor;
        default: boolean;
    };
    placeholder: StringConstructor;
    filterOption: {
        type: import("vue").PropType<(inputValue: string, option: import("./types.ts").CascaderOption) => boolean>;
    };
    popupContainer: {
        type: import("vue").PropType<import("../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    maxTagCount: {
        type: NumberConstructor;
        validator: (value: number) => boolean;
        default: number;
    };
    formatLabel: {
        type: import("vue").PropType<(options: import("./types.ts").CascaderOption[]) => string>;
    };
    triggerProps: {
        type: import("vue").PropType<import("../index.ts").TriggerProps>;
    };
    checkStrictly: {
        type: BooleanConstructor;
        default: boolean;
    };
    loadMore: {
        type: import("vue").PropType<(option: import("./types.ts").CascaderOption, done: (children?: import("./types.ts").CascaderOption[]) => void) => void>;
    };
    searchOptionOnlyLabel: {
        type: BooleanConstructor;
        default: boolean;
    };
    searchDelay: {
        type: NumberConstructor;
        validator: (value: number) => boolean;
        default: number;
    };
    fieldNames: {
        type: import("vue").PropType<import("./types.ts").CascaderFieldNames>;
    };
    fallbackOption: {
        type: import("vue").PropType<boolean | ((value: string | number | Record<string, unknown> | (string | number | Record<string, unknown>)[]) => {
            value: unknown;
            label: string;
        })>;
        default: boolean;
    };
    expandChild: {
        type: BooleanConstructor;
        default: boolean;
    };
    virtualListProps: {
        type: import("vue").PropType<import("../_components/virtual-list-v2/interface.ts").VirtualListProps>;
    };
    tagNowrap: {
        type: BooleanConstructor;
        default: boolean;
    };
    editMode: {
        type: import("vue").PropType<import("../index.ts").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
    beforeCommit: import("vue").PropType<import("../index.ts").BeforeFieldCommit>;
    needConfirm: {
        type: BooleanConstructor;
        default: undefined;
    };
    openTriggerTarget: {
        type: import("vue").PropType<import("../index.ts").OpenTriggerTarget>;
        default: "field";
        validator: (value: string) => value is "icon" | "field";
    };
    caseSensitive: {
        type: BooleanConstructor;
        default: boolean;
    };
    searchFields: {
        type: import("vue").PropType<readonly import("../index.ts").OptionSearchField[]>;
        default: () => string[];
    };
    loading: BooleanConstructor;
    loadingMode: {
        type: import("vue").PropType<import("../index.ts").FieldLoadingMode>;
        default: string;
        validator: (value: import("../index.ts").FieldLoadingMode) => boolean;
    };
}>, {
    refresh: () => Promise<void>;
    focus: () => void | undefined;
    blur: () => void | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    focus: (ev: FocusEvent) => void;
    clear: (event: Event) => void;
    search: (value: string) => void;
    blur: (ev: FocusEvent) => void;
    change: (value: string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | null | undefined) => void;
    keydown: (_event: KeyboardEvent) => void;
    "update:open": (visible: boolean) => void;
    "open-change": (visible: boolean) => void;
    "load-error": (error: unknown) => void;
    "update:modelValue": (value: string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | null | undefined) => void;
    "update:inputValue": (value: string) => void;
    "input-value-change": (value: string) => void;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    emptyValue: {
        type: import("vue").PropType<import("../_utils/empty-value.ts").EmptyValue<string | number | (string | number)[] | (string | number)[][]>>;
        default: undefined;
    };
    showTags: {
        type: BooleanConstructor;
        default: boolean;
    };
    separator: {
        type: StringConstructor;
        default: string;
    };
    textAlign: {
        type: import("vue").PropType<"left" | "right" | "center">;
    };
    autoFitPopupWidth: {
        type: BooleanConstructor;
        default: boolean;
    };
    hint: {
        type: BooleanConstructor;
        default: boolean;
    };
    line: {
        type: BooleanConstructor;
        default: boolean;
    };
    textColor: StringConstructor;
    focusColor: StringConstructor;
    blurColor: StringConstructor;
    readonly: {
        type: BooleanConstructor;
        default: undefined;
    };
    variant: {
        type: import("vue").PropType<import("../_utils/form-control.ts").FormControlVariant>;
        default: undefined;
        validator: (value: import("../_utils/form-control.ts").FormControlVariant) => boolean;
    };
    pathMode: {
        type: BooleanConstructor;
        default: boolean;
    };
    multiple: {
        type: BooleanConstructor;
        default: boolean;
    };
    modelValue: {
        type: import("vue").PropType<string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined>;
    };
    defaultValue: {
        type: import("vue").PropType<string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined>;
        default: (props: import("../_utils/types.ts").Data) => "" | never[] | undefined;
    };
    options: {
        type: import("vue").PropType<readonly import("./types.ts").CascaderOption[] | import("../_hooks/use-option-request.ts").OptionsLoader<import("./types.ts").CascaderOption>>;
        default: undefined;
    };
    disabled: {
        type: BooleanConstructor;
        default: undefined;
    };
    error: {
        type: BooleanConstructor;
        default: undefined;
    };
    size: {
        type: import("vue").PropType<import("../index.ts").ComponentSize>;
    };
    filterable: {
        type: BooleanConstructor;
        default: (props: import("../_utils/types.ts").Data) => boolean;
    };
    clearable: {
        type: BooleanConstructor;
        default: boolean;
    };
    inputValue: {
        type: StringConstructor;
        default: undefined;
    };
    defaultInputValue: {
        type: StringConstructor;
        default: string;
    };
    open: {
        type: BooleanConstructor;
        default: undefined;
    };
    expandTrigger: {
        type: import("vue").PropType<"click" | "hover">;
        default: string;
    };
    defaultOpen: {
        type: BooleanConstructor;
        default: boolean;
    };
    placeholder: StringConstructor;
    filterOption: {
        type: import("vue").PropType<(inputValue: string, option: import("./types.ts").CascaderOption) => boolean>;
    };
    popupContainer: {
        type: import("vue").PropType<import("../index.ts").PopupContainer>;
        default: undefined;
        validator: ((value: unknown) => value is string | false | HTMLElement) | undefined;
    };
    maxTagCount: {
        type: NumberConstructor;
        validator: (value: number) => boolean;
        default: number;
    };
    formatLabel: {
        type: import("vue").PropType<(options: import("./types.ts").CascaderOption[]) => string>;
    };
    triggerProps: {
        type: import("vue").PropType<import("../index.ts").TriggerProps>;
    };
    checkStrictly: {
        type: BooleanConstructor;
        default: boolean;
    };
    loadMore: {
        type: import("vue").PropType<(option: import("./types.ts").CascaderOption, done: (children?: import("./types.ts").CascaderOption[]) => void) => void>;
    };
    searchOptionOnlyLabel: {
        type: BooleanConstructor;
        default: boolean;
    };
    searchDelay: {
        type: NumberConstructor;
        validator: (value: number) => boolean;
        default: number;
    };
    fieldNames: {
        type: import("vue").PropType<import("./types.ts").CascaderFieldNames>;
    };
    fallbackOption: {
        type: import("vue").PropType<boolean | ((value: string | number | Record<string, unknown> | (string | number | Record<string, unknown>)[]) => {
            value: unknown;
            label: string;
        })>;
        default: boolean;
    };
    expandChild: {
        type: BooleanConstructor;
        default: boolean;
    };
    virtualListProps: {
        type: import("vue").PropType<import("../_components/virtual-list-v2/interface.ts").VirtualListProps>;
    };
    tagNowrap: {
        type: BooleanConstructor;
        default: boolean;
    };
    editMode: {
        type: import("vue").PropType<import("../index.ts").FieldEditMode>;
        default: undefined;
        validator: (value: string) => boolean;
    };
    readPretty: {
        type: BooleanConstructor;
        default: undefined;
    };
    emptyValues: {
        type: import("vue").PropType<readonly unknown[]>;
        default: undefined;
    };
    emptyText: {
        type: StringConstructor;
        default: undefined;
    };
    beforeCommit: import("vue").PropType<import("../index.ts").BeforeFieldCommit>;
    needConfirm: {
        type: BooleanConstructor;
        default: undefined;
    };
    openTriggerTarget: {
        type: import("vue").PropType<import("../index.ts").OpenTriggerTarget>;
        default: "field";
        validator: (value: string) => value is "icon" | "field";
    };
    caseSensitive: {
        type: BooleanConstructor;
        default: boolean;
    };
    searchFields: {
        type: import("vue").PropType<readonly import("../index.ts").OptionSearchField[]>;
        default: () => string[];
    };
    loading: BooleanConstructor;
    loadingMode: {
        type: import("vue").PropType<import("../index.ts").FieldLoadingMode>;
        default: string;
        validator: (value: import("../index.ts").FieldLoadingMode) => boolean;
    };
}>> & Readonly<{
    onFocus?: ((ev: FocusEvent) => any) | undefined;
    onClear?: ((event: Event) => any) | undefined;
    onSearch?: ((value: string) => any) | undefined;
    onBlur?: ((ev: FocusEvent) => any) | undefined;
    onChange?: ((value: string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | null | undefined) => any) | undefined;
    onKeydown?: ((_event: KeyboardEvent) => any) | undefined;
    "onUpdate:open"?: ((visible: boolean) => any) | undefined;
    "onOpen-change"?: ((visible: boolean) => any) | undefined;
    "onLoad-error"?: ((error: unknown) => any) | undefined;
    "onUpdate:modelValue"?: ((value: string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | null | undefined) => any) | undefined;
    "onUpdate:inputValue"?: ((value: string) => any) | undefined;
    "onInput-value-change"?: ((value: string) => any) | undefined;
}>, {
    error: boolean;
    readonly: boolean;
    line: boolean;
    disabled: boolean;
    variant: "outline" | "standard" | "filled";
    loading: boolean;
    editMode: import("../index.ts").FieldEditMode;
    readPretty: boolean;
    loadingMode: "default" | "line";
    hint: boolean;
    clearable: boolean;
    emptyValue: import("../_utils/empty-value.ts").EmptyValue<string | number | (string | number)[] | (string | number)[][]>;
    emptyValues: readonly unknown[];
    emptyText: string;
    popupContainer: import("../index.ts").PopupContainer;
    open: boolean;
    defaultOpen: boolean;
    defaultValue: string | number | Record<string, any> | (string | number | Record<string, any> | (string | number | Record<string, any>)[])[] | undefined;
    autoFitPopupWidth: boolean;
    separator: string;
    multiple: boolean;
    needConfirm: boolean;
    openTriggerTarget: import("../index.ts").OpenTriggerTarget;
    options: readonly import("./types.ts").CascaderOption[] | import("../_hooks/use-option-request.ts").OptionsLoader<import("./types.ts").CascaderOption>;
    searchDelay: number;
    inputValue: string;
    defaultInputValue: string;
    caseSensitive: boolean;
    searchFields: readonly import("../index.ts").OptionSearchField[];
    showTags: boolean;
    filterable: boolean;
    maxTagCount: number;
    fallbackOption: boolean | ((value: string | number | Record<string, unknown> | (string | number | Record<string, unknown>)[]) => {
        value: unknown;
        label: string;
    });
    tagNowrap: boolean;
    pathMode: boolean;
    checkStrictly: boolean;
    expandTrigger: "hover" | "click";
    expandChild: boolean;
    searchOptionOnlyLabel: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
