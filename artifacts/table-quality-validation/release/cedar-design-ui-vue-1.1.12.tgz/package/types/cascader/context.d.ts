import { InjectionKey, Slots } from 'vue';
import { UnionType } from '../_utils/types';
import { CascaderOption, CascaderOptionInfo } from './types';
export interface CascaderContext {
    expandOption: (option: CascaderOptionInfo) => Promise<void>;
    isOptionLoading?: (key: string) => boolean;
    onClickOption: (option: CascaderOptionInfo, checked?: boolean) => void;
    setActiveKey: (key?: string) => void;
    setSelectedPath: (key?: string) => void;
    formatLabel?: (options: CascaderOption[]) => string;
    slots: import("vue").Slots;
    valueMap: Map<string, UnionType | UnionType[]>;
    expandTrigger: 'click' | 'hover';
}
export declare const cascaderInjectionKey: import("vue").InjectionKey<CascaderContext>;
