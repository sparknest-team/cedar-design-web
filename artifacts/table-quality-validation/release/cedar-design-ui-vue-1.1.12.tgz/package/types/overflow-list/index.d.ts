import _OverflowList from './overflow-list';
import { overflowListProps } from './props';
declare const OverflowList: import('../_utils/global-config').ComponentWithInstall<typeof _OverflowList>;
export type OverflowListInstance = InstanceType<typeof _OverflowList>;
export declare const _OverflowListComponent: typeof OverflowList;
export { OverflowList };
export { overflowListProps };
export default OverflowList;
export type { OverflowListProps } from './props';
