import type { SchedulerEvent } from "./core";
export type SchedulerResize = boolean | "start";
export declare function projectSchedulerDrag(event: SchedulerEvent, at: Date, resize: SchedulerResize, step: number, startHour: number, fromResourceId?: string, toResourceId?: string, allDay?: boolean): SchedulerEvent | undefined;
