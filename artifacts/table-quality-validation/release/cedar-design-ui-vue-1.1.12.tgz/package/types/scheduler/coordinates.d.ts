import type { ReadingDirection } from "../_utils/direction";
/** Screen coordinates stay physical; only horizontal time runs from inline start. */
export declare function schedulerPointerFraction(rect: Pick<DOMRect, "left" | "right" | "top" | "width" | "height">, x: number, y: number, horizontal: boolean, direction: ReadingDirection): number;
export declare function schedulerTimeEdge(rect: Pick<DOMRect, "left" | "right">, edge: string, direction: ReadingDirection): number;
