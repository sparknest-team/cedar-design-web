import type { SchedulerEvent, SchedulerDate } from "../core";
import type { SchedulerTimeDisambiguation, SchedulerRRuleSeries } from "./rrule";
export declare function exportSchedulerICalendar(events: readonly SchedulerEvent[], options: {
    stamp: SchedulerDate;
    name?: string;
}): string;
export interface SchedulerCalendarImport {
    events: SchedulerEvent[];
    series: SchedulerRRuleSeries[];
}
/** Import individual VEVENTs and RRULE seeds. Custom VTIMEZONE definitions are rejected, not guessed. */
export declare function importSchedulerICalendar(text: string, options?: {
    timeZone?: string;
    disambiguation?: SchedulerTimeDisambiguation;
}): SchedulerCalendarImport;
