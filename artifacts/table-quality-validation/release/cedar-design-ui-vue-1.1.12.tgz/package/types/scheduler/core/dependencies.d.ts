import type { SchedulerEvent } from "./types";
export interface SchedulerDependency {
    id: string;
    fromId: string;
    toId: string;
    type?: "finish-to-start" | "start-to-start" | "finish-to-finish" | "start-to-finish";
    /** Minimum distance in elapsed minutes; negative values allow overlap. */
    lag?: number;
}
export interface SchedulerDependencyIssue {
    dependencyId: string;
    code: "invalid" | "missing-event" | "cycle" | "order";
}
export declare function getSchedulerDependencyIssues(events: readonly SchedulerEvent[], dependencies: readonly SchedulerDependency[]): SchedulerDependencyIssue[];
