import type { SchedulerDate, SchedulerEvent } from "./types";
export interface SchedulerWorkingHours {
    daysOfWeek: number[];
    startMinute: number;
    endMinute: number;
    resourceIds?: string[];
}
export interface SchedulerDateWorkingHours {
    date: string;
    intervals: {
        startMinute: number;
        endMinute: number;
    }[];
    resourceIds?: string[];
}
export interface SchedulerDisabledRange {
    id: string;
    start: SchedulerDate;
    end: SchedulerDate;
    resourceIds?: string[];
    label?: string;
}
export interface SchedulerAvailabilityIssue {
    code: "outside-working-hours" | "disabled-range" | "invalid-config";
    resourceId?: string;
    rangeId?: string;
    label?: string;
}
export interface SchedulerAvailabilityOptions {
    workingHours?: readonly SchedulerWorkingHours[];
    dateWorkingHours?: readonly SchedulerDateWorkingHours[];
    disabledRanges?: readonly SchedulerDisabledRange[];
}
/** Checks every assigned resource. No Vue, DOM, networking or input mutation. */
export declare function getSchedulerAvailabilityIssues(event: SchedulerEvent, options: SchedulerAvailabilityOptions): SchedulerAvailabilityIssue[];
