import type { SchedulerEvent } from "./types";
/** Copy standard event fields into an independent event, without recurrence identity. */
export declare function duplicateSchedulerEvent(event: SchedulerEvent, id: string): SchedulerEvent;
