import type { SchedulerDate, SchedulerMode, SchedulerRange, SchedulerEvent, SchedulerChange, SchedulerConflict, SchedulerLayoutItem } from "./types";
export declare function schedulerDate(value: SchedulerDate): Date;
export declare function schedulerDay(value: SchedulerDate): Date;
export declare function addSchedulerDays(value: SchedulerDate, days: number): Date;
export declare function schedulerDateKey(value: SchedulerDate): string;
export declare function getSchedulerRange(value: SchedulerDate, mode: SchedulerMode, firstDayOfWeek?: number): SchedulerRange;
export declare function getSchedulerDays(range: SchedulerRange): Date[];
export declare function navigateSchedulerDate(value: SchedulerDate, mode: SchedulerMode, direction: number): Date;
export declare function cloneSchedulerEvent(event: SchedulerEvent): SchedulerEvent;
export declare function validateSchedulerEvent(event: SchedulerEvent): void;
export declare function isSchedulerEventInRange(event: SchedulerEvent, range: SchedulerRange): boolean;
export declare function getSchedulerConflicts(event: SchedulerEvent, events: readonly SchedulerEvent[]): SchedulerConflict[];
export declare function applySchedulerChange(events: readonly SchedulerEvent[], change: SchedulerChange): SchedulerEvent[];
export declare function moveSchedulerEvent(event: SchedulerEvent, start: SchedulerDate, fromResourceId?: string, toResourceId?: string): SchedulerEvent;
/** Pack connected overlap groups; adjacent events share a lane. Numbers are local minutes. */
export declare function layoutSchedulerEvents(events: readonly SchedulerEvent[], day: Date, startHour?: number, endHour?: number): SchedulerLayoutItem[];
/** Timeline positions are fractions of the visible calendar-day range. */
export declare function layoutSchedulerTimeline(events: readonly SchedulerEvent[], range: SchedulerRange, granularity?: "time" | "day"): SchedulerLayoutItem[];
