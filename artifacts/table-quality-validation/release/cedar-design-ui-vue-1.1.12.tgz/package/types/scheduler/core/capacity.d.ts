import type { SchedulerEvent, SchedulerRange, SchedulerResource } from "./types";
export interface SchedulerResourceLoad extends SchedulerRange {
    resourceId: string;
    /** Each scheduled event occupies one unit, including all-day events. */
    load: number;
    capacity?: number;
    exceeded: boolean;
    eventIds: string[];
}
export interface SchedulerCapacityIssue extends SchedulerResourceLoad {
    capacity: number;
    exceeded: true;
}
/** Occupied half-open spans, split whenever the active event set changes. */
export declare function getSchedulerResourceLoad(events: readonly SchedulerEvent[], resource: SchedulerResource, range?: SchedulerRange): SchedulerResourceLoad[];
/** Replace the candidate by id, then check only its time span and assigned resources. */
export declare function getSchedulerCapacityIssues(event: SchedulerEvent, events: readonly SchedulerEvent[], resources: readonly SchedulerResource[]): SchedulerCapacityIssue[];
export interface SchedulerResourceSummary {
    resourceId: string;
    peakLoad: number;
    unitMinutes: number;
    /** Percentage of the entire supplied elapsed range, not working-hours-only utilization. */
    utilization?: number;
}
export declare function getSchedulerResourceSummary(events: readonly SchedulerEvent[], resource: SchedulerResource, range: SchedulerRange): SchedulerResourceSummary;
