import type { SchedulerDate, SchedulerRange } from "./types";
import type { SchedulerDisabledRange } from "./availability";
export interface SchedulerCalendarOverride {
    date: string;
    working: boolean;
    label?: string;
}
export interface SchedulerBusinessCalendar {
    /** Default Monday–Friday; an empty array means no regular working days. */
    workingDays?: number[];
    overrides?: SchedulerCalendarOverride[];
}
/** Compile a detached lookup once for recurrence/availability scans. */
export declare function createSchedulerBusinessCalendar(calendar: SchedulerBusinessCalendar): (date: Date) => {
    working: boolean;
    label: string | undefined;
};
export declare function isSchedulerWorkingDate(date: SchedulerDate, calendar: SchedulerBusinessCalendar): boolean;
/** Adapt closed calendar dates to existing availability constraints. */
export declare function getSchedulerCalendarDisabledRanges(calendar: SchedulerBusinessCalendar, range: SchedulerRange, maxDays?: number): SchedulerDisabledRange[];
