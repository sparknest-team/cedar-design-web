import _CountTo from './CountTo.vue';
import { countToProps } from './props';
declare const CountTo: import('../_utils/global-config').ComponentWithInstall<typeof _CountTo>;
export type CountToInstance = InstanceType<typeof _CountTo>;
export type { CountToProps, CountToSlots, CountToEmits, CountToExpose } from './props';
export { countToProps };
export { CountTo };
export declare const _CountToComponent: typeof CountTo;
export default CountTo;
