import { type CountToSlots } from './props';
type __VLS_Slots = CountToSlots;
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    from: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
        validator: (value: string | number) => boolean;
    };
    to: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
        validator: (value: string | number) => boolean;
    };
    duration: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
        validator: (value: string | number) => boolean;
    };
    precision: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
        validator: (value: string | number) => boolean;
    };
    autoStart: {
        type: BooleanConstructor;
        default: boolean;
    };
    timingFunction: {
        type: import("vue").PropType<(v: number) => number>;
    };
}>, {
    start: () => void;
    pause: () => void;
    reset: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    end: () => any;
}, string, import("../vue-compat").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    from: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
        validator: (value: string | number) => boolean;
    };
    to: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
        validator: (value: string | number) => boolean;
    };
    duration: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
        validator: (value: string | number) => boolean;
    };
    precision: {
        type: (StringConstructor | NumberConstructor)[];
        default: number;
        validator: (value: string | number) => boolean;
    };
    autoStart: {
        type: BooleanConstructor;
        default: boolean;
    };
    timingFunction: {
        type: import("vue").PropType<(v: number) => number>;
    };
}>> & Readonly<{
    onEnd?: (() => any) | undefined;
}>, {
    duration: string | number;
    to: string | number;
    from: string | number;
    precision: string | number;
    autoStart: boolean;
}>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
