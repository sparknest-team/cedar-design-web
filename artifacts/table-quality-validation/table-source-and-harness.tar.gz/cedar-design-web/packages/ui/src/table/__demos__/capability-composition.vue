<template>
  <div ref="host" class="table-capability-demo">
    <div class="table-capability-demo__actions">
      <button
        type="button"
        data-table-action="layout"
        @click="mode = mode === 'fixed' ? 'auto' : 'fixed'"
      >
        {{ copy.layout }}
      </button>
      <button
        type="button"
        data-table-action="page"
        @click="page = page === 1 ? 2 : 1"
      >
        {{ copy.page }}
      </button>
      <button
        type="button"
        data-table-action="direction"
        @click="toggleDirection"
      >
        {{ copy.direction }}
      </button>
      <button
        type="button"
        data-table-action="data"
        @click="changed = !changed"
      >
        {{ copy.replace }}
      </button>
    </div>
    <section data-table-case="core">
      <h4>{{ copy.core }}</h4>
      <TableCore
        :columns="columns"
        :data="rows"
        :height="180"
        :table-layout="mode"
        :dir="direction"
        :aria-label="copy.core"
      />
    </section>
    <section data-table-case="paged">
      <h4>{{ copy.paged }}</h4>
      <c-table
        :columns="columns"
        :data="rows"
        :summary="summary"
        :height="180"
        :dir="direction"
        :sticky-pagination="false"
        :pagination="{ modelValue: page, pageSize: 5, responsive: false }"
        @page-change="page = $event"
      />
    </section>
    <section data-table-case="virtual">
      <h4>{{ copy.virtual }}</h4>
      <c-table
        :columns="columns"
        :data="rows"
        :summary="summary"
        :dir="direction"
        :pagination="false"
        :virtual-list-props="{ height: 180, estimatedSize: 35, buffer: 0 }"
      />
    </section>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from "vue";
import TableCore from "../core";
import "../core/style";
import { useDemoLocale } from "../../__demos__/locale";
import type { TableData } from "../types";

const copy = useDemoLocale("tableCapabilities");
const host = ref<HTMLElement>();
const mode = ref<"fixed" | "auto">("fixed");
const direction = ref<"ltr" | "rtl">();
const page = ref(1);
const changed = ref(false);
const columns = computed(() => [
  {
    title: copy.value.group,
    children: [
      {
        title: copy.value.name,
        dataIndex: "name",
        width: 140,
        minWidth: 140,
        fixed: "left" as const,
      },
      {
        title: copy.value.amount,
        dataIndex: "amount",
        width: 220,
        minWidth: 220,
      },
    ],
  },
  { title: copy.value.note, dataIndex: "note", width: 240, minWidth: 240 },
]);
const rows = computed(() =>
  changed.value
    ? [
        {
          key: "changed",
          name: copy.value.changed,
          amount: 7,
          note: copy.value.note,
        },
      ]
    : Array.from({ length: 100 }, (_, index) => ({
        key: String(index),
        name: `Cedar ${index}`,
        amount: index,
        note: `${copy.value.note} ${index}`,
      })),
);
const summary = ({ data }: { data: TableData[] }) => [
  {
    key: "total",
    name: copy.value.total,
    amount: data.reduce((sum, row) => sum + row.amount, 0),
    note: copy.value.note,
  },
];
const toggleDirection = () => {
  const current =
    direction.value ??
    (host.value ? getComputedStyle(host.value).direction : "ltr");
  direction.value = current === "rtl" ? "ltr" : "rtl";
};
</script>

<style scoped>
.table-capability-demo {
  display: grid;
  gap: 16px;
}
.table-capability-demo__actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.table-capability-demo section {
  width: 360px;
  max-width: 100%;
  min-width: 0;
}
</style>
